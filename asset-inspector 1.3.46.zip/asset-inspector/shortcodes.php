<?php
function scan_unused_elementor_templates() {
    // Get all Elementor templates
    ob_start();
    $templates = get_posts(array(
        'post_type' => array('elementor_library','jet-engine','ae_global_templates','jet-popup'),
        'post_status' => 'publish',
        'numberposts' => -1
    ));

    // Create an array of template IDs
    
    foreach ($templates as $template) {
        $template_ids[] = $template->ID;
    }
	$used_templates = array();
    // Query to get all published posts with '_elementor_data' meta key
    global $wpdb;
    $results = $wpdb->get_results("
        SELECT pm.post_id, pm.meta_value 
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
        WHERE pm.meta_key = '_elementor_data' AND p.post_status = 'publish'
    ");

    $used_templates = array();
    foreach ($results as $result) {
		
		if (Elementor\Plugin::instance()->db->is_built_with_elementor($result->post_id)) {
			///this is an elementor page
			
			$string=$result->meta_value;
			$stripped_string = str_replace(['[', ']'], '', $string);
			$stripped_string = str_replace(['\\'], '', $string);

			preg_match_all('/elementor-template id="(\d+)"/', $stripped_string, $template_shortcode_matches); //elementor template shortcode
			preg_match_all('/"template_id":"([^"]+)"/', $result->meta_value, $template_matches); //  "template_id":"79"
			preg_match_all('/"lisitng_id":"([^"]+)"/', $result->meta_value, $listing_matches); //JetEngine Listing
			preg_match_all('/"popup":"([^"]+)"/', urldecode($result->meta_value), $popup_matches); //Elementor Popup
			preg_match_all('/INSERT_ELEMENTOR id="(\d+)"/', $stripped_string, $ae_template_shortcode_matches); //AE Global Templates
			preg_match_all('/"jet_attached_popup":"([^"]+)"/', $result->meta_value, $jet_popup_matches);

			

			$shortcode_ids_ = $template_shortcode_matches[1];
			$template_ids_ = $template_matches[1];
			$listing_ids_ = $listing_matches[1];
			$popup_matches_ = $popup_matches[1];
			$ae_template_shortcode_matches_ = $ae_template_shortcode_matches[1];
			$jet_popup_matches_ = $jet_popup_matches[1];

			echo "<h2>".get_the_title($result->post_id)."</h2>";
			

			foreach($shortcode_ids_ as $id){
				echo "<h3>".$id."</h3>";
				$used_templates[]=$id;
			}
			foreach($template_ids_ as $id){
				echo "<h3>".$id."</h3>";
				$used_templates[]=$id;
			}
			foreach($listing_ids_ as $id){
				echo "<h3>".$id."</h3>";
				$used_templates[]=$id;
			}

			foreach($popup_matches_ as $id){
				echo "<h3>".$id."</h3>";
				$used_templates[]=$id;
			}

			foreach($ae_template_shortcode_matches_ as $id){
				echo "<h3>".$id."</h3>";
				$used_templates[]=$id;
			}

			foreach($jet_popup_matches_ as $id){
				echo "<h3>".$id."</h3>";
				$used_templates[]=$id;
			}

			echo "<div style='border-bottm:1px solid #000;'>---</div>";
			
			///this is an elementor page
		} else {
			///not an elementor page
			$post_content = $wpdb->get_var($wpdb->prepare("SELECT post_content FROM {$wpdb->posts} WHERE ID = %d", $result->post_id));
			
			preg_match_all('/elementor-template id="(\d+)"/', $post_content, $template_shortcode_matches); //elementor template shortcode			
			preg_match_all('/INSERT_ELEMENTOR id="(\d+)"/', $post_content, $AEtemplate_shortcode_matches); //ae template shortcode						
				
			$shortcode_ids_ = $template_shortcode_matches[1];
			$AEtemplate_shortcode_matches_ = $AEtemplate_shortcode_matches[1];
			
			echo "<h2>".get_the_title($result->post_id)."</h2>";
			echo "<p>".$post_content."</p>";

			foreach($shortcode_ids_ as $id){
				echo "<h3>".$id."</h3>";
				$used_templates[]=$id;
			}
			
			foreach($AEtemplate_shortcode_matches_ as $id){
				echo "<h3>".$id."</h3>";
				$used_templates[]=$id;
			}
			
			
			///not an elementor page
		}

		
		
		
	
    }
	// Check for post_meta meta_key _elementor_conditions
	foreach ($templates as $template) {
		// Check for post_meta meta_key _elementor_conditions
		$elementor_conditions = get_post_meta($template->ID, '_elementor_conditions', true);
		switch (true) {
			case !empty($elementor_conditions):
				$used_templates[] = $template->ID;
				break;
			default:
				// Get the meta value
				$jetPopupConditions = get_post_meta($template->ID, '_conditions', true);
				switch (true) {
					case !empty($jetPopupConditions) && $jetPopupConditions !== 'a:0:{}':
						// Skip processing
						$used_templates[] = $template->ID;
						break;
					default:
						// Search for the post_id where $template->ID is the meta_value for meta_key 'pa_mega_content_temp'
						$post_id = $wpdb->get_var($wpdb->prepare(
							"SELECT post_id FROM $wpdb->postmeta WHERE meta_key = %s AND meta_value = %d",
							'pa_mega_content_temp',
							$template->ID
						));
						if ($post_id) {
							$post_type = get_post_type($post_id);
							if ($post_type === 'nav_menu_item') {
								
								echo "-----------".$post_id." = ".$template->ID;
								$item_data = $wpdb->get_var($wpdb->prepare(
									"SELECT meta_value FROM $wpdb->postmeta WHERE post_id = %d AND meta_key = %s",
									$post_id,'pa_megamenu_item_meta',
								));
								
								//"full_width_mega_content":"false"
								if($item_data){
									if (preg_match('/"mega_content_enabled":"true"/', $item_data)) {//mega menu enabled/disabled
										echo "Mega Menu Enabled";
										$used_templates[] = $template->ID;
									} else {
										echo "Mega Menu Disabled";
									}

								}else{
									
								}
							}
						}
						break;
				}
				break;
		}
	}

	
	//add PA Template Mega Menu
	//menu item = post type: nav_menu_item 
	//loop nav_menu_item
	//get meta_value from meta_key 'pa_mega_content_temp' and cross reference it with all templates if it is used.

    // Get unique used templates
    $used_templates = array_unique($used_templates);

	foreach($used_templates as $i){
		echo "<h4>==".$i."</h4>";
	}
    // Find unused templates
    $unused_templates = array_diff($template_ids, $used_templates);

    // Output the unused templates
    echo "<h3>Unused Elementor Templates:</h3><ol>";
    foreach ($unused_templates as $unused_template) {
        echo "<li>Template ID: $unused_template</li>";
    }
    echo "</ol>";

    return ob_get_clean();
}
// Register the shortcode
add_shortcode('scan_unused_templates', 'scan_unused_elementor_templates');