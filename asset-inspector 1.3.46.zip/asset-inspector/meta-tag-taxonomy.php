<?php
/********************META TAG GENERATOR FOR TAXONOMIES**********************/
function mt_taxonomy_settings_page() {
    echo '<div class="wrap"><h1>Taxonomy Metadata Generator</h1>';

    // Dropdown to select taxonomy
    $taxonomies = array_filter(
      get_taxonomies(['public' => true], 'objects'),
      function($tax) {
        $terms = get_terms(['taxonomy' => $tax->name, 'hide_empty' => false]);
        return !empty($terms);
      }
    );
    
    ?>
    <div class="tax-meta-fields">
        <div class="tax-selection">
            <select id="taxonomy-selector">
            <?php foreach ($taxonomies as $taxonomy) {
                ?><option value="<?php echo esc_attr($taxonomy->name);?>"><?php echo esc_html($taxonomy->label);?></option><?php
            }?>
            </select>
        </div>

        <div class="tax-meta-gen-buttons">
            <button id="gem-generate-all-terms" class="button">Generate Tags</button>
            <button id="gem-save-all-terms" class="button button-primary">💾 Save All Changes</button>
        </div>
    </div>

    <div id="gem-progress-wrapper" style="margin: 1em 0; display: none;">
    <div style="height: 8px; background: #eee; width: 100%; border-radius: 4px;">
        <div id="gem-progress-bar" style="height: 100%; width: 0%; background: #0073aa; transition: width 0.3s ease; border-radius: 4px;"></div>
    </div>
    <small id="gem-progress-label" style="display: block; margin-top: 4px; color: #555;">Starting...</small>
    </div>


    <?php // Placeholder for term table
    ?>
    <div id="taxonomy-meta-table"></div>

    </div>

    
    <style>
        div#taxonomy-meta-table input[type="text"], div#taxonomy-meta-table textarea {
            width: 100%;
        }
        .tax-meta-fields {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
    </style>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
  const selector = document.getElementById('taxonomy-selector');
  const tableContainer = document.getElementById('taxonomy-meta-table');

  function loadTerms(filterMissing = false) {
    tableContainer.innerHTML = '<p>Loading terms...</p>';
    fetch(ajaxurl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action: 'gem_load_taxonomy_terms',
        taxonomy: selector.value,
        filter_missing: filterMissing ? '1' : '0',
        nonce: '<?php echo wp_create_nonce("gem_taxonomy_nonce"); ?>'
      })
    })
    .then(res => res.text())
    .then(html => tableContainer.innerHTML = html)
    .catch(err => tableContainer.innerHTML = '<p>Error loading terms.</p>');
  }

  selector.addEventListener('change', () => loadTerms());
  document.body.addEventListener('change', function (e) {
    if (e.target.id === 'gem-filter-missing') {
      loadTerms(e.target.checked);
    }
  });

  selector.dispatchEvent(new Event('change'));
});

    </script>

<script>
document.addEventListener('DOMContentLoaded', function () {
  // Generate tags for a single term
  document.body.addEventListener('click', function (e) {
    if (e.target.classList.contains('generate-tags-btn')) {
      const btn = e.target;
      const termId = btn.dataset.term;
      const taxonomy = btn.dataset.taxonomy;
      btn.textContent = '⏳ Generating...';

      fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          action: 'gem_generate_term_tags',
          term_id: termId,
          taxonomy: taxonomy,
          nonce: '<?php echo wp_create_nonce("gem_taxonomy_nonce"); ?>'
        })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          const { description, primary_keyword, additional_keywords } = data.data;
          document.querySelector(`.gem-primary[data-id="${termId}"]`).value = primary_keyword;
          document.querySelector(`.gem-additional[data-id="${termId}"]`).value = additional_keywords;
          document.querySelector(`.gem-description[data-id="${termId}"]`).value = description;
          btn.textContent = '✅ Done';
        } else {
          btn.textContent = '❌ Error';
          alert(data.data.message || 'Generation failed');
        }
      })
      .catch(err => {
        btn.textContent = '❌ Failed';
        console.error(err);
      });
    }
  });

  // Save tags for a single term
  document.body.addEventListener('click', function (e) {
    if (e.target.classList.contains('gem-save-row')) {
      const btn = e.target;
      const termId = btn.dataset.term;
      const taxonomy = btn.dataset.taxonomy;
      const primary = document.querySelector(`.gem-primary[data-id="${termId}"]`).value;
      const additional = document.querySelector(`.gem-additional[data-id="${termId}"]`).value;
      const description = document.querySelector(`.gem-description[data-id="${termId}"]`).value;
      btn.textContent = '💾 Saving...';

      fetch(ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          action: 'gem_save_term_tags',
          term_id: termId,
          taxonomy: taxonomy,
          primary: primary,
          additional_keywords: additional,
          description: description,
          nonce: '<?php echo wp_create_nonce("gem_taxonomy_nonce"); ?>'
        })
      })
      .then(res => res.json())
      .then(data => {
        btn.textContent = data.success ? '✅ Saved' : '❌ Error';
        if (!data.success) alert(data.data.message || 'Save failed');
      })
      .catch(err => {
        btn.textContent = '❌ Failed';
        console.error(err);
      });
    }
  });
});
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
  const generateAllBtn = document.getElementById('gem-generate-all-terms');
  const saveAllBtn = document.getElementById('gem-save-all-terms');
  const progressBar = document.getElementById('gem-progress-bar');
  const progressLabel = document.getElementById('gem-progress-label');
  const wrapper = document.getElementById('gem-progress-wrapper');

  function updateProgress(current, total) {
    const percent = Math.round((current / total) * 100);
    progressBar.style.width = percent + '%';
    progressLabel.textContent = `Processed ${current} of ${total} terms (${percent}%)`;
  }

  generateAllBtn.addEventListener('click', function () {
    const rows = document.querySelectorAll('.generate-tags-btn');
    if (!rows.length) return;

    wrapper.style.display = 'block';
    let index = 0;

    function processNext() {
      if (index >= rows.length) {
        progressLabel.textContent = '✅ All terms generated.';
        return;
      }

      const btn = rows[index];
      btn.click(); // triggers individual generation
      updateProgress(index + 1, rows.length);
      index++;
      setTimeout(processNext, 3000); // Gemini pacing
    }

    processNext();
  });

  saveAllBtn.addEventListener('click', function () {
    const rows = document.querySelectorAll('.gem-save-row');
    if (!rows.length) return;

    wrapper.style.display = 'block';
    let index = 0;

    function processNext() {
      if (index >= rows.length) {
        progressLabel.textContent = '✅ All terms saved.';
        return;
      }

      const btn = rows[index];
      btn.click(); // triggers individual save
      updateProgress(index + 1, rows.length);
      index++;
      setTimeout(processNext, 500); // faster than generation
    }

    processNext();
  });
});
</script>






    <?php
}



add_action('wp_ajax_gem_load_taxonomy_terms', function () {
    check_ajax_referer('gem_taxonomy_nonce', 'nonce');
  
    $taxonomy = sanitize_text_field($_POST['taxonomy'] ?? '');
    $filter_missing = isset($_POST['filter_missing']) && $_POST['filter_missing'] === '1';
  
    if (!taxonomy_exists($taxonomy)) {
      echo '<p>❌ Invalid taxonomy.</p>';
      wp_die();
    }
  
    $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]);
    if (is_wp_error($terms) || empty($terms)) {
      echo '<p>No terms found.</p>';
      wp_die();
    }
  
    $option = get_option('wpseo_taxonomy_meta', []);
    $taxonomy_meta = $option[$taxonomy] ?? [];
  
    $total = count($terms);
    $shown = 0;
    $missing = 0;
  
    // echo '<div style="margin: 1em 0;">';
    // echo '<label><input type="checkbox" id="gem-filter-missing" ' . ($filter_missing ? 'checked' : '') . '> Show only terms missing metadata</label>';
    // echo '<p><strong>Total terms:</strong> ' . $total . ' | <strong>Missing metadata:</strong> <span id="gem-missing-count">0</span> | <strong>Displayed:</strong> <span id="gem-shown-count">0</span></p>';
    // echo '</div>';
  
    echo '<table class="widefat striped">
    <thead><tr>
      <th>Term ID</th>
      <th>Name</th>
      <th>Primary Keyword</th>
      <th>Additional Keywords</th>
      <th>Meta Description</th>
      <th width="230">Actions</th>
    </tr></thead><tbody>';
  
    foreach ($terms as $term) {
      $term_id = $term->term_id;
      $name = esc_html($term->name);
      $desc = esc_html($term->description);
  
      $meta = $taxonomy_meta[$term_id] ?? [];
      $primary = $meta['wpseo_focuskw'] ?? '';
      $desc_meta = $meta['wpseo_desc'] ?? '';
      $focuskeywords_json = $meta['wpseo_focuskeywords'] ?? '';
      $additional_list = [];
  
      if ($focuskeywords_json) {
        $decoded = json_decode($focuskeywords_json, true);
        if (is_array($decoded)) {
          $additional_list = array_column($decoded, 'keyword');
        }
      }
  
      $keyword_string = implode(', ', $additional_list);
      $is_missing = empty($primary) && empty($desc_meta) && empty($keyword_string);
  
      if ($is_missing) $missing++;
      if ($filter_missing && !$is_missing) continue;
  
      $shown++;
  
      echo "<tr>
        <td>{$term_id}</td>
        <td>{$name}</td>
        <td><input type='text' class='gem-primary' data-id='{$term_id}' value='" . esc_attr($primary) . "'></td>
        <td><input type='text' class='gem-additional' data-id='{$term_id}' value='" . esc_attr($keyword_string) . "'></td>
        <td><textarea class='gem-description' data-id='{$term_id}' rows='2'>" . esc_textarea($desc_meta) . "</textarea></td>
        <td>
          <button class='generate-tags-btn button' data-term='{$term_id}' data-taxonomy='{$taxonomy}'>Generate</button>
          <button class='gem-save-row button' data-term='{$term_id}' data-taxonomy='{$taxonomy}'>💾</button>
        </td>
      </tr>";
    }
  
    echo '</tbody>
    <tfoot><tr>
      <th>Term ID</th>
      <th>Name</th>
      <th>Primary Keyword</th>
      <th>Additional Keywords</th>
      <th>Meta Description</th>
      <th>Actions</th>
    </tr></tfoot>
    </table>';
    echo "<script>
      document.getElementById('gem-missing-count').textContent = '{$missing}';
      document.getElementById('gem-shown-count').textContent = '{$shown}';
    </script>";
  
    wp_die();
  });
  
  
  


  

  add_action('wp_ajax_gem_generate_term_tags', function () {
    check_ajax_referer('gem_taxonomy_nonce', 'nonce');
  
    $term_id = intval($_POST['term_id'] ?? 0);
    $taxonomy = sanitize_text_field($_POST['taxonomy'] ?? '');
  
    if (!$term_id || !taxonomy_exists($taxonomy)) {
      wp_send_json_error(['message' => 'Invalid term or taxonomy']);
      return;
    }
  
    $term = get_term($term_id, $taxonomy);
    if (is_wp_error($term)) {
      wp_send_json_error(['message' => 'Failed to load term']);
      return;
    }
  
    $term_name = $term->name;
    $term_desc = $term->description;
    $site_title = get_bloginfo('name');
    $lang = get_bloginfo('language');
    $word_count = intval(get_option('gen_ai_meta_length', 30));
    $max_keywords = intval(get_option('gem_max_additional_keywords', 4));
  
    $prompt = "You're an SEO assistant working in {$lang}. For the following taxonomy archive page, generate:
  - A brief meta description (~{$word_count} words)
  - A primary keyword
  - Up to {$max_keywords} additional keywords
  
  Respond in JSON:
  {
    \"description\": \"...\",
    \"primary_keyword\": \"...\",
    \"additional_keywords\": \"...\"
  }
  
  Category name: {$term_name}
  Description: {$term_desc}
  Site name: {$site_title}";
  
    $api_key = decrypt_gen_ai_api_key(get_option('gen_ai_api_key'));
    if (empty($api_key)) {
      wp_send_json_error(['message' => 'Missing API key']);
      return;
    }
  
    $result = gem_call_gemini_api($prompt, $api_key);
    if (is_wp_error($result)) {
      wp_send_json_error(['message' => $result->get_error_message()]);
      return;
    }
  
    wp_send_json_success($result);
  });
  

  add_action('wp_ajax_gem_save_term_tags', function () {
    check_ajax_referer('gem_taxonomy_nonce', 'nonce');
  
    $term_id = intval($_POST['term_id'] ?? 0);
    $taxonomy = sanitize_text_field($_POST['taxonomy'] ?? '');
    $primary = sanitize_text_field($_POST['primary'] ?? '');
    $desc = sanitize_textarea_field($_POST['description'] ?? '');
    $additional = sanitize_text_field($_POST['additional_keywords'] ?? '');
  
    if (!$term_id || !taxonomy_exists($taxonomy)) {
      wp_send_json_error(['message' => 'Invalid term or taxonomy']);
      return;
    }
  
    // Prepare additional keywords
    $keywords_array = array_filter(array_map('trim', explode(',', $additional)));
    $limit = intval(get_option('gem_max_additional_keywords', 4));
    $keywords_array = array_slice($keywords_array, 0, $limit);
  
    $scored = [];
    foreach ($keywords_array as $keyword) {
      $scored[] = ['keyword' => $keyword, 'score' => '56']; // default score
    }
  
    // Build term meta array
    $term_meta = [
      'wpseo_focuskw' => $primary,
      'wpseo_desc' => $desc,
      'wpseo_focuskeywords' => wp_json_encode($scored),
      'wpseo_keywordsynonyms' => '["","",""]',
      'wpseo_linkdex' => '35',
      'wpseo_content_score' => '90'
    ];
  
    // Load existing option
    $option = get_option('wpseo_taxonomy_meta', []);
    if (!is_array($option)) $option = [];
  
    // Update taxonomy + term
    if (!isset($option[$taxonomy])) $option[$taxonomy] = [];
    $option[$taxonomy][$term_id] = $term_meta;
  
    // Save back to wp_options
    update_option('wpseo_taxonomy_meta', $option);
  
    wp_send_json_success(['message' => 'Saved to wp_options']);
  });
  
  

  