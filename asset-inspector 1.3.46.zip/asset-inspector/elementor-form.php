<?php
function mt_forms_page() {
    $forms = mt_get_elementor_forms();

    // Get all pages for dropdown
    $pages = get_pages();
    $thank_you_id = 0;
    foreach ($pages as $p) {
        if (stripos($p->post_title, 'thank you') !== false) {
            $thank_you_id = $p->ID;
            break;
        }
    }

    $nonce = wp_create_nonce('mt_save_form_settings');
    ?>
    <div class="wrap">
        <h1>📋 Elementor Forms Audit</h1>

        <div style="margin-bottom:15px;">
            <label for="bulk-redirect-page">Redirect Page:</label>
            <select id="bulk-redirect-page">
                <?php foreach ($pages as $p): ?>
                    <option value="<?= esc_attr($p->ID) ?>" <?= selected($p->ID, $thank_you_id) ?>>
                        <?= esc_html($p->post_title) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button id="bulk-update-forms" class="button button-primary">Bulk Update All Forms</button>
        </div>

        <table class="widefat fixed striped">
            <thead>
                <tr>
                    <th>Page Title</th>
                    <th width="100">Post Type</th>
                    <th style="display:none;">Post ID</th>
                    <th>To</th>
                    <th width="25%">Subject</th>
                    <th width="25%">From (Name &amp; Email)</th>
                    <th>Reply-To</th>
                    <th>Redirect</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($forms as $form):
                $post_id            = (int) $form['id'];
                $to                 = $form['to'] ?? '—';
                $subject            = $form['subject'] ?? '—';
                $subject_dynamic     = $form['subject_static'] ?? '—';
                $from_name          = trim($form['from_name'] ?? '');
                $from_email         = $form['from_email'] ?? '';
                $reply_to           = $form['reply_to'] ?? '—';
                $redirect           = $form['redirect'] ?? '—';
            ?>
                <tr>
                    <td>
                        <strong><?= esc_html($form['title']) ?></strong>
                        <div class="row-actions" style="margin-top:4px;">
                            <span class="edit"><a href="#" class="quick-edit-trigger" data-post="<?= $post_id ?>">Quick Edit</a></span> |
                            <span class="elementor"><a href="<?= esc_url($form['edit_url']) ?>" target="_blank">Edit with Elementor</a></span>
                        </div>
                    </td>
                    <td><?= esc_html($form['type']) ?></td>
                    <td style="display:none;"><?= $post_id ?></td>
                    <td class="col-to" data-post="<?= $post_id ?>"><?= esc_html($to) ?></td>
                    <td class="col-subject" data-post="<?= $post_id ?>"><?= esc_html($subject) ?></td>
                    <td class="col-from" data-post="<?= $post_id ?>"><?= esc_html(trim($from_name . ' <' . $from_email . '>')) ?></td>
                    <td class="col-reply-to" data-post="<?= $post_id ?>"><?= esc_html($reply_to) ?></td>
                    <td class="col-redirect" data-post="<?= $post_id ?>"><?= $redirect ?></td>
                </tr>
                <tr id="quick-edit-row-<?= $post_id ?>" class="quick-edit-row" style="display:none;">
                    <td colspan="7" style="padding:10px; background:#f9f9f9; border:1px solid #ddd;">
                        <div class="quick-edit-container">
                            <div class="quick-edit-item quick-edit-item-to">
                                <label>To:
                                    <input type="text" class="form-to" value="<?= esc_attr($to) ?>" data-post="<?= $post_id ?>" style="width:100%;" />
                                </label>
                            </div>
                            <div class="quick-edit-item quick-edit-item-subject item-<?= !$subject_dynamic ? 'static' : 'dynamic' ?>">
                                <?php if(!$subject_dynamic){
                                    ?>
                                    <label>Subject:
                                        <input type="text" class="form-subject" value="<?= esc_attr($subject) ?>" data-post="<?= $post_id ?>" style="width:100%;" />
                                    </label>
                                    <?php
                                }else{ 
                                    ?>
                                    <label>Subject:
                                        <input type="disabled" class="form-subject form-disabled" value="" Placeholder="This subject is set dynamically. To change it, edit the form in Elementor." data-post="<?= $post_id ?>" style="width:100%;" readonly />
                                    </label>

                                    <?php
                                }?>
                            
                            </div>
                                                
                            <button class="button button-primary save-quick-edit" data-post="<?= $post_id ?>">Save</button>
                            <button class="button cancel-quick-edit" data-post="<?= $post_id ?>">Cancel</button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Page Title</th>
                    <th width="100">Post Type</th>
                    <th style="display:none;">Post ID</th>
                    <th>To</th>
                    <th width="25%">Subject</th>
                    <th width="25%">From (Name &amp; Email)</th>
                    <th>Reply-To</th>
                    <th>Redirect</th>
                </tr>
            </tfoot>
        </table>
    </div>

    <style>
        .quick-edit-container {
            padding: 20px;
            margin: 10px;
            border: 1px solid #bfbfbf;
            display: flex;
            gap: 20px;
        }
        .quick-edit-container button {
            align-self: end;
        }
        .form-disabled{
            width: 100%;
            padding: 0 8px;
            line-height: 2;
            min-height: 30px;
            box-shadow: 0 0 0 transparent;
            border-radius: 4px;
            border: 1px solid #8c8f94;
            background-color: #dddddd;
            color: #2c3338;
        }
        .quick-edit-item {
            width: 250px;
        }
        .quick-edit-item.quick-edit-item-subject {
            width: 600px;
        }
    </style>
    <script>
    const mtFormNonce = "<?= esc_js($nonce) ?>";

    document.addEventListener("DOMContentLoaded", function() {
        document.querySelectorAll(".quick-edit-trigger").forEach(btn => {
            btn.addEventListener("click", e => {
                e.preventDefault();
                const postId = btn.dataset.post;
                document.querySelectorAll(".quick-edit-row").forEach(row => row.style.display = "none");
                document.getElementById("quick-edit-row-" + postId).style.display = "table-row";
            });
        });

        document.querySelectorAll(".cancel-quick-edit").forEach(btn => {
            btn.addEventListener("click", () => {
                document.querySelectorAll(".quick-edit-row").forEach(row => row.style.display = "none");
            });
        });

        // document.querySelectorAll(".set-reply-to").forEach(btn => {
        //     btn.addEventListener("click", () => {
        //         const postId = btn.dataset.post;
        //         const input = document.querySelector(`.form-reply-to[data-post="${postId}"]`);
        //         if (input) input.value = "[Email Field]";
        //     });
        // });

        document.querySelectorAll(".save-quick-edit").forEach(btn => {
            btn.addEventListener("click", () => {
                const postId = btn.dataset.post;
                const to = document.querySelector(`.form-to[data-post="${postId}"]`).value;
                const subject = document.querySelector(`.form-subject[data-post="${postId}"]`).value;

                const payload = {
                    action: "mt_save_form_settings",
                    post_id: postId,
                    email_to: to,
                    email_subject: subject,
                    _ajax_nonce: mtFormNonce
                };

                fetch(ajaxurl, {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: new URLSearchParams(payload)
                })
                .then(res => res.json())
                .then(json => {
                    if (json.success) {
                        const body = json.data;
                        document.querySelector(`.col-to[data-post="${postId}"]`).textContent = body.debug.email_to || "—";
                        document.querySelector(`.col-subject[data-post="${postId}"]`).textContent = body.debug.email_subject || "—";
                        document.getElementById(`quick-edit-row-${postId}`).style.display = "none";
                    } else {
                        alert("Error: " + (json.data?.message || "Unknown error"));
                    }
                });
            });
        });

        document.getElementById("bulk-update-forms").addEventListener("click", () => {
            if (!confirm("This will set Reply-To to the email field and Redirect to the selected page for ALL forms. Continue?")) return;
            const redirectPageId = document.getElementById("bulk-redirect-page").value;

            const payload = {
                action: "mt_bulk_update_forms",
                redirect_page_id: redirectPageId,
                _ajax_nonce: mtFormNonce
            };

            fetch(ajaxurl, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams(payload)
            })
            .then(res => res.json())
            .then(json => {
                if (json.success) {
                    alert("✅ All forms updated successfully");
                    location.reload();
                } else {
                    alert("❌ Error: " + (json.data?.message || "Unknown error"));
                }
            });
        });
    });
    </script>
    <?php
}


function mt_get_elementor_forms() {
    $forms = [];
    $post_types = get_post_types(['public' => true], 'names');

    foreach ($post_types as $post_type) {
        $posts = get_posts([
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_query'     => [
                [
                    'key'     => '_elementor_data',
                    'compare' => 'EXISTS',
                ],
            ],
        ]);

        foreach ($posts as $post) {
            $raw = get_post_meta($post->ID, '_elementor_data', true);
            if (is_array($raw)) {
                $content_array = $raw;
            } elseif (is_string($raw)) {
                $content_array = json_decode($raw, true);
                if (!is_array($content_array)) {
                    $content_array = json_decode(wp_unslash($raw), true);
                }
            } else {
                continue;
            }
            if (!is_array($content_array)) continue;

            // Helper: format dynamic or static value
            $get_value = function($settings, $key) {
                if (!empty($settings['__dynamic__'][$key])) {
                    $tag_str = $settings['__dynamic__'][$key];

                    // Extract tag name
                    preg_match('/name="([^"]+)"/', $tag_str, $name_match);
                    $tag_name = $name_match[1] ?? '';

                    // Extract and decode settings JSON
                    $before = $after = '';
                    if (preg_match('/settings="([^"]+)"/', $tag_str, $settings_match)) {
                        $decoded_json = json_decode(urldecode($settings_match[1]), true);
                        if (is_array($decoded_json)) {
                            $before = $decoded_json['before'] ?? '';
                            $after  = $decoded_json['after'] ?? '';

                            // Special case: internal-url → get post title
                            if ($tag_name === 'internal-url' && !empty($decoded_json['post_id'])) {
                                $title = get_the_title((int) $decoded_json['post_id']);
                                if ($title) {
                                    return 'Page: <strong>' . esc_html($title) . '</strong> (dynamic)';
                                }
                            }
                        }
                    }

                    // Default dynamic display
                    return trim($before . ' [tag name="' . $tag_name . '"] ' . $after) . ' (dynamic)';
                }

                // Static value
                return $settings[$key] ?? '';
            };

            $scan = function ($elements) use (&$scan, $post, &$forms, $get_value) {
                foreach ($elements as $el) {
                    if (
                        isset($el['elType'], $el['widgetType']) &&
                        $el['elType'] === 'widget' &&
                        $el['widgetType'] === 'form'
                    ) {
                        $settings = isset($el['settings']) && is_array($el['settings']) ? $el['settings'] : [];

                        // First email field ID for Reply-To detection
                        $first_email_id = '';
                        if (!empty($settings['form_fields']) && is_array($settings['form_fields'])) {
                            foreach ($settings['form_fields'] as $field) {
                                if (isset($field['field_type']) && $field['field_type'] === 'email') {
                                    $first_email_id = !empty($field['custom_id']) ? $field['custom_id'] : ($field['id'] ?? '');
                                    break;
                                }
                            }
                        }

                        $reply_to_display = '';
                        if (!empty($settings['email_reply_to']) && $settings['email_reply_to'] === $first_email_id) {
                            $reply_to_display = '[Email Field]';
                        }

                        // ✅ Only show redirect if submit_actions contains "redirect"
                        $redirect_value = '';
                        if (!empty($settings['submit_actions'])
                            && is_array($settings['submit_actions'])
                            && in_array('redirect', $settings['submit_actions'], true)
                        ) {
                            $redirect_value = $get_value($settings, 'redirect_to');
                        }

                        // Detect if subject is dynamic
                        $is_subject_static = !empty($settings['__dynamic__']['email_subject']);

                        $forms[] = [
                            'id'               => $post->ID,
                            'title'            => get_the_title($post),
                            'type'             => get_post_type($post),
                            'to'               => $get_value($settings, 'email_to'),
                            'subject'          => $get_value($settings, 'email_subject'),
                            'subject_static'  => $is_subject_static,
                            'from_name'        => $get_value($settings, 'email_from_name'),
                            'from_email'       => $get_value($settings, 'email_from'),
                            'reply_to'         => $reply_to_display,
                            'redirect'         => $redirect_value,
                            'edit_url'         => admin_url('post.php?post=' . $post->ID . '&action=elementor')
                        ];
                    }

                    if (!empty($el['elements']) && is_array($el['elements'])) {
                        $scan($el['elements']);
                    }
                    if (!empty($el['inner']) && is_array($el['inner'])) {
                        $scan($el['inner']);
                    }
                }
            };

            if (isset($content_array[0]) || empty($content_array['elements'])) {
                $scan($content_array);
            } else {
                $scan($content_array['elements']);
            }
        }
    }

    return $forms;
}







add_action('wp_ajax_mt_save_form_settings', 'mt_save_form_settings');

function mt_save_form_settings() {
    $debug = [];

    // Permission + nonce checks
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(['message' => 'Permission denied', 'debug' => $debug]);
    }
    if (!check_ajax_referer('mt_save_form_settings', '_ajax_nonce', false)) {
        wp_send_json_error(['message' => 'Security check failed', 'debug' => $debug]);
    }

    // Inputs from Quick Edit
    $post_id           = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
    $email_to_in       = isset($_POST['email_to']) ? sanitize_text_field(wp_unslash($_POST['email_to'])) : '';
    $email_subject_in  = isset($_POST['email_subject']) ? sanitize_text_field(wp_unslash($_POST['email_subject'])) : '';
    
    

    $debug['post_id']          = $post_id;
    $debug['email_to']         = $email_to_in;
    $debug['email_subject']    = $email_subject_in;
    
    

    if ($post_id <= 0) {
        wp_send_json_error(['message' => 'Invalid post ID', 'debug' => $debug]);
    }

    // Get and decode _elementor_data
    $raw = get_post_meta($post_id, '_elementor_data', true);
    if (is_array($raw)) {
        $content_array = $raw;
    } elseif (is_string($raw)) {
        $content_array = json_decode($raw, true);
        if (!is_array($content_array)) {
            $content_array = json_decode(wp_unslash($raw), true);
        }
    } else {
        $content_array = null;
    }

    if (!is_array($content_array)) {
        wp_send_json_error(['message' => 'Invalid Elementor data', 'debug' => $debug]);
    }

    // Recursively update form widget settings
    $updated = false;
    $update_form_settings = function (&$elements) use (&$update_form_settings, $email_to_in, $email_subject_in, $email_reply_to_in, $redirect_to_in, &$updated) {
        foreach ($elements as &$el) {
            if (
                isset($el['elType'], $el['widgetType']) &&
                $el['elType'] === 'widget' &&
                $el['widgetType'] === 'form'
            ) {
                if (!isset($el['settings']) || !is_array($el['settings'])) {
                    $el['settings'] = [];
                }

                // Helper to check if a field is dynamic
                $is_dynamic = function($settings, $key) {
                    return !empty($settings['__dynamic__'][$key]);
                };

                // Update only if not dynamic
                if (!$is_dynamic($el['settings'], 'email_to')) {
                    $el['settings']['email_to'] = $email_to_in;
                }
                if (!$is_dynamic($el['settings'], 'email_subject')) {
                    $el['settings']['email_subject'] = $email_subject_in;
                }
                

                // // Reply-To logic
                // if ($email_reply_to_in === '[Email Field]') {
                //     $first_email_id = '';
                //     if (!empty($el['settings']['form_fields']) && is_array($el['settings']['form_fields'])) {
                //         foreach ($el['settings']['form_fields'] as $field) {
                //             if (isset($field['field_type']) && $field['field_type'] === 'email') {
                //                 $first_email_id = !empty($field['custom_id']) ? $field['custom_id'] : ($field['id'] ?? '');
                //                 break;
                //             }
                //         }
                //     }
                //     $el['settings']['email_reply_to'] = $first_email_id;
                // } elseif ($email_reply_to_in === '') {
                //     unset($el['settings']['email_reply_to']);
                // } else {
                //     $el['settings']['email_reply_to'] = $email_reply_to_in;
                // }

                $updated = true;
            }

            if (!empty($el['elements']) && is_array($el['elements'])) {
                $update_form_settings($el['elements']);
            }
            if (!empty($el['inner']) && is_array($el['inner'])) {
                $update_form_settings($el['inner']);
            }
        }
    };

    if (isset($content_array[0]) || empty($content_array['elements'])) {
        $update_form_settings($content_array);
    } else {
        $update_form_settings($content_array['elements']);
    }

    if (!$updated) {
        $debug['status'] = 'no_form_found';
        wp_send_json_error(['message' => 'No form widget found', 'debug' => $debug]);
    }

    // Save updated _elementor_data
    $encoded = wp_slash(wp_json_encode($content_array, JSON_UNESCAPED_UNICODE));
    update_post_meta($post_id, '_elementor_data', $encoded);

    $debug['status'] = 'updated_fields';
    wp_send_json_success(['message' => 'Form settings updated', 'debug' => $debug]);
}

























if (!function_exists('mt_decode_elementor_data')) {
    function mt_decode_elementor_data($post_id) {
        $debug = [
            'post_id' => $post_id,
        ];

        $raw = get_post_meta($post_id, '_elementor_data', true);
        $debug['raw_type']    = gettype($raw);
        $debug['raw_preview'] = is_string($raw) ? substr($raw, 0, 280) : $raw;

        if ($raw === '' || $raw === null) {
            $debug['reason'] = 'empty_meta';
            return [null, $debug];
        }

        // Already array
        if (is_array($raw)) {
            $debug['decode_path'] = 'already_array';
            return [$raw, $debug];
        }

        // Normalize string
        $unslashed = wp_unslash($raw);
        $debug['unslashed_preview'] = substr($unslashed, 0, 280);

        // Serialized?
        if (function_exists('is_serialized') && is_serialized($unslashed)) {
            $maybe = maybe_unserialize($unslashed);
            if (is_array($maybe)) {
                $debug['decode_path'] = 'unserialized_to_array';
                return [$maybe, $debug];
            }
            if (is_string($maybe)) {
                $decoded = json_decode($maybe, true);
                $debug['json_error_after_unserialize'] = json_last_error_msg();
                if (is_array($decoded)) {
                    $debug['decode_path'] = 'unserialized_to_string_then_json';
                    return [$decoded, $debug];
                }
                // fall through to other strategies
                $unslashed = $maybe;
            }
        }

        // Strategy A: plain json_decode on unslashed
        $decodedA = json_decode($unslashed, true);
        $debug['json_error_A'] = json_last_error_msg();
        if (is_array($decodedA)) {
            $debug['decode_path'] = 'json_decoded_unslashed';
            return [$decodedA, $debug];
        }

        // Strategy B: html_entity_decode (handles &quot; style content)
        $html_decoded = html_entity_decode($unslashed, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $decodedB = json_decode($html_decoded, true);
        $debug['json_error_B'] = json_last_error_msg();
        if (is_array($decodedB)) {
            $debug['decode_path'] = 'html_entity_decoded_then_json';
            return [$decodedB, $debug];
        }

        // Strategy C: strip control chars that can poison JSON
        $sanitized = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $unslashed);
        $decodedC = json_decode($sanitized, true);
        $debug['json_error_C'] = json_last_error_msg();
        if (is_array($decodedC)) {
            $debug['decode_path'] = 'control_chars_stripped_then_json';
            return [$decodedC, $debug];
        }

        // Strategy D: double-unescape backslashes (handles double-escaped storage)
        $double_unescaped = stripcslashes($unslashed);
        $decodedD = json_decode($double_unescaped, true);
        $debug['json_error_D'] = json_last_error_msg();
        if (is_array($decodedD)) {
            $debug['decode_path'] = 'stripcslashes_then_json';
            return [$decodedD, $debug];
        }

        // Couldn’t decode
        $debug['decode_path'] = 'failed_all_strategies';
        $debug['final_preview'] = substr($unslashed, 0, 280);
        return [null, $debug];
    }
}



add_action('wp_ajax_mt_bulk_update_forms', 'mt_bulk_update_forms');

function mt_bulk_update_forms() {
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(['message' => 'Permission denied']);
    }
    if (!check_ajax_referer('mt_save_form_settings', '_ajax_nonce', false)) {
        wp_send_json_error(['message' => 'Security check failed']);
    }

    $redirect_page_id = isset($_POST['redirect_page_id']) ? (int) $_POST['redirect_page_id'] : 0;
    if ($redirect_page_id <= 0) {
        wp_send_json_error(['message' => 'Invalid redirect page']);
    }

    $forms = mt_get_elementor_forms();
    $updated_count = 0;

    foreach ($forms as $form) {
        $post_id = $form['id'];
        $raw = get_post_meta($post_id, '_elementor_data', true);
        if (is_array($raw)) {
            $content_array = $raw;
        } elseif (is_string($raw)) {
            $content_array = json_decode($raw, true);
            if (!is_array($content_array)) {
                $content_array = json_decode(wp_unslash($raw), true);
            }
        } else {
            continue;
        }
        if (!is_array($content_array)) continue;

        $update_form_settings = function (&$elements) use (&$update_form_settings, $redirect_page_id, &$updated_count) {
            foreach ($elements as &$el) {
                if (
                    isset($el['elType'], $el['widgetType']) &&
                    $el['elType'] === 'widget' &&
                    $el['widgetType'] === 'form'
                ) {
                    if (!isset($el['settings']) || !is_array($el['settings'])) {
                        $el['settings'] = [];
                    }

                    // Set Reply-To to first email field
                    $first_email_id = '';
                    if (!empty($el['settings']['form_fields']) && is_array($el['settings']['form_fields'])) {
                        foreach ($el['settings']['form_fields'] as $field) {
                            if (isset($field['field_type']) && $field['field_type'] === 'email') {
                                $first_email_id = !empty($field['custom_id']) ? $field['custom_id'] : ($field['id'] ?? '');
                                break;
                            }
                        }
                    }
                    $el['settings']['email_reply_to'] = $first_email_id;

                    // Ensure redirect action is in submit_actions
                    if (empty($el['settings']['submit_actions']) || !in_array('redirect', $el['settings']['submit_actions'], true)) {
                        $el['settings']['submit_actions'][] = 'redirect';
                    }

                    // Prepare dynamic tag for redirect_to
                    $dynamic_tag = '[elementor-tag id="' . uniqid() . '" name="internal-url" settings="' .
                        rawurlencode(json_encode(['type' => 'post', 'post_id' => (string)$redirect_page_id])) . '"]';

                    // Set redirect_to in both static and __dynamic__
                    $el['settings']['redirect_to'] = $dynamic_tag;
                    if (!isset($el['settings']['__dynamic__']) || !is_array($el['settings']['__dynamic__'])) {
                        $el['settings']['__dynamic__'] = [];
                    }
                    $el['settings']['__dynamic__']['redirect_to'] = $dynamic_tag;

                    $updated_count++;
                }

                if (!empty($el['elements']) && is_array($el['elements'])) {
                    $update_form_settings($el['elements']);
                }
                if (!empty($el['inner']) && is_array($el['inner'])) {
                    $update_form_settings($el['inner']);
                }
            }
        };

        if (isset($content_array[0]) || empty($content_array['elements'])) {
            $update_form_settings($content_array);
        } else {
            $update_form_settings($content_array['elements']);
        }

        update_post_meta($post_id, '_elementor_data', wp_slash(wp_json_encode($content_array, JSON_UNESCAPED_UNICODE)));
    }

    wp_send_json_success(['message' => "Updated {$updated_count} forms"]);
}








function get_elementor_forms_count() {
    $forms = mt_get_elementor_forms();
    return is_array($forms) ? count($forms) : 0;
}