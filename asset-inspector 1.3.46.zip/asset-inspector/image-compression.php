<?php

function audit_attachment_compression($id, string $field = 'status') {
    $image_path = get_attached_file($id);

    if (!$image_path || !file_exists($image_path)) {
        return $field === 'status' ? 'missing' : null;
    }

    [$width, $height, $type] = getimagesize($image_path);
    $size_bytes = filesize($image_path);
    $estimated_raw_size = $width * $height * 3;

    $compression_ratio = $size_bytes / $estimated_raw_size;
    $exif = @exif_read_data($image_path);
    $compression_tag = $exif['Compression'] ?? null;

    $status = match (true) {
        $compression_ratio < 0.1 => 'aggressively compressed',
        $compression_ratio < 0.5 => 'compressed',
        $compression_ratio >= 0.9 => 'likely raw',
        default => 'semi compressed',
    };

    $compression_level = match (true) {
        $compression_ratio >= 0.9 => 1,
        $compression_ratio >= 0.7 => 2,
        $compression_ratio >= 0.4 => 3,
        $compression_ratio >= 0.2 => 4,
        default => 5,
    };

    return match ($field) {
        'status' => $status,
        'compression_level' => $compression_level,
        'compression_ratio' => round($compression_ratio, 2),
        'exif_compression' => $compression_tag,
        'dimensions' => "{$width}x{$height}",
        'type' => image_type_to_mime_type($type),
        'file_size' => $size_bytes,
        default => null,
    };
}