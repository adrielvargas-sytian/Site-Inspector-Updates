<?php
add_action('init', function () {
    add_post_type_support('attachment', 'comments'); // already present
    add_post_type_support('attachment', 'trackbacks'); // optional
    add_post_type_support('attachment', 'custom-fields'); // optional
    add_post_type_support('attachment', 'trash'); // ✅ this ensures trash support
});


/**
 * Display the Trashed Attachments page in the admin area.
 *
 * @return void
 */


function ic_view_trashed_attachments() {
    $trashed = get_posts([
        'post_type'   => 'attachment',
        'post_status' => 'trash',
        'numberposts' => -1,
    ]);
    ?>
    <div class="wrap">
        <h1>Trashed Attachments</h1>
        <p>
            <a href="<?php echo admin_url('admin.php?page=image-link-checker'); ?>" class="button">← Back to Image Link Checker</a>
        </p>

        <?php if (empty($trashed)) : ?>
            <p>No attachments found in Trash.</p>
        </div>
        <?php return;
        endif; ?>

        <form method="post">
            <?php wp_nonce_field('ic_bulk_trash_action'); ?>
            <div style="margin-bottom:20px;">
                <button type="submit" name="ic_bulk_restore" class="button">Restore Selected</button>
                <button type="submit" name="ic_bulk_delete" class="button delete">Delete Selected Permanently</button>
                <button type="submit" name="ic_empty_trash" class="button delete" style="float:right;">Empty All Trash</button>
            </div>

            <table class="widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width:30px;"><input type="checkbox" id="ilc-select-all"></th>
                        <th>Preview</th>
                        <th>Title</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($trashed as $item) :
                        $thumb = wp_get_attachment_image($item->ID, 'thumbnail', false, ['style' => 'max-width:80px; height:auto;']);
                        $title = esc_html($item->post_title ?: '(No title)');
                        $restore_url = wp_nonce_url(admin_url('admin.php?page=trashed-attachments&ic_restore=' . $item->ID), 'ic_restore_' . $item->ID);
                        $delete_url  = wp_nonce_url(admin_url('admin.php?page=trashed-attachments&ic_delete=' . $item->ID), 'ic_delete_' . $item->ID);
                    ?>
                    <tr>
                        <td><input type="checkbox" name="selected_attachments[]" value="<?php echo esc_attr($item->ID); ?>"></td>
                        <td><?php echo $thumb; ?></td>
                        <td><?php echo $title; ?></td>
                        <td>
                            <a href="<?php echo esc_url($restore_url); ?>" class="button">Restore</a>
                            <a href="<?php echo esc_url($delete_url); ?>" class="button delete">Delete Permanently</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </form>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const selectAll = document.getElementById('ilc-select-all');
                const checkboxes = document.querySelectorAll("input[name='selected_attachments[]']");
                if (selectAll) {
                    selectAll.addEventListener('change', function () {
                        checkboxes.forEach(cb => cb.checked = this.checked);
                    });
                }
            });
        </script>
    </div>
    <?php
}

add_action('admin_init', function () {
    // Single Restore
    if (isset($_GET['ic_restore']) && current_user_can('delete_posts')) {
        $id = (int) $_GET['ic_restore'];
        if (check_admin_referer('ic_restore_' . $id)) {
            wp_untrash_post($id);
            wp_safe_redirect(admin_url('admin.php?page=trashed-attachments'));
            exit;
        }
    }

    // Single Delete
    if (isset($_GET['ic_delete']) && current_user_can('delete_posts')) {
        $id = (int) $_GET['ic_delete'];
        if (check_admin_referer('ic_delete_' . $id)) {
            wp_delete_attachment($id, true);
            wp_safe_redirect(admin_url('admin.php?page=trashed-attachments'));
            exit;
        }
    }

    // Bulk Restore/Delete/Empty
    if (isset($_POST['ic_bulk_restore']) || isset($_POST['ic_bulk_delete']) || isset($_POST['ic_empty_trash'])) {
        if (!check_admin_referer('ic_bulk_trash_action')) return;

        $selected = array_map('intval', $_POST['selected_attachments'] ?? []);

        if (isset($_POST['ic_bulk_restore'])) {
            foreach ($selected as $id) {
                wp_untrash_post($id);
            }
        }

        if (isset($_POST['ic_bulk_delete'])) {
            foreach ($selected as $id) {
                wp_delete_attachment($id, true);
            }
        }

        if (isset($_POST['ic_empty_trash'])) {
            $trashed = get_posts([
                'post_type'   => 'attachment',
                'post_status' => 'trash',
                'numberposts' => -1,
            ]);
            foreach ($trashed as $item) {
                wp_delete_attachment($item->ID, true);
            }
        }

        wp_safe_redirect(admin_url('admin.php?page=trashed-attachments'));
        exit;
    }
});
