<?php

function mt_settings_page() {
    echo '<div class="page-container" style="padding-right:20px">';
    echo "<h2>Meta Tags Settings</h2>";

    

    meta_css();

    
    
    //csv_file_upload_isset();
    save_meta_tags();

    

	// Immediately display the content table
	csv_prep_isset();

    
    echo '</div>';


    
}

function csv_file_generator(){
    // **Step 1: Generate and Download CSV File**
    echo "<h3>Generate and Download CSV File for Meta Tags</h3>"; // Revised heading
    echo '<form method="post">';
    echo '<p><input type="submit" name="download_csv" class="submit-btn" value="Generate and Download CSV"></p>';
    echo '</form>';

    // Check if the button was clicked
    
        csv_prep_isset(); // Call the function to generate and download the CSV
    
}


function meta_css(){
    // Add CSS styling globally
    ?><style>
    input[type="text"] {
        width: 100%;
    }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 16px; text-align: left; }
        th, td { padding: 10px; border: 1px solid #ddd; }
        .submit-btn, .copy-btn { padding: 10px 15px; background-color: #0073aa; color: #fff; border: none; border-radius: 5px; cursor: pointer; }
        .submit-btn:hover { background-color: #005a87; }
        .copy-btn,.save-btn { background-color: #28a745; }
        .copy-btn:hover,.save-btn:hover { background-color: #218838; }
        .error { color: red; font-weight: bold; }
        .csv-url {    display: none;}
        
	tr.row-error {
		background-color: #ffeded !important;
		border-left: 4px solid #cc0000;
	}


	.gem-status-icon {
	  font-weight: bold;
	  font-size: 16px;
	  display: inline-block;
	}

	.gem-status-icon.success {
	  color: #28a745;
	}

	.gem-status-icon.error {
	  color: #dc3545;
	}

	.gem-status-icon.skipped {
	  color: #888;
	}

	tr.row-error {
	  background-color: #ffe7e7;
	  border-left: 4px solid #cc0000;
	}

	#e-meta-footer-buttons {
        position: fixed;
        bottom: 0;
        left: 160px; /* Adjust based on sidebar width */
        right: 0;
        background: #fff;
        padding: 12px 24px;
        box-shadow: 0 -2px 6px rgba(0, 0, 0, 0.1);
        z-index: 9999;
        display: flex;
        justify-content: center;
        gap: 16px;
    }

	
    </style> 




    <?php
}

function csv_prep(){
    // **Step 3: List All Content & Copy for CSV Preparation**
    echo "<h3>Generate Content List for CSV Export</h3>"; // Revised heading
    echo '<form method="post">';
    echo '<p><input type="submit" name="list_content" class="submit-btn" value="List All Content"></p>';
    echo '</form>';
}

function csv_prep_isset() {
    if (isset($_POST['gem_bulk_save']) && is_array($_POST['primary_keyword'])) {
        foreach ($_POST['primary_keyword'] as $post_id => $primary) {
            $primary     = sanitize_text_field($primary);
            $additional  = sanitize_text_field($_POST['additional_keywords'][$post_id] ?? '');
            $description = sanitize_text_field($_POST['meta_description'][$post_id] ?? '');
			
			gem_save_meta_tags_for_post($post_id, $primary, $description, $additional);

//             update_post_meta($post_id, '_yoast_wpseo_focuskw', $primary);
//             update_post_meta($post_id, '_yoast_wpseo_multiple_focus_keywords', [['keyword' => $additional]]);
//             update_post_meta($post_id, '_yoast_wpseo_metadesc', $description);
        }
        echo '<div class="notice notice-success"><p>✅ All meta tags saved.</p></div>';
    }

    $encrypted_key = get_option('gen_ai_api_key');
    $api_key = decrypt_gen_ai_api_key($encrypted_key);

    // 1. Detect ACF-bound CPTs
    $acf_custom_post_types = [];
    $field_groups = function_exists('acf_get_field_groups') ? acf_get_field_groups() : [];

    foreach ($field_groups as $group) {
        if (!empty($group['location'])) {
            foreach ($group['location'] as $ruleGroup) {
                foreach ($ruleGroup as $rule) {
                    if ($rule['param'] === 'post_type' && $rule['operator'] === '==') {
                        $acf_custom_post_types[] = $rule['value'];
                    }
                }
            }
        }
    }

    $all_types = array_unique(array_merge(['post', 'page'], $acf_custom_post_types));
    
    $selected_type = $_GET['gem_post_type'] ?? '';
    $post_types = $selected_type ? [$selected_type] : $all_types;

    $selected_types = isset($_GET['gem_post_type']) ? [sanitize_text_field($_GET['gem_post_type'])] : $all_types;

    if (!is_array($selected_types)) $selected_types = [$selected_types];
?>
    <div style="display: flex; justify-content: space-between; align-items: center; margin: 10px 0;">
        <form method="get">
            <input type="hidden" name="page" value="e-meta_tags">
            <select name="gem_post_type" id="gem_post_type" style="margin-right:10px;">
            <option value="">All Posts/Pages</option>
            <?php 
            foreach ($all_types as $type) {
            $obj = get_post_type_object($type);
            if (!$obj) continue;
            $selected = ($_GET['gem_post_type'] ?? '') === $type ? 'selected' : '';
            echo "<option value='{$type}' {$selected}>" . esc_html($obj->labels->name) . '</option>';

            }
            ?>
            </select>
            <button type="submit" class="button">Filter</button>
        </form>
        <div>
        <?php
        if ($api_key) {
            // Non-submit buttons
            echo '<button id="gem-generate-all" type="button" class="button">Generate Meta Tags</button>';
        }else{
            //add link to gemini settings page
            echo '<p class="error">❌ Gemini API key is missing. <a href="' . esc_url(admin_url('admin.php?page=gemini-settings')) . '">Gemini Settings</a></p>';
        }
?>
        </div>
    </div>
<?php
    // echo '<form method="get" style="margin-bottom: 1em;">';
    // echo '<input type="hidden" name="page" value="e-meta_tags">';
    // echo '<select name="gem_post_type" id="gem_post_type" style="margin-right:10px;">';
    // echo '<option value="">All Posts/Pages</option>';
    // foreach ($all_types as $type) {
    // $obj = get_post_type_object($type);
    // if (!$obj) continue;
    // $selected = ($_GET['gem_post_type'] ?? '') === $type ? 'selected' : '';
    // echo "<option value='{$type}' {$selected}>" . esc_html($obj->labels->name) . '</option>';
    // }
    // echo '</select>';
    // echo '<button type="submit" class="button">Filter</button>';
    // echo '</form>';


    
    $query_args = [
        'post_type'      => $post_types,
        'posts_per_page' => -1,
        'post_status'    => 'publish'
    ];

    $all_posts = get_posts($query_args);
    if (!$all_posts) {
        echo "<p>No posts found.</p>";
        return;
    }


    

    

    

    echo '<div id="gem-progress-wrapper" style="margin: 1em 0; display: none;">
        <div style="height: 8px; background: #eee; width: 100%; border-radius: 4px;">
            <div id="gem-progress-bar" style="height: 100%; width: 0%; background: #0073aa; transition: width 0.3s ease; border-radius: 4px;"></div>
        </div>
        <small id="gem-progress-label" style="display: block; margin-top: 4px; color: #555;">Starting...</small>
		<div style="margin-top: -0.5em; color: #666; font-size: 13px;">
    ⚠️ Generating tags one-by-one (every 3 seconds) to stay within Gemini’s safe usage thresholds.
</div>

    </div>';

    // echo '<p id="gem-status-download-wrap" style="display: none;">
    //     <button id="gem-status-download" type="button" class="button">📥 Download Tag Report</button>
    // </p>';

    echo '<p style="margin-top: 10px;">
        <button id="gem-stop-generation" type="button" class="button button-secondary" style="display: none;">Stop Generating</button>
    </p>';

    echo '<p style="margin-top: 10px; display:none;">
        <button id="gem-clear-tags" type="button" class="button button-secondary">Clear All Tags</button>
    </p>';

    // Start bulk save form
    echo '<form method="post" id="gem-save-all-form">';
    echo '<input type="hidden" name="gem_bulk_save" value="1">';
    echo '<table id="contentTable" class="wp-list-table widefat fixed striped">';
    ?>
    <thead>
        <th width="70" class="e-meta-exportable">Post ID</th>
        <th class="e-meta-exportable">Title</th>
        <th class="csv-url e-meta-exportable">Link</th>
        <th width="120" class="e-meta-exportable">Post Type</th>
        <th class="e-meta-exportable">Primary Keyword</th>
        <th class="e-meta-exportable">Additional Keywords</th>
        <th class="e-meta-exportable" width="300">Meta Description</th>
        
        <?php if ($api_key) { echo '<th width="150">Actions</th>'; } ?>
    </tr>
</thead>
<tbody>
    <?php

    foreach ($all_posts as $post) {
        $post_id    = $post->ID;
        $title      = get_the_title($post_id);
        $link       = get_permalink($post_id);
        $type       = get_post_type($post_id);
        $primary    = get_post_meta($post_id, '_yoast_wpseo_focuskw', true);
        $additional = get_post_meta($post_id, '_yoast_wpseo_multiple_focus_keywords', true);
        $meta_desc  = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);

        $additional_list = is_array($additional) ? array_column($additional, 'keyword') : [];
        $keyword_string  = implode(', ', $additional_list);

        echo '<tr>';
        echo '<td class="e-meta-exportable">' . esc_html($post_id) . '</td>';
        echo '<td class="e-meta-exportable">' . esc_html($title) . '</td>';
        echo '<td class="csv-url e-meta-exportable"><a href="' . esc_url($link) . '" target="_blank">' . esc_html($link) . '</a></td>';
        echo '<td class="e-meta-exportable">' . esc_html($type) . '</td>';
        echo '<td class="e-meta-exportable"><input type="text" name="primary_keyword[' . esc_attr($post_id) . ']" class="gem-primary" data-id="' . esc_attr($post_id) . '" value="' . esc_attr($primary) . '"></td>';
        echo '<td class="e-meta-exportable"><input type="text" name="additional_keywords[' . esc_attr($post_id) . ']" class="gem-additional" data-id="' . esc_attr($post_id) . '" value="' . esc_attr($keyword_string) . '"></td>';
        echo '<td class="e-meta-exportable"><textarea name="meta_description[' . esc_attr($post_id) . ']" class="gem-description" data-id="' . esc_attr($post_id) . '" rows="2" style="width:100%;">' . esc_textarea($meta_desc) . '</textarea></td>';

        if ($api_key) {
            echo '<td>
                <button type="button" class="generate-tags-btn button" data-post="' . esc_attr($post_id) . '">Generate</button>
                <button type="button" class="gem-save-row" data-post="' . esc_attr($post_id) . '">💾</button>
            </td>';

            
        }
        
        echo '</tr>';
		
    }
?>
</tbody>
<tfoot>
<th width="70" class="e-meta-exportable">Post ID</th>
        <th class="e-meta-exportable">Title</th>
        <th class="csv-url e-meta-exportable">Link</th>
        <th width="120" class="e-meta-exportable">Post Type</th>
        <th class="e-meta-exportable">Primary Keyword</th>
        <th class="e-meta-exportable">Additional Keywords</th>
        <th class="e-meta-exportable" width="300">Meta Description</th>
        
        <?php if ($api_key) { echo '<th width="150">Actions</th>'; } ?>
    </tr>
</tfoot>
  </table>
   
  
<div id="e-meta-footer-buttons">
  <button type="submit" id="gem-save-all" class="button button-primary">Save All Changes</button>
  <button type="button" class="copy-btn" onclick="copyTable()">Download CSV</button>
  
</div>

    <?php
    echo '</form>';

    

    //gem_render_debug_panel();

    // 7. JS for CSV copying
    ?>
    <script>
		function copyTable() {
            const table = document.getElementById("contentTable");
            const rows = table.rows;
            let csvContent = "data:text/csv;charset=utf-8,";

            // Extract headers only from exportable columns
            const exportableIndexes = [];
            const headers = Array.from(rows[0].cells).map((cell, index) => {
                if (cell.classList.contains("e-meta-exportable")) {
                exportableIndexes.push(index);
                return cell.innerText.trim();
                }
                return null;
            }).filter(Boolean);

            csvContent += headers.join(",") + "\n";

            // Extract only exportable data
            for (let i = 1; i < rows.length; i++) {
                const cells = rows[i].cells;
                const rowData = exportableIndexes.map(j => {
                const cell = cells[j];
                const input = cell.querySelector("input, textarea");
                let val = input ? input.value.trim() : cell.innerText.trim();

                if (val.includes(",") || val.includes('"')) {
                    val = '"' + val.replace(/"/g, '""') + '"';
                }

                return val;
                });

                csvContent += rowData.join(",") + "\n";
            }

            const link = document.createElement("a");
            link.href = encodeURI(csvContent);
            link.download = "meta_export_" + new Date().toISOString().slice(0, 19).replace("T", "_").replace(/:/g, "-") + ".csv";
            document.body.appendChild(link);
            link.click();
            }


    </script>
    <?php
}



function csv_prep_isset_download_csv(){
    if (isset($_POST['get_data'])) {
        // Completely remove any previous output
        ob_end_clean();
        
        // Ensure headers are correctly set for pure CSV output
        header("Content-Type: text/csv; charset=UTF-8");
        header("Content-Disposition: attachment; filename=\"meta_tags_export.csv\"");
        header("Pragma: no-cache");
        header("Expires: 0");

        // Open file output stream
        $output = fopen('php://output', 'w');

        // Write column headers
        fputcsv($output, ["Post ID", "Title", "Link", "Post Type", "Meta Keywords", "Meta Description"]);

        // Retrieve data from ACF and post types
        $acf_custom_post_types = [];
        $field_groups = acf_get_field_groups();
        foreach ($field_groups as $group) {
            if (!empty($group['location'])) {
                foreach ($group['location'] as $ruleGroup) {
                    foreach ($ruleGroup as $rule) {
                        if ($rule['param'] === 'post_type' && $rule['operator'] === '==') {
                            $acf_custom_post_types[] = $rule['value'];
                        }
                    }
                }
            }
        }

        // Query posts
        $post_types = array_merge(["post", "page"], $acf_custom_post_types);
        $query_args = [
            "post_type" => $post_types,
            "posts_per_page" => -1
        ];
        $all_posts = get_posts($query_args);

        // Write post data while forcing clean text output
        foreach ($all_posts as $post) {
            fputcsv($output, [
                strip_tags($post->ID),
                strip_tags(html_entity_decode(get_the_title($post->ID))),
                strip_tags(html_entity_decode(get_permalink($post->ID))),
                strip_tags(html_entity_decode(get_post_type($post->ID))),
                strip_tags(html_entity_decode(get_field("meta_keywords", $post->ID) ?: '')),
                strip_tags(html_entity_decode(get_field("meta_description", $post->ID) ?: ''))
            ]);
        }

        // Close file stream and flush output buffer
        fclose($output);
        ob_flush();
        exit;
    }
}














function csv_file_upload_isset() {
    if (
        isset($_POST['upload_csv']) &&
        isset($_FILES['csv_file']) &&
        $_FILES['csv_file']['error'] === UPLOAD_ERR_OK
    ) {
        $file = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($file, "r")) !== false) {
            $headers = fgetcsv($handle);
            $headers_lower = array_map('strtolower', $headers);

            $id_index = array_search("post id", $headers_lower);
            $primary_index = array_search("primary keyword", $headers_lower);
            $additional_index = array_search("additional keywords", $headers_lower);
            $description_index = array_search("meta description", $headers_lower);
            $link_index = array_search("link", $headers_lower);

            if (
                $id_index === false ||
                $primary_index === false ||
                $additional_index === false ||
                $description_index === false
            ) {
                echo "<p class='error'>CSV format error: Missing required columns: 'Post ID', 'Primary Keyword', 'Additional Keywords', or 'Meta Description'.</p>";
                return;
            }

            echo '<form method="post">';
            echo '<h3>Review & Edit CSV Data Before Saving</h3>';
            echo '<p><input type="submit" name="save_meta_tags" class="submit-btn save-btn" value="Save Meta Tags"> <input type="submit" name="go_home" class="submit-btn" value="Home"></p>';
            echo '<table id="contentTable" class="wp-list-table widefat fixed striped"><tr>';

            foreach ($headers as $header) {
                $normalized = strtolower($header);
                $attrs = '';
                if ($normalized === "title") $attrs = ' width="200"';
                elseif ($normalized === "post id") $attrs = ' width="70"';
                elseif ($normalized === "post type") $attrs = ' width="120"';
                elseif ($normalized === "link") $attrs = ' style="display:none"';
                echo '<th' . $attrs . '>' . esc_html($header) . '</th>';
            }

            echo '</tr>';

            while (($data = fgetcsv($handle)) !== false) {
                $post_id = $data[$id_index];
                if (!is_numeric($post_id)) continue;

				//new meta tags from csv
                $meta_primary     = trim($data[$primary_index]);
				$meta_additional  = trim($data[$additional_index]);
				$meta_description = $data[$description_index];


                // Flatten existing additional if blank
                $meta_additional = trim($data[$additional_index]);
                if (empty($meta_additional) && is_array($existing_additional)) {
                    $meta_additional = implode(', ', array_column($existing_additional, 'keyword'));
                }

                echo '<tr>';
                foreach ($data as $index => $value) {
                    $value = trim($value);
                    if ($index == $id_index) {
                        echo '<td><input type="text" name="post_id[]" value="' . esc_attr($post_id) . '" readonly></td>';
                    } elseif ($index == $primary_index) {
                        echo '<td><input type="text" name="meta_keywords[]" value="' . esc_attr($meta_primary) . '" placeholder="Enter primary keyword"></td>';
                    } elseif ($index == $additional_index) {
                        echo '<td><input type="text" name="meta_additional[]" value="' . esc_attr($meta_additional) . '" placeholder="Comma-separated additional keywords"></td>';
                    } elseif ($index == $description_index) {
                        echo '<td><input type="text" name="meta_description[]" value="'.$data[$description_index].'" placeholder="Enter meta description"></td>';
                    } else {
                        echo '<td ' . ($index == $link_index ? 'style="display:none"' : '') . '>' . esc_html($value) . '</td>';
                    }
                }
                echo '</tr>';
            }

            echo '</table>';
            echo '<p><input type="submit" name="save_meta_tags" class="submit-btn save-btn" value="Save Meta Tags"> <input type="submit" name="go_home" class="submit-btn" value="Home"></p>';
            echo '</form>';

            fclose($handle);
        } else {
            echo "<p class='error'>Error opening CSV file.</p>";
        }
    }
}
  
function save_meta_tags() {
    if (isset($_POST['save_meta_tags'])) {
        if (!empty($_POST['meta_keywords']) && !empty($_POST['post_id'])) {
            foreach ($_POST['post_id'] as $index => $post_id) {
                $primary_keyword     = $_POST['meta_keywords'][$index] ?? '';
                $meta_description    = $_POST['meta_description'][$index] ?? '';
                $additional_keywords = $_POST['meta_additional'][$index] ?? '';

                gem_save_meta_tags_for_post($post_id, $primary_keyword, $meta_description, $additional_keywords);
            }
            echo "<p>✅ Meta tags updated successfully to Yoast SEO!</p>";
        } else {
            echo "<p class='error'>❌ Error: Missing data. Ensure all fields are correctly populated.</p>";
        }
    }
}
add_action('wp_ajax_gem_save_row_tags', function () {
    $post_id     = intval($_POST['post_id'] ?? 0);
    $primary     = sanitize_text_field($_POST['primary'] ?? '');
    $desc        = sanitize_text_field($_POST['description'] ?? '');
    $additional  = sanitize_text_field($_POST['additional_keywords'] ?? '');

    gem_save_meta_tags_for_post($post_id, $primary, $desc, $additional);

    wp_send_json_success(['message' => 'Saved']);
});

// function save_meta_tags() {
//     if (isset($_POST['save_meta_tags'])) {
//         if (!empty($_POST['meta_keywords']) && !empty($_POST['post_id'])) {
//             foreach ($_POST['post_id'] as $index => $post_id) {
//                 if (!is_numeric($post_id)) continue;

//                 $primary_keyword     = sanitize_text_field($_POST['meta_keywords'][$index]);
//                 $meta_description    = sanitize_text_field($_POST['meta_description'][$index]);
//                 $additional_keywords = isset($_POST['meta_additional'][$index])
//                     ? sanitize_text_field($_POST['meta_additional'][$index])
//                     : '';

//                 // Save Primary Keyword
//                 update_post_meta($post_id, '_yoast_wpseo_focuskw', $primary_keyword);

//                 // Save Meta Description
//                 update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_description);

//                 // Prepare and save Additional Keywords if present
//                 $keywords_array = array_filter(array_map('trim', explode(',', $additional_keywords)));

//                 $serialized = [];
//                 $scored     = [];

//                 foreach ($keywords_array as $keyword) {
//                     $serialized[] = [
//                         'keyword'   => $keyword,
//                         'synonyms' => [],
//                         'modifiers'=> [],
//                         'links'    => []
//                     ];
//                     $scored[] = [
//                         'keyword' => $keyword,
//                         'score'   => 0
//                     ];
//                 }

//                 update_post_meta($post_id, '_yoast_wpseo_multiple_focus_keywords', $serialized);
//                 update_post_meta($post_id, '_yoast_wpseo_focuskeywords', wp_json_encode($scored));
//             }

//             echo "<p>✅ Meta tags updated successfully to Yoast SEO!</p>";
//         } else {
//             echo "<p class='error'>❌ Error: Missing data. Ensure all fields are correctly populated.</p>";
//         }
//     }
// }




// //add meta tags to the page
// function add_dynamic_meta_tags() {
//     global $post;

//     // Determine the correct page ID
//     if (is_singular()) {
//         $page_id = $post->ID; // Single post or page
//     } elseif (is_home()) { 
//         $page_id = get_option('page_for_posts'); // Post archive page
//     } elseif (is_post_type_archive('post')) { 
//         $page_id = get_option('page_for_posts'); // Archive page for posts
//     } else {
//         return; // Exit if not a valid page/post
//     }

//     // Retrieve meta keywords and description from ACF fields
//     $acf_keywords = function_exists('get_field') ? get_field('meta_keywords', $page_id) : '';
//     $acf_description = function_exists('get_field') ? get_field('meta_description', $page_id) : '';

//     // Check if Yoast SEO has already set a meta description
//     $yoast_description = get_post_meta($page_id, '_yoast_wpseo_metadesc', true);

//     // Output meta keywords if available
//     if (!empty($acf_keywords)) {
// 		 echo "<!-- Dynamic Meta Keywords -->\n";
//         echo '<meta name="keywords" content="' . esc_attr($acf_keywords) . '" />' . "\n";
//     }

//     // Output meta description only if Yoast hasn't set one
//     if (empty($yoast_description) && !empty($acf_description)) {
// 		echo "<!-- Dynamic Meta Description -->\n";
//         echo '<meta name="description" content="' . esc_attr($acf_description) . '" />' . "\n";
//     }
// }
// add_action('wp_head', 'add_dynamic_meta_tags');




add_action('wp_ajax_gem_save_meta_tags', 'gem_save_meta_tags_handler');



function gem_save_meta_tags_handler() {
    check_ajax_referer('gca_meta_tags_nonce', 'nonce');

    $post_id = intval($_POST['post_id']);
    $primary = sanitize_text_field($_POST['primary_keyword'] ?? '');
    $additional = sanitize_text_field($_POST['additional_keywords'] ?? '');
    $description = sanitize_text_field($_POST['meta_description'] ?? '');

    if (!$post_id) {
        wp_send_json_error(['message' => 'Missing Post ID']);
    }

    update_post_meta($post_id, '_yoast_wpseo_focuskw', $primary);
    update_post_meta($post_id, '_yoast_wpseo_multiple_focus_keywords', [['keyword' => $additional]]);
    update_post_meta($post_id, '_yoast_wpseo_metadesc', $description);

    wp_send_json_success(['message' => 'Tags saved']);
	
	
}


function gem_render_debug_panel() {
    if ( ! current_user_can('manage_options') ) return;

    $logs = get_transient('gem_ai_debug_logs');
    if ( ! $logs || ! is_array($logs) ) return;

    echo '<div style="margin-top:2em; background:#fefefe; border:1px solid #ccc; padding:1em;">';
    echo '<h3 style="margin-top:0;">🧠 Gemini Debug Panel</h3>';
    echo '<pre style="white-space:pre-wrap; max-height:300px; overflow:auto; font-size:13px; background:#f8f8f8; padding:10px; border:1px dashed #ccc;">';
    foreach ( $logs as $line ) {
        echo esc_html($line) . "\n";
    }
    echo '</pre></div>';
}





