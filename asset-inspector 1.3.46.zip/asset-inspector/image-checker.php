<?php
function ic_enqueue_styles()
{
    wp_enqueue_style('image-link-checker', plugin_dir_url(__FILE__) . 'assets/css/image-link-checker.css');
}
add_action('admin_enqueue_scripts', 'ic_enqueue_styles');




function ic_settings_page_old() {
    // Handle deletion requests
    if (isset($_POST['delete_selected']) && !empty($_POST['selected_attachments'])) {
        ic_delete_selected_attachments($_POST['selected_attachments']);
    }

    if (isset($_POST['delete_unused'])) {
        ic_delete_unused_attachments();
    }

    // Fetch scan data
    $data = ic_check_image_links_data();
    $status_filter = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : '';

    // Count totals
    $total = count($data);
    $used = count(
		array_filter(
			$data,
			function ( $img ) {
				return isset( $img['status'] ) && $img['status'] === 'Used';
			}
		)
	);

    $unused = $total - $used;

   
    ?>
    <div class="wrap image-link-checker">
        <h1>Image Checker</h1>

        <div style="margin: 10px 0 20px;">
            <strong>Total images:</strong> <?= $total ?> |
            <span style="color: green;"><strong>Used:</strong> <?= $used ?></span> |
            <span style="color: red;"><strong>Unused:</strong> <?= $unused ?></span>
        </div>

        <form method="GET" style="margin-bottom: 20px;">
            <input type="hidden" name="page" value="image-link-checker" />
            <label for="status_filter">Filter by Status: </label>
            <select name="status_filter" id="status_filter">
                <option value="">All</option>
                <option value="Unused" <?= $status_filter === 'Unused' ? 'selected' : '' ?>>Unused</option>
                <option value="Used" <?= $status_filter === 'Used' ? 'selected' : '' ?>>Used</option>
            </select>
            <button type="submit">Filter</button>
        </form>

        <?php
        $trashed = get_posts([
            'post_type'      => 'attachment',
            'post_status'    => 'trash',
            'numberposts'    => -1
        ]);

        if (!empty($trashed)) {
    echo '<div style="margin-top: 10px;">
            <a href="' . admin_url('admin.php?page=trashed-attachments') . '" class="button" style="background-color: #555; color: #fff;">
                View Trashed Attachments
            </a>
        </div>';
        }
        ?>

        <form method="POST">
            <table class="asset-scanner-table wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th class="check-column"><label><input type="checkbox" id="select_all" /></label></th>
                        <th style="width: 30px;">ID</th>
                        <th style="width: 60px;">Preview</th>
                        <th>Title</th>
                        <th style="width: 140px;">Type</th>
                        <th style="width: 60px;">Format</th>
                        <th style="width: 60px;">Status</th>
                        <!--<th style="width:90px;">Compression Status</th>-->
                        <th>Pages/Posts</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                if (!empty($data)) {
                    foreach ($data as $item) {
                        if ($status_filter && $item['status'] !== $status_filter) {
                            continue;
                        }

                        $pagesPostsRaw = isset( $item['pages_posts'] ) && is_array( $item['pages_posts'] ) ? $item['pages_posts'] : [];

                        $uniquePagesPosts = array_unique( array_map( 'serialize', $pagesPostsRaw ) );
                        $uniquePagesPosts = array_map( 'unserialize', $uniquePagesPosts );



                        /******************* C H E C K   S V G    */


                        $pagesPostsList = '<ul>';
                        foreach ($uniquePagesPosts as $page_post) {
                            
                            // Determine correct edit URL based on type
                            if (strpos($page_post['type'], 'taxonomy:') === 0) {
                                $taxonomy = str_replace('taxonomy:', '', $page_post['type']);
                                $editUrl = admin_url("edit-tags.php?action=edit&taxonomy={$taxonomy}&tag_ID={$page_post['id']}");
                            } elseif ($page_post['type'] === 'site' || $page_post['id'] === 0) {
                                $editUrl = ''; // Can't edit directly
                            } else {
                                $editUrl = admin_url('post.php?post=' . $page_post['id'] . '&action=edit');
                            }

                            
                            $displayText = $page_post['title'] . ' (' . $page_post['type'] . ' ID: ' . $page_post['id'] . ')';
                            if (isset($page_post['note'])) {
                                $displayText .= ' (' . $page_post['note'] . ')';
                            }

                            if ($editUrl) {
                                $pagesPostsList .= '<li><a href="' . esc_url($editUrl) . '" target="_blank">' . esc_html($displayText) . '</a></li>';
                            } else {
                                $pagesPostsList .= '<li>' . esc_html($displayText) . '</li>';
                            }

                            
                        }
                        $pagesPostsList .= '</ul>';

                        $status   = isset($item['status']) ? $item['status'] : '';
                        $id       = isset($item['id']) ? $item['id'] : 0;
                        $type     = isset($item['type']) ? $item['type'] : '';
                        $format   = isset($item['format']) ? $item['format'] : '';
                        $statusStyle = $status === 'Unused' ? 'color: red;' : '';
                        
                        $thumbnail = isset($item['thumbnail_url']) ? $item['thumbnail_url'] : '';
                        $title = isset($item['title']) ? $item['title'] : '';

                        $previewImage = $thumbnail
                            ? '<a href="' . esc_url(admin_url('upload.php?item=' . $id)) . '" target="_blank"><img src="' . esc_url($thumbnail) . '" alt="' . esc_attr($title) . '" width="50"></a>'
                            : 'No Image';

                    $titleLink = '<a href="' . esc_url(admin_url('upload.php?item=' . $id)) . '" target="_blank">' . esc_html($title) . '</a>';

                ?>
                    <tr>

                        <?php if ($status === 'Unused') :
                            ?>
                        <td class="check-column">
                            <label><input type="checkbox" name="selected_attachments[]"
                                    value="<?= esc_attr($id) ?>" /></label>
                        </td>
                        <?php else : ?>
                        <td class="check-column"></td>
                        <?php endif; ?>

                        <td><?= esc_html($id) ?></td>
                        <td><?= $previewImage ?></td>
                        <td><?= $titleLink ?></td>
                        <td><?= esc_html($type) ?></td>
                        <td><?= esc_html($format) ?></td>
                        <td class="status-column" style="<?= esc_attr($statusStyle) ?>"><?= esc_html($status) ?></td>
                        <?php /*<td><?= audit_attachment_compression($item['id'],'compression_level')?></td>*/?>
                        <td><?= $pagesPostsList ?></td>

                    </tr>
                    <?php
                    }
                } else {
                    echo '<tr><td colspan="8">No data available.</td></tr>';
                }
                ?>
                </tbody>
            </table>

            <div id="ilc-footer-buttons">
                <div>
                    <button type="submit" name="delete_selected" class="button button-primary">Delete Selected
                        Attachments</button>
                    <button type="submit" name="delete_unused" class="button button-secondary">Delete All Unused
                        Attachments</button>
                </div>
                <div id="ilc-selected-count" style="margin-left: 20px; font-weight: bold;"></div>

            </div>

            <script>
            const selectedCounter = document.getElementById("ilc-selected-count");
            const checkboxes = document.querySelectorAll("input[name='selected_attachments[]']");
            checkboxes.forEach(cb => {
                cb.addEventListener("change", updateSelectedCount);
            });

            function updateSelectedCount() {
                const count = document.querySelectorAll("input[name='selected_attachments[]']:checked").length;
                selectedCounter.textContent = count > 0 ? `${count} image(s) selected` : '';
            }
            </script>



        </form>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const selectAllCheckbox = document.getElementById("select_all");
        const checkboxes = document.querySelectorAll("input[name='selected_attachments[]']");
        const selectedCounter = document.getElementById("ilc-selected-count");

        // 🔄 Update selected image count display
        function updateSelectedCount() {
            const count = document.querySelectorAll("input[name='selected_attachments[]']:checked").length;
            selectedCounter.textContent = count > 0 ? `${count} image(s) selected` : '';
        }

        // Bind checkbox change events
        checkboxes.forEach(cb => cb.addEventListener("change", updateSelectedCount));

        // Handle "Select All" toggle
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener("change", function() {
                const isChecked = this.checked;
                checkboxes.forEach(cb => cb.checked = isChecked);
                updateSelectedCount();
            });
        }

        // 🗑 Confirm dialog for "Delete Selected"
        const deleteSelectedButton = document.querySelector("button[name='delete_selected']");
        if (deleteSelectedButton) {
            deleteSelectedButton.addEventListener("click", function(event) {
                const selectedCount = document.querySelectorAll(
                    "input[name='selected_attachments[]']:checked").length;
                if (selectedCount === 0) {
                    alert("Please select at least one attachment to move to Trash.");
                    event.preventDefault();
                    return;
                }

                const message =
                    `Move ${selectedCount} selected attachment(s) to Trash?\nYou can restore them later from the Media Library.`;
                if (!confirm(message)) {
                    event.preventDefault();
                }
            });
        }

        // 🧹 Confirm dialog for "Delete All Unused"
        const deleteUnusedButton = document.querySelector("button[name='delete_unused']");
        if (deleteUnusedButton) {
            deleteUnusedButton.addEventListener("click", function(event) {
                const message =
                    "Move all unused attachments to Trash?\nYou can restore them later from Media > Trash.";
                if (!confirm(message)) {
                    event.preventDefault();
                }
            });
        }
    });
    </script>


<?php
}



function ic_list_acf_fields_and_used_images() {
    global $wpdb;

    // **1️⃣ Get all ACF Field Groups**
    $acf_field_groups = acf_get_field_groups();
    $acf_image_fields = [];

    // **2️⃣ Extract Image & Gallery Fields from Field Groups**
    foreach ($acf_field_groups as $group) {
        $fields = acf_get_fields($group['key']);
        if (!$fields) continue;

        foreach ($fields as $field) {
            if (isset($field['type']) && ($field['type'] === 'image' || $field['type'] === 'gallery')) {
                $acf_image_fields[$field['name']] = [
                    'label' => $field['label'],
                    'type' => $field['type']
                ];
            }
        }
    }

    // **3️⃣ Loop Through Posts & Retrieve Images Used**
    $post_types = get_post_types(['public' => true], 'names');
    $post_types_list = "'" . implode("','", $post_types) . "'";
    $query = "
        SELECT ID, post_title, post_type FROM {$wpdb->posts} 
        WHERE post_type IN ($post_types_list) 
        AND post_status = 'publish'
    ";
    $posts = $wpdb->get_results($query);
    $acf_images_used = [];

    foreach ($posts as $post) {
        if (function_exists('get_fields')) {
            $acf_fields = get_fields($post->ID);
            if (!$acf_fields) continue;

            foreach ($acf_image_fields as $field_name => $field_info) {
                if (isset($acf_fields[$field_name])) {
                    $field_value = $acf_fields[$field_name];

                    if (!isset($acf_images_used[$field_name])) {
                        $acf_images_used[$field_name] = [
                            'label' => $field_info['label'],
                            'type' => $field_info['type'],
                            'images' => []
                        ];
                    }

                    // **Handle Single Image Field**
                    if ($field_info['type'] === 'image' && is_numeric($field_value) && get_post_mime_type($field_value)) {
                        $acf_images_used[$field_name]['images'][] = [
                            'id' => $field_value,
                            'url' => wp_get_attachment_url($field_value),
                            'title' => get_the_title($field_value),
                            'used_in' => [
                                'title' => $post->post_title,
                                'id' => $post->ID,
                                'type' => $post->post_type
                            ]
                        ];
                    }

                    // **Handle Gallery Field (Multiple Images)**
                    elseif ($field_info['type'] === 'gallery' && is_array($field_value)) {
                        foreach ($field_value as $gallery_image) {
                            if (is_numeric($gallery_image) && get_post_mime_type($gallery_image)) {
                                $acf_images_used[$field_name]['images'][] = [
                                    'id' => $gallery_image,
                                    'url' => wp_get_attachment_url($gallery_image),
                                    'title' => get_the_title($gallery_image),
                                    'used_in' => [
                                        'title' => $post->post_title,
                                        'id' => $post->ID,
                                        'type' => $post->post_type
                                    ]
                                ];
                            }
                        }
                    }
                }
            }
        }
    }

    // **4️⃣ Display Output**
    echo '<pre>';
    echo "<strong>List of ACF Image & Gallery Fields:</strong><br>";
    foreach ($acf_images_used as $field_name => $field_info) {
        echo "<strong>{$field_info['label']}</strong> ({$field_info['type']})<br>";

        foreach ($field_info['images'] as $image) {
            echo "- <strong>ID:</strong> {$image['id']} | <strong>Title:</strong> {$image['title']} | ";
            echo "<strong>Used in:</strong> {$image['used_in']['title']} (ID: {$image['used_in']['id']}, Type: {$image['used_in']['type']})<br>";
            echo "<img src='{$image['url']}' style='max-width:100px; height:auto;'><br>";
        }
        echo "<br>";
    }
    echo '</pre>';
}



add_shortcode('display--i',function (){
return ic_list_acf_fields_and_used_images();
});










// Move selected attachments to Trash
function ic_delete_selected_attachments($attachment_ids) {
    foreach ($attachment_ids as $attachment_id) {
        $post_type = get_post_type($attachment_id);
        if ($post_type === 'attachment') {
            wp_update_post(['ID' => $attachment_id, 'post_status' => 'trash']);
        }
    }

    add_action('admin_notices', function () {
        echo '<div class="notice notice-success is-dismissible"><p>Selected attachments moved to Trash successfully.</p></div>';
    });
}

// Move all unused attachments to Trash
function ic_delete_unused_attachments() {
    $data = ic_check_image_links_data();

    foreach ($data as $item) {
        if ($item['status'] === 'Unused' && get_post_type($item['id']) === 'attachment') {
            wp_update_post(['ID' => $item['id'], 'post_status' => 'trash']);
        }
    }

    add_action('admin_notices', function () {
        echo '<div class="notice notice-success is-dismissible"><p>All unused attachments moved to Trash successfully.</p></div>';
    });
}















function ic_check_image_links_data() {
    $all_images = [];

    // 🧲 Fetch all image attachments
    $attachments = get_posts([
        'post_type'   => 'attachment',
        'post_status' => 'inherit',
        'numberposts' => -1
    ]);

    foreach ($attachments as $a) {
        $mime = get_post_mime_type($a->ID);
        if (strpos($mime, 'image/') !== 0) continue;
        
        if ($mime === 'image/svg+xml' && ic_is_empty_svg_font($a->ID)) continue;
        

        

    
        $meta = get_post_meta($a->ID, '_wp_attachment_metadata', true);
        $files = [];
        if (is_array($meta)) {
            if (isset($meta['file'])) $files[] = $meta['file'];
            foreach ($meta['sizes'] ?? [] as $s) {
                if (!empty($s['file'])) $files[] = $s['file'];
            }
        }
    
        // 🖼 SVG fallback thumbnail
        $thumb = ($mime === 'image/svg+xml')
            ? wp_get_attachment_url($a->ID)
            : wp_get_attachment_image_url($a->ID, 'thumbnail');
    
        $all_images[$a->ID] = [
            'id'            => $a->ID,
            'title'         => $a->post_title,
            'files'         => $files,
            'status'        => 'Unused',
            'pages_posts'   => [],
            'type'          => $mime,
            'format'        => isset($files[0]) ? pathinfo($files[0], PATHINFO_EXTENSION) : '',
            'thumbnail_url' => $thumb
        ];
    }
    

    // 🔍 Scan usage across site
    ic_scan_posts_and_pages($all_images);
    ic_scan_taxonomy_terms($all_images);
    ic_scan_revslider_images($all_images);
    ic_register_global_asset($all_images, get_theme_mod('custom_logo'), 'Site Identity Logo');
    ic_register_global_asset($all_images, get_option('site_icon'), 'Site Icon');
    ic_scan_wp_options_images($all_images);
    ic_scan_elementor_font_posts($all_images);


    // 🧼 Final pass: enforce array integrity
    foreach ($all_images as &$img) {
        if (!isset($img['pages_posts']) || !is_array($img['pages_posts'])) {
            $img['pages_posts'] = [];
        }
        if (!isset($img['status'])) {
            $img['status'] = 'Unknown';
        }
    }

    return array_values($all_images);
}









/** 
 * Checks if an image exists by URL and returns its attachment ID.
 * 
 * @param string $url The URL of the image.
 * @return int|false Attachment ID if found, false otherwise.
 */

function ic_get_attachment_id_by_url($url)
{
    global $wpdb;
    $query = $wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE guid=%s", $url);
    return $wpdb->get_var($query);
}

/** 
 * Checks if an image exists by URL and returns true/false.
 * 
 * @param string $url The URL of the image.
 * @return bool True if the image exists, false otherwise.
 */
function ic_image_exists($url)
{
    $headers = @get_headers($url);
    return strpos($headers[0], '200') !== false;
}


/**
 * Marks an image as used and stores contextual info (e.g. post, taxonomy, slider).
 */
function ic_mark_image_used(&$images, $id, $context, $note = '') {
    if (isset($images[$id])) {
        $images[$id]['status'] = 'Used';
        $images[$id]['pages_posts'][] = $note ? array_merge($context, ['note' => $note]) : $context;
    }
}

/**
 * Matches a source filename against known image files and triggers usage marking.
 */
function ic_match_images_by_filename(&$images, $src, $context, $note = '') {
    $filename = strtolower(basename($src));
    foreach ($images as $id => $image) {
        foreach ($image['files'] as $file) {
            if (strtolower(basename($file)) === $filename) {
                ic_mark_image_used($images, $id, $context, $note);
                break;
            }
        }
    }
}


/**
 * Registers global assets (site logo, icon) as used and adds their metadata.
 */
function ic_register_global_asset(&$images, $id, $fallback_label = 'Global Asset') {
    if (!$id) return;

    // 🧠 Extract filename from metadata or URL
    $meta = get_post_meta($id, '_wp_attachment_metadata', true);
    $filename = '';

    if (is_array($meta) && isset($meta['file'])) {
        $filename = basename($meta['file']);
    } else {
        $url = wp_get_attachment_url($id);
        if ($url) {
            $filename = basename($url);
        }
    }

    // 🏷 Use filename as label, fallback if missing
    $label = $filename ?: $fallback_label;

    // 🧱 Ensure image entry exists
    if (!isset($images[$id])) {
        $images[$id] = [
            'id'            => $id,
            'title'         => $label,
            'files'         => [],
            'status'        => 'Unused',
            'pages_posts'   => [],
            'type'          => get_post_mime_type($id),
            'format'        => '',
            'thumbnail_url' => '',
        ];
    }

    // 🖼 SVG fallback thumbnail
    $mime = get_post_mime_type($id);
    $thumb = ($mime === 'image/svg+xml')
        ? wp_get_attachment_url($id)
        : wp_get_attachment_image_url($id, 'thumbnail');

    // 🖊️ Register usage
    ic_mark_image_used($images, $id, [
        'title' => $fallback_label,
        'id'    => 0,
        'type'  => 'site'
    ]);

    // 🧼 Update image metadata
    $images[$id]['title']         = $label;
    $images[$id]['files']         = [];
    $images[$id]['type']          = $mime;
    $images[$id]['format']        = '';
    $images[$id]['thumbnail_url'] = $thumb;
}





/**
 * Scans published posts/pages for image usage via content, Elementor, featured images, ACF.
 */
function ic_scan_posts_and_pages(&$images) {
    global $wpdb;

    // Get published posts across all public types
    $post_types = get_post_types(['public' => true], 'names');
    $post_types_list = "'" . implode("','", $post_types) . "'";
    $posts = $wpdb->get_results("
        SELECT ID, post_content, post_title, post_type FROM {$wpdb->posts}
        WHERE post_type IN ($post_types_list) AND post_status = 'publish'
    ");

    foreach ($posts as $post) {
        $ctx = ['title' => $post->post_title, 'id' => $post->ID, 'type' => $post->post_type];

        // Detect <img> tags in post content
        preg_match_all('/<img[^>]+src="([^">]+)"/i', $post->post_content, $matches);
        foreach ($matches[1] as $src) {
            ic_match_images_by_filename($images, $src, $ctx);
        }

        // Detect image URLs in Elementor JSON
        $elementor_json = get_post_meta($post->ID, '_elementor_data', true);
        if (!empty($elementor_json)) {
            // Raw URL matches like "url":"..."
            preg_match_all('/"url":"([^"]+)"/i', $elementor_json, $matches);
            foreach ($matches[1] as $src) {
                ic_match_images_by_filename($images, $src, $ctx, 'Elementor URL');
            }

            // Decode Elementor node structure
            $elementor_data = json_decode($elementor_json, true);
            if (is_array($elementor_data)) {
                $stack = $elementor_data;

                while ($stack) {
                    $node = array_pop($stack);
                    if (!is_array($node)) continue;

                    // Custom CSS in this node
                    if (!empty($node['settings']['custom_css'])) {
                        preg_match_all('/url\\(([^)]+)\\)/i', $node['settings']['custom_css'], $css_matches);
                        foreach ($css_matches[1] as $raw_url) {
                            $clean_url = trim(str_replace(['"', "'"], '', $raw_url));
                            ic_match_images_by_filename($images, $clean_url, $ctx, 'Elementor CSS');
                        }
                    }

                    // Descend into child elements
                    if (!empty($node['elements']) && is_array($node['elements'])) {
                        foreach ($node['elements'] as $child) {
                            $stack[] = $child;
                        }
                    }
                }
            }
        }


        // Mark featured image as used
        $feat_id = get_post_thumbnail_id($post->ID);
        if ($feat_id) ic_mark_image_used($images, $feat_id, $ctx, 'Featured Image');

        // Detect ACF image and gallery fields
        // if (function_exists('get_fields')) {
        //     $acf = get_fields($post->ID);
        
        //     foreach ((array) $acf as $field_value) {
        //         // Single image (e.g. image field returning ID)
        //         if (is_numeric($field_value)) {
        //             ic_mark_image_used($images, $field_value, $ctx, 'ACF Image');
        //         }
        
        //         // Array: could be gallery field
        //         elseif (is_array($field_value)) {
        //             foreach ($field_value as $item) {
        //                 if (is_numeric($item)) {
        //                     // Gallery returns ID array
        //                     ic_mark_image_used($images, $item, $ctx, 'ACF Gallery (ID)');
        //                 } elseif (is_array($item) && isset($item['ID'])) {
        //                     // Gallery returns array of image objects
        //                     ic_mark_image_used($images, $item['ID'], $ctx, 'ACF Gallery (Image Object Array)');
        //                 }
        //             }
        //         }
        //     }
        // }
        if (function_exists('get_fields')) {
            $acf = get_fields($post->ID);
        
            foreach ((array) $acf as $field_name => $field_value) {
                $image_ids = ic_find_images_in_acf_field($field_value);
        
                foreach ($image_ids as $img_id) {
                    ic_mark_image_used($images, $img_id, $ctx, "ACF Field: $field_name");
                }
            }
        }

        // Scan ACF Options Page
        if (function_exists('get_fields')) {
            $acf_options = get_fields('option');

            if (!empty($acf_options)) {
                $ctx = ['title' => 'ACF Options', 'id' => 0, 'type' => 'options'];

                foreach ((array) $acf_options as $field_name => $field_value) {
                    $image_ids = ic_find_images_in_acf_field($field_value);

                    foreach ($image_ids as $img_id) {
                        ic_mark_image_used($images, $img_id, $ctx, "Options Field: $field_name");
                    }
                }
            }
        }
        
    }
}

/**
 * Scans acf fields from nested fields
 */
function ic_find_images_in_acf_field($field_value) {
    $found_ids = [];

    if (is_numeric($field_value)) {
        $found_ids[] = $field_value;
    } elseif (is_array($field_value)) {
        foreach ($field_value as $item) {
            if (is_numeric($item)) {
                $found_ids[] = $item;
            } elseif (is_array($item)) {
                if (isset($item['ID'])) {
                    $found_ids[] = $item['ID'];
                }
                // Recurse deeper
                $found_ids = array_merge($found_ids, ic_find_images_in_acf_field($item));
            }
        }
    }

    return $found_ids;
}

/**
 * Scans taxonomy terms (e.g. categories, brands) for image usage via ACF.
 */
function ic_scan_taxonomy_terms(&$images) {
    $taxonomies = get_taxonomies(['public' => true], 'names');
    foreach ($taxonomies as $tax) {
        $terms = get_terms(['taxonomy' => $tax, 'hide_empty' => false]);
        foreach ($terms as $term) {
            $ctx = ['title' => $term->name, 'id' => $term->term_id, 'type' => 'taxonomy:' . $tax];

            // ACF image fields for terms
            if (function_exists('get_fields')) {
                $acf = get_fields($term);
                foreach ((array) $acf as $v) {
                    if (is_numeric($v)) {
                        ic_mark_image_used($images, $v, $ctx, 'ACF Term Image');
                    } elseif (is_array($v)) {
                        foreach ($v as $img) {
                            if (is_numeric($img)) {
                                ic_mark_image_used($images, $img, $ctx, 'ACF Term Gallery');
                            }
                        }
                    }
                }
            }
        }
    }
}





/**
 * Scans all Revolution Slider tables for image usage:
 * - wp_revslider_sliders    → slider-level image library + thumb
 * - wp_revslider_slides     → individual slide background + thumbnail
 * - wp_revslider_slides7    → RevSlider v7 with structured thumbs and layers
 */

function ic_scan_revslider_images(&$images) {
    global $wpdb;

    // 🔹 SLIDER-LEVEL (wp_revslider_sliders)
    $slider_rows = $wpdb->get_col("SELECT params FROM {$wpdb->prefix}revslider_sliders");
    foreach ($slider_rows as $json) {
        $params = json_decode($json, true);
        if (!is_array($params)) continue;

        $ctx = [
            'title' => $params['title'] ?? 'RevSlider',
            'id'    => 0,
            'type'  => 'revslider'
        ];

        // Library-style image array
        if (!empty($params['imgs'])) {
            foreach ($params['imgs'] as $img) {
                if (!empty($img['src'])) {
                    ic_match_images_by_filename($images, $img['src'], $ctx, 'RevSlider Slide Image');
                }
            }
        }

        // Slider thumbnail
        if (!empty($params['thumb'])) {
            ic_match_images_by_filename($images, $params['thumb'], $ctx, 'RevSlider Slider Thumb');
        }
    }

    // 🔹 SLIDE-LEVEL (wp_revslider_slides)
    $slides = $wpdb->get_col("SELECT params FROM {$wpdb->prefix}revslider_slides");
    foreach ($slides as $json) {
        $params = json_decode($json, true);
        if (!is_array($params)) continue;

        $ctx = [
            'title' => $params['title'] ?? 'RevSlider Slide',
            'id'    => 0,
            'type'  => 'revslider'
        ];

        if (!empty($params['bg']['image'])) {
            ic_match_images_by_filename($images, $params['bg']['image'], $ctx, 'RevSlider Slide BG');
        }

        if (!empty($params['thumb']['customThumbSrc'])) {
            ic_match_images_by_filename($images, $params['thumb']['customThumbSrc'], $ctx, 'RevSlider Slide Thumb');
        }
    }

    // 🔹 SLIDE v7 (wp_revslider_slides7)
    $slides7 = $wpdb->get_col("SELECT params FROM {$wpdb->prefix}revslider_slides7");
    foreach ($slides7 as $json) {
        $params = json_decode($json, true);
        if (!is_array($params)) continue;

        $ctx = [
            'title' => $params['title'] ?? 'RevSlider7',
            'id'    => $params['id'] ?? 0,
            'type'  => 'revslider7'
        ];

        // Background image in thumb.default.image.src
        if (!empty($params['thumb']['default']['image']['src'])) {
            ic_match_images_by_filename($images, $params['thumb']['default']['image']['src'], $ctx, 'RevSlider7 BG');
        }

        // Custom thumbnail
        if (!empty($params['thumb']['src'])) {
            ic_match_images_by_filename($images, $params['thumb']['src'], $ctx, 'RevSlider7 Thumb');
        }

        // Deep scan layers JSON for slidebg image backgrounds
        if (!empty($params['layers']) && is_string($params['layers'])) {
            $layers = json_decode($params['layers'], true);
            if (is_array($layers)) {
                foreach ($layers as $layer) {
                    if (
                        isset($layer['subtype']) &&
                        $layer['subtype'] === 'slidebg' &&
                        !empty($layer['bg']['image']['src'])
                    ) {
                        ic_match_images_by_filename($images, $layer['bg']['image']['src'], $ctx, 'RevSlider7 Layer BG');
                    }
                }
            }
        }
    }
}



function ic_scan_wp_options_images(&$images) {
    global $wpdb;

    $rows = $wpdb->get_results("
        SELECT option_name, option_value
        FROM {$wpdb->prefix}options
        WHERE option_value LIKE '%<img%'
           OR option_value LIKE 'http%'
           OR option_value LIKE '%uploads/%'
    ");

    foreach ($rows as $row) {
        $context = [
            'title' => $row->option_name,
            'id'    => 0,
            'type'  => 'wp_option'
        ];

        // Match image src attributes in <img> tags
        preg_match_all('/<img[^>]+src=[\'"]([^\'"]+)[\'"]/i', $row->option_value, $matches);
        foreach ($matches[1] as $src) {
            ic_match_images_by_filename($images, $src, $context, 'Option Image Tag');
        }

        // Match standalone image URLs (fallback)
        preg_match_all('/https?:\/\/[^"\']+\.(jpg|jpeg|png|gif|webp)/i', $row->option_value, $plain_matches);
        foreach ($plain_matches[0] as $src) {
            ic_match_images_by_filename($images, $src, $context, 'Option Raw Image URL');
        }


    }
}




/*************updates */
function ic_render_filter_controls($images) {
    $status_filter = $_GET['status_filter'] ?? '';
    $action = $_GET['action'] ?? '';
    $total = count($images);
    $used = count(array_filter($images, fn($img) => $img['status'] === 'Used'));
    $unused = $total - $used;
    ?>
    <div style="display: flex; justify-content: space-between; align-items: center; margin: 10px 0;">
      <form method="get" class="bulk-action-form" style="display: flex; gap: 10px; align-items: center;">
        <input type="hidden" name="page" value="image-link-checker" />
  
        <select name="action" class="button action bulk-action-button">
          <option value="">Bulk actions</option>
          <option value="trash" <?= $action === 'trash' ? 'selected' : '' ?>>Move to Trash</option>
        </select>
  
        <button type="submit" class="button action">Apply</button>
  
        <select name="status_filter" id="status_filter">
          <option value="">All Status</option>
          <option value="Used" <?= $status_filter === 'Used' ? 'selected' : '' ?>>Used</option>
          <option value="Unused" <?= $status_filter === 'Unused' ? 'selected' : '' ?>>Unused</option>
        </select>
  
        <button type="submit" class="button action filter-button">Filters</button>
      </form>
  
      <div style="margin-right:10px;">
        <strong>Total:</strong> <?= $total ?> |
        <span style="color: green;"><strong>Used:</strong> <?= $used ?></span> |
        <span style="color: red;"><strong>Unused:</strong> <?= $unused ?></span>
      </div>
    </div>
    <?php
  }

  
  function ic_handle_deletion() {
    if (
      $_SERVER['REQUEST_METHOD'] === 'GET' &&
      isset($_GET['action']) &&
      $_GET['action'] === 'trash' &&
      !empty($_GET['delete_ids']) &&
      current_user_can('delete_posts')
    ) {
      foreach ($_GET['delete_ids'] as $id) {
        wp_trash_post($id);
      }
      echo '<div class="updated"><p>Selected attachments moved to Trash.</p></div>';
    }
  }

  
  function ic_render_image_table($images) {
    $status_filter = $_GET['status_filter'] ?? '';
    ?>
    <form method="get" class="template-table-form">
      <table class="asset-scanner-table wp-list-table widefat fixed striped">
        <thead>
          <tr>
            <th class="check-column"><label><input type="checkbox" id="select-unused" /></label></th>
            <th style="width: 30px;">ID</th>
            <th style="width: 60px;">Preview</th>
            <th>Title</th>
            <th style="width: 140px;">Type</th>
            <th style="width: 60px;">Format</th>
            <th style="width: 60px;">Status</th>
            <th>Pages/Posts</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($images as $item):

            if ($status_filter && $item['status'] !== $status_filter) continue;
            $id = $item['id'];
            $status = $item['status'];
            $checkbox = ($status === 'Unused') ? "<input type='checkbox' name='delete_ids[]' value='{$id}' class='row-checkbox' data-status='{$status}' />" : '';
            $preview = $item['thumbnail_url'] ? "<a href='" . admin_url("upload.php?item={$id}") . "' target='_blank'><img src='{$item['thumbnail_url']}' width='50'></a>" : 'No Image';
            $title = "<a href='" . admin_url("upload.php?item={$id}") . "' target='_blank'>" . esc_html($item['title']) . "</a>";
            $statusStyle = $status === 'Unused' ? 'color: red;' : '';
            $pagesPostsList = '<ul>';
            foreach (array_unique(array_map('serialize', $item['pages_posts'])) as $serialized) {
                $page_post = unserialize($serialized);
                $displayText = $page_post['title'] . ' (' . $page_post['type'] . ' ID: ' . $page_post['id'] . ')';
                if (isset($page_post['note'])) $displayText .= ' (' . $page_post['note'] . ')';
                $editUrl = ($page_post['type'] === 'site' || $page_post['id'] === 0) ? '' :
                (strpos($page_post['type'], 'taxonomy:') === 0
                    ? admin_url("edit-tags.php?action=edit&taxonomy=" . str_replace('taxonomy:', '', $page_post['type']) . "&tag_ID=" . $page_post['id'])
                    : admin_url("post.php?post=" . $page_post['id'] . "&action=edit"));
                $pagesPostsList .= $editUrl
                ? "<li><a href='{$editUrl}' target='_blank'>{$displayText}</a></li>"
                : "<li>{$displayText}</li>";
            }
            $pagesPostsList .= '</ul>';
            ?>
            <tr>
              <td class="check-column"><label><?= $checkbox ?></label></td>
              <td><?= esc_html($id) ?></td>
              <td><?= $preview ?></td>
              <td><?= $title ?>
				<div class="var-dump" style="display:none;"><?php echo var_dump($item);?></div>
				</td>
              <td><?= esc_html($item['type']) ?></td>
              <td><?= esc_html($item['format']) ?></td>
              <td style="<?= $statusStyle ?>"><?= esc_html($status) ?></td>
              <td><?= $pagesPostsList ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <th class="check-column"><label><input type="checkbox" id="select-unused" /></label></th>
            <th style="width: 30px;">ID</th>
            <th style="width: 60px;">Preview</th>
            <th>Title</th>
            <th style="width: 140px;">Type</th>
            <th style="width: 60px;">Format</th>
            <th style="width: 60px;">Status</th>
            <th>Pages/Posts</th>
          </tr>
        </tfoot>
      </table>
    </form>
    <?php
  }

  function ic_scripts() {
    ?>
    <script>
      document.addEventListener('DOMContentLoaded', function () {
        const selectUnused = document.getElementById('select-unused');
        const checkboxes = document.querySelectorAll('.row-checkbox');
  
        if (selectUnused) {
          selectUnused.addEventListener('change', function () {
            checkboxes.forEach(cb => {
              if (cb.dataset.status === 'Unused') {
                cb.checked = selectUnused.checked;
              }
            });
          });
        }
  
        const bulkForm = document.querySelector('form.bulk-action-form');
        const tableForm = document.querySelector('form.template-table-form');
  
        bulkForm.addEventListener('submit', function () {
          bulkForm.querySelectorAll('input[name="delete_ids[]"]').forEach(el => el.remove());
          const checked = tableForm.querySelectorAll('input[name="delete_ids[]"]:checked');
          checked.forEach(input => {
            const hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'delete_ids[]';
            hidden.value = input.value;
            bulkForm.appendChild(hidden);
          });
        });
      });
    </script>
    <?php
  }

  
  function ic_settings_page() {
    ic_handle_deletion();
    $images = ic_check_image_links_data();
    echo '<div class="wrap image-link-checker"><h1>Image Checker</h1>';
    ic_render_filter_controls($images);
    ic_render_image_table($images);
    ic_render_filter_controls($images);
    ic_scripts();
    echo '</div>';
  }
  
  function ic_is_empty_svg_font($attachment_id) {
    $mime = get_post_mime_type($attachment_id);
    if ($mime !== 'image/svg+xml') return false;

    $path = get_attached_file($attachment_id);
    if (!file_exists($path)) return false;

    $svg = file_get_contents($path);
    if (!$svg) return false;

    // Normalize and strip whitespace
    $svg = preg_replace('/\s+/', '', $svg);

    // Match empty SVG structure
    return preg_match('/^<svg[^>]*><metadata\/?><defs\/?><\/svg>$/i', $svg);
}


function ic_scan_elementor_font_posts(&$images) {
    $fonts = get_posts([
      'post_type' => 'elementor_font',
      'post_status' => 'publish',
      'numberposts' => -1
    ]);
  
    foreach ($fonts as $font) {
      $font_files = get_post_meta($font->ID, 'elementor_font_files', true);
      if (!is_array($font_files)) continue;
  
      foreach ($font_files as $entry) {
        foreach (['svg', 'woff', 'woff2', 'ttf', 'eot'] as $format) {
          if (!empty($entry[$format]['id'])) {
            $id = intval($entry[$format]['id']);
            ic_mark_image_used($images, $id, [
              'title' => $font->post_title,
              'id' => $font->ID,
              'type' => 'elementor_font'
            ], 'Elementor Font');
          }
        }
      }
    }
  }
  