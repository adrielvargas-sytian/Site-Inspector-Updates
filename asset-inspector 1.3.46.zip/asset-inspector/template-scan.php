<?php

/*
  for shortcodes that display elementor templates, please add the following attribute to the shortcode:
  template_id="1234" where 1234 is the ID of the elementor template
 */

/**
 * Matches template usage in various formats including:
 *
 * Elementor Shortcodes & JSON:
 * - Shortcode references: [elementor-template id="123"]
 * - JSON structure from Elementor widgets: "template_id":"123" and "template_id":123
 *
 * AE Templates:
 * - AE shortcode usage: [INSERT_ELEMENTOR id="123"]
 *
 * JetEngine & JetPopup:
 * - JetEngine listing templates: "lisitng_id":"123"
 * - Dynamic popup injection: "popup":"123"
 * - JetPopup widget assignment: "jet_attached_popup":"123"
 *
 * Generic Usage:
 * - Any shortcode using template_id="123"
 *
 * Premium Addons for Elementor:
 * - Premium Carousel widget titles inside premium_carousel_templates_repeater
 *   → Titles are resolved to post IDs via get_page_by_title() in a recursive element scan.
 * 
 * 
 * Elementor Maintenance Mode:
 * - Template assigned via Settings > Tools > Maintenance Mode
 *   → Retrieved via get_option('elementor_maintenance_mode_template_id')
 */




function scan_elementor_templates($template_id) {
    $template_status = "none";
    global $wpdb;

    $results = $wpdb->get_results("
        SELECT pm.post_id, pm.meta_value 
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
        WHERE pm.meta_key = '_elementor_data' AND p.post_status = 'publish'
    ");

    $all_template_id = [];

    foreach ($results as $result) {
        if (Elementor\Plugin::instance()->db->is_built_with_elementor($result->post_id)) {
            // 🧹 Clean shortcode/markup for parsing
            $string = $result->meta_value;
            $stripped_string = str_replace(['[', ']', '\\'], '', $string);

            // 📦 Regex patterns to detect template references by ID
            $patterns = [                
                '/elementor-template id="(\d+)"/' 		=> 		$stripped_string, // Elementor shortcode: [elementor-template id="123"]
                
                '/"template_id":"([^"]+)"/' 			=> 		$result->meta_value, // JSON-style: "template_id":"123"

                '/"template":"([^"]+)"/' 			    => 		$result->meta_value, // JSON-style: "template":"123"
                
                '/"lisitng_id":"([^"]+)"/' 				=> 		$result->meta_value, // JetEngine listing usage: "lisitng_id":"123"
                
                '/"popup":"([^"]+)"/' 					=> 		urldecode($result->meta_value), // Popup reference: "popup":"123"
                
                '/INSERT_ELEMENTOR id="(\d+)"/' 		=> 		$stripped_string, // AE Templates via shortcode: [INSERT_ELEMENTOR id="123"]
                
                '/"jet_attached_popup":"([^"]+)"/' 		=> 		$result->meta_value, // JetPopup reference: "jet_attached_popup":"123"
                
                '/template_id\s*=\s*"(\d+)"/' 			=> 		$stripped_string, // Generic shortcode attribute: template_id="123"
                
                '/"template_id"\s*:\s*(\d+)/' 			=> 		$result->meta_value, // JSON literal: "template_id":123
            ];

            // 🎯 Match all regex-based template IDs
            foreach ($patterns as $pattern => $subject) {
                preg_match_all($pattern, $subject, $matches);
                if (!empty($matches[1])) {
                    $all_template_id = array_merge($all_template_id, $matches[1]);
                }
            }

            // 🔍 Decode _elementor_data to scan widgets
            $decoded = json_decode($result->meta_value, true);

            if (is_array($decoded)) {
                $all_template_id = array_merge($all_template_id, scan_carousel_template_ids($decoded));
            }

        } else {
            // 🧭 Non-Elementor page — scan post_content
            $post_content = $wpdb->get_var($wpdb->prepare(
                "SELECT post_content FROM {$wpdb->posts} WHERE ID = %d",
                $result->post_id
            ));

            $non_elementor_patterns = [                
                '/elementor-template id="(\d+)"/' 		=>		 $post_content, // Elementor shortcode: [elementor-template id="123"]
				                
                '/INSERT_ELEMENTOR id="(\d+)"/' 		=> 		$post_content, // AE shortcode: [INSERT_ELEMENTOR id="123"]
            ];

            foreach ($non_elementor_patterns as $pattern => $subject) {
                preg_match_all($pattern, $subject, $matches);
                if (!empty($matches[1])) {
                    $all_template_id = array_merge($all_template_id, $matches[1]);
                }
            }
        }
    }

    // Elementor Maintenance Mode Template (if assigned)
    $maintenance_id = get_option('elementor_maintenance_mode_template_id');
    if (!empty($maintenance_id)) {
        $all_template_id[] = $maintenance_id;
    }


    $all_template_id = array_unique($all_template_id);

    // 🔘 Direct match found
    if (in_array($template_id, $all_template_id)) return "Used";

    // 🔘 Conditional template usage
    if (get_post_meta($template_id, '_elementor_conditions', true)) return "Used";
    if (($jet = get_post_meta($template_id, '_conditions', true)) && $jet !== 'a:0:{}') return "Used";

    $type = get_elementor_template_type($template_id);
    if ($type == "" || $type == "kit") return "N/A";

    // 🔘 Mega menu condition scan
    $post_id_ = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %d",
        'pa_mega_content_temp',
        $template_id
    ));

    if ($post_id_) {
        $post_type = get_post_type($post_id_);
        if ($post_type === 'nav_menu_item') {
            $item_data = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s",
                $post_id_,
                'pa_megamenu_item_meta'
            ));
            if ($item_data && preg_match('/"mega_content_enabled":"true"/', $item_data)) {
                return "Used";
            }
            return "<span style='color:red'>Mega Menu Disabled</span>";
        }
    }
    return "<span style='color:red'>Unused</span>";
}

function scan_carousel_template_ids($elements) {
    $ids = [];

    foreach ($elements as $node) {
        if (!empty($node['elements'])) {
            $ids = array_merge($ids, scan_carousel_template_ids($node['elements']));
        }

        if (
            isset($node['widgetType']) &&
            $node['widgetType'] === 'premium-carousel-widget' &&
            !empty($node['settings']['premium_carousel_templates_repeater'])
        ) {
            foreach ($node['settings']['premium_carousel_templates_repeater'] as $item) {
                if (!empty($item['premium_carousel_repeater_item'])) {
                    $template_post = get_page_by_title($item['premium_carousel_repeater_item'], OBJECT, 'elementor_library');
                    if ($template_post) {
                        $ids[] = $template_post->ID;
                    }
                }
                if (!empty($item['live_temp_content'])) {
                    $template_post = get_page_by_title($item['live_temp_content'], OBJECT, 'elementor_library');
                    if ($template_post) {
                        $ids[] = $template_post->ID;
                    }
                }
            }
        }
    }

    return $ids;
}


/****** TEMPLATE OVERVIEW PAGE******/

function get_available_template_types() {
  $types = ['elementor_library' => 'Elementor'];

  if (is_plugin_active('anywhere-elementor-pro/anywhere-elementor-pro.php') && post_type_exists('ae_global_templates')) {
    $types['ae_global_templates'] = 'AE';
  }

  if (is_plugin_active('jet-engine/jet-engine.php')) {
    if (post_type_exists('jet-engine')) {
      $types['jet-engine'] = 'JetEngine';
    }
    if (post_type_exists('jet-popup')) {
      $types['jet-popup'] = 'JetPopup';
    }
  }

  return $types;
}


function render_filter_controls($templates) {
  $filter = $_GET['filter'] ?? 'all';
  $usage = $_GET['usage'] ?? 'all';
  $action = $_GET['action'] ?? '';
  $types = get_available_template_types();
  $count = count($templates);
  ?>

  <div style="display: flex; justify-content: space-between; align-items: center; margin: 10px 0;">
    <form method="get" class="bulk-action-form" style="display: flex; gap: 10px; align-items: center;">
      <input type="hidden" name="page" value="template-overview" />

      <select name="action" class="button action bulk-action-button">
        <option value="">Bulk actions</option>
        <option value="trash" <?= $action === 'trash' ? 'selected' : '' ?>>Move to Trash</option>
      </select>

      <button type="submit" class="button action">Apply</button>

      <select name="filter" id="filter">
        <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>All Templates</option>
        <?php foreach ($types as $key => $label): ?>
          <option value="<?= $key ?>" <?= $filter === $key ? 'selected' : '' ?>><?= $label ?></option>
        <?php endforeach; ?>
      </select>

      <select name="usage" id="usage">
        <?php foreach (['all' => 'All Usage', 'used' => 'Used', 'unused' => 'Unused'] as $key => $label): ?>
          <option value="<?= $key ?>" <?= $usage === $key ? 'selected' : '' ?>><?= $label ?></option>
        <?php endforeach; ?>
      </select>

      <button type="submit" class="button action filter-button">Filters</button>
    </form>

    <div style="margin-right:10px;"><?= get_template_usage_summary($templates) ?></div>
  </div>

  
  <?php
}


function template_scripts(){
	?>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const selectUnused = document.getElementById('select-unused');
  const checkboxes = document.querySelectorAll('.row-checkbox');

  if (selectUnused) {
    selectUnused.addEventListener('change', function () {
      checkboxes.forEach(cb => {
        if (cb.dataset.status === 'Unused') {
          cb.checked = selectUnused.checked;
        }
      });
    });
  }
});
</script>




<script>
    document.addEventListener('DOMContentLoaded', function () {
      const bulkForm = document.querySelector('form.bulk-action-form');
      const tableForm = document.querySelector('form.template-table-form');

      bulkForm.addEventListener('submit', function () {
        bulkForm.querySelectorAll('input[name="delete_ids[]"]').forEach(el => el.remove());

        const checked = tableForm.querySelectorAll('input[name="delete_ids[]"]:checked');
        checked.forEach(input => {
          const hidden = document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = 'delete_ids[]';
          hidden.value = input.value;
          bulkForm.appendChild(hidden);
        });
      });
    });
  </script>

<?php
}



function get_all_templates($filter = 'all', $usage = 'all') {
  $filter = $_POST['filter'] ?? $_GET['filter'] ?? $filter;
  $usage = $_POST['usage'] ?? $_GET['usage'] ?? $usage;

  $types = array_keys(get_available_template_types());
  $templates = [];

  foreach ($types as $type) {
    $args = [
      'post_type' => $type,
      'post_status' => ['publish', 'draft'],
      'posts_per_page' => -1,
    ];

    $query = new WP_Query($args);

    foreach ($query->posts as $post) {
      $status_raw = scan_elementor_templates($post->ID);
      $status_clean = strip_tags($status_raw);
      $status_clean = ($status_clean === 'Found') ? 'Used' : (($status_clean === 'Not Found') ? 'Unused' : $status_clean);

      if (($usage === 'used' && $status_clean !== 'Used') || ($usage === 'unused' && $status_clean !== 'Unused')) continue;
      if ($filter !== 'all' && $post->post_type !== $filter) continue;

      $type_label = get_post_type_label($post->post_type, $post->ID);

      $templates[] = [
        'id' => $post->ID,
        'title' => $post->post_title,
        'type' => $type_label,
        'date' => $post->post_date,
        'status' => $status_clean,
      ];
    }
  }

  return $templates;
}



function get_post_type_label($post_type, $post_id) {
  switch ($post_type) {
    case 'elementor_library':
      $subtype = get_post_meta($post_id, '_elementor_template_type', true);
      return 'Elementor (' . ucfirst($subtype ?: 'Unknown') . ')';
    case 'ae_global_templates': return 'AE';
    case 'jet-engine': return 'JetEngine';
    case 'jet-popup': return 'JetPopup';
    default: return ucfirst($post_type);
  }
}



function render_template_table($templates) {
  ?>
  <form method="get" class="template-table-form">
    <?php wp_nonce_field('delete_templates_action'); ?>

    <style>
      .template-table th:nth-child(2),
      .template-table td:nth-child(2) {
        display:none;
      }

      .template-table th:first-child {
        width: 2.2em;
      }

    

      .template-table td, .template-table th {
        vertical-align: top;
        padding-top: 12px;
        padding-bottom: 12px;
        line-height: 1.5em;
      }

      .template-table tbody tr {
        height: 3.6em;
      }

      td.template-title { display: inline-block; font-weight:600; font-size:14px; }
      .row-actions {
        position: relative;
        left: -9999px;
        overflow: hidden;
      }
      tr:hover .row-actions {
        left: 0px;
      }
      td.template-title .row-actions .trash a {
        text-decoration: none;
		  font-size:13px;
		  font-weight:400;
      }
      td.status-unused {
        color: red;
      }
		.template-table td.check-column,.template-table th.check-column {
		  padding: 4px;
		  vertical-align: middle;
		  text-align: center;
		}

		.template-table td.check-column label,.template-table th.check-column label {
		  display: flex;
		  justify-content: center;
		  align-items: center;
		}
		


    </style>

    <table class="wp-list-table widefat fixed striped template-table">
      <thead>
        <tr>
          <th class="check-column"> <label> <input type="checkbox" id="select-unused" title="Select all unused templates" /> </label> </th>
          <th>ID</th>
          <th>Title</th>
          <th>Type</th>
          <th>Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
		  
		

		  
        <?php foreach ($templates as $tpl): 
          $checkbox = ($tpl['status'] === 'Unused') ? "<input type='checkbox' name='delete_ids[]' value='{$tpl['id']}' class='row-checkbox' data-status='{$tpl['status']}' />" : '';
          $edit_link = esc_url(admin_url("post.php?post={$tpl['id']}&action=elementor"));
          $trash_link = esc_url(get_delete_post_link($tpl['id']));
          $status_class = ($tpl['status'] === 'Unused') ? 'status-unused' : '';

          $post_status = get_post_status($tpl['id']);
          $title = $tpl['title'];
          

          $date_label = ($post_status === 'publish') ? 'Published' : 'Last Modified';
          $date_value = ($post_status === 'publish') 
            ? get_the_date('Y/m/d \a\t g:i a', $tpl['id']) 
            : get_post_modified_time('Y/m/d \a\t g:i a', false, $tpl['id']);
        ?>
          <tr>
            <td class="check-column"> <label><?= $checkbox ?></label></td>
            <td><?= $tpl['id'] ?></td>
            <td class="template-title">
              <a href="<?= $edit_link ?>" target="_blank"><?= esc_html($title) ?></a>
				<?= ($post_status === 'draft') ?' — Draft' :'' ?>
              <div class="row-actions">
                <?php if ($tpl['status'] === "Unused") { ?>
                  <span class="trash"><a href="<?= $trash_link ?>" class="trash">Trash</a></span>
                <?php } else { ?>
                  <span>&nbsp;</span>
                <?php } ?>
              </div>
            </td>
            <td><?= esc_html($tpl['type']) ?></td>
            <td><?= $date_label ?> <br /> <?= esc_html($date_value) ?></td>
            <td class="<?= $status_class ?>"><?= esc_html($tpl['status']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr>
          <th class="check-column"> <label> <input type="checkbox" id="select-unused" title="Select all unused templates" /> </label> </th>
          <th>ID</th>
          <th>Title</th>
          <th>Type</th>
          <th>Date</th>
          <th>Status</th>
        </tr>
      </tfoot>
    </table>

    
  </form>
  <?php
}





function render_template_overview_page() {
  handle_template_deletion();

  echo '<div class="wrap"><h1>Template Overview</h1>';
  

  $filter = $_GET['filter'] ?? 'all';
  $usage = $_GET['usage'] ?? 'all';
  $templates = get_all_templates($filter, $usage);
render_filter_controls($templates);
  render_template_table($templates);
	render_filter_controls($templates);
	template_scripts();
  echo '</div>';
}

function handle_template_deletion() {
  if (
    $_SERVER['REQUEST_METHOD'] === 'GET' &&
    isset($_GET['action']) &&
    $_GET['action'] === 'trash' &&
    !empty($_GET['delete_ids']) &&
    current_user_can('delete_posts')
  ) {
    foreach ($_GET['delete_ids'] as $id) {
      wp_trash_post($id);
    }
    echo '<div class="updated"><p>Selected templates moved to trash.</p></div>';
  }
}


function get_template_usage_summary($templates) {
  $total = count($templates);
  $used = count(array_filter($templates, fn($tpl) => $tpl['status'] === 'Used'));
  $unused = count(array_filter($templates, fn($tpl) => $tpl['status'] === 'Unused'));
  $na = count(array_filter($templates, fn($tpl) => $tpl['status'] === 'N/A'));
  ob_start();
?>
<strong>Total:</strong> <?= $total ?> |
<span style="color: green;"><strong>Used:</strong> <?= $used ?></span> |
<span style="color: red;"><strong>Unused:</strong> <?= $unused ?></span> |
<span><strong>N/A:</strong> <?= $na ?></span>
<?php
  return ob_get_clean();

}


/****** END TEMPLATE OVERVIEW PAGE******/