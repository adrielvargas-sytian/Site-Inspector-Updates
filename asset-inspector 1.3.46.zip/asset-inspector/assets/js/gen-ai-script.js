jQuery(function ($) {
    let isGenerating = false;
    let generatedCount = 0;
    let failedCount = 0;
    let skippedCount = 0;
    let noContentCount = 0;
    let generationSummary = [];

    function updateProgress(current, total) {
        const percent = Math.round((current / total) * 100);
        $('#gem-progress-bar').css('width', percent + '%');
        $('#gem-progress-label').html(
            'Progress: ' + current + '/' + total + ' (' + percent + '%)<br>' +
            '✅ Generated: ' + generatedCount +
            ' &nbsp;&nbsp; ❌ Failed: ' + failedCount +
            ' &nbsp;&nbsp; ⚠️ Skipped: ' + skippedCount +
            ' &nbsp;&nbsp; 📭 No Content: ' + noContentCount
        );
    }


    function generateTagsForRow($btn, callback) {
        const $row = $btn.closest('tr');
        const postId = $btn.data('post');
        const $desc = $row.find('.gem-description');
        const $primary = $row.find('.gem-primary');
        const $additional = $row.find('.gem-additional');

        $row.addClass('loading');
        $btn.prop('disabled', true).text('Generating...');
        $desc.val('');
        $primary.val('');
        $additional.val('');

        console.log('🧠 Generating for Post ID:', postId);

        $.post(ajaxurl, {
            action: 'gem_generate_meta_tags',
            nonce: gem_meta_tags.nonce,
            post_id: postId
        }, function (res) {
            console.log('✅ Response for Post', postId, res);
            $row.removeClass('loading');

            // 📭 Check for missing content error
            if (res.data?.message === 'Post content not found') {
                noContentCount++;
                generationSummary.push('📭 Post ' + postId + ' — Skipped (no content)');
                $btn.prop('disabled', false).text('Generate Tags');
                if (typeof callback === 'function') callback();
                return;
            }

            if (res.success && res.data) {
                $desc.val(res.data.description || '');
                $primary.val(res.data.primary_keyword || '');
                $additional.val(res.data.additional_keywords || '');

                generatedCount++;
                generationSummary.push('✅ Post ' + postId + ' — Success');
            } else {
                $desc.val('');
                failedCount++;
                const message = res.data?.message || 'Unknown error';
                generationSummary.push('❌ Post ' + postId + ' — ' + message);
            }

            $btn.prop('disabled', false).text('Generate Tags');
            if (typeof callback === 'function') callback();
        }).fail(function () {
            console.log('❌ AJAX error on Post', postId);

            $row.removeClass('loading');
            $desc.val('');
            failedCount++;
            generationSummary.push('❌ Post ' + postId + ' — AJAX error');

            $btn.prop('disabled', false).text('Generate Tags');
            if (typeof callback === 'function') callback();
        });
    }

    $('#gem-generate-all').on('click', function () {
        const buttons = $('.generate-tags-btn').filter(function () {
            const $row = $(this).closest('tr');
            const filled =
                $row.find('.gem-primary').val().trim() ||
                $row.find('.gem-additional').val().trim() ||
                $row.find('.gem-description').val().trim();

            if (filled) {
                skippedCount++;
                const postId = $(this).data('post');
                generationSummary.push('⚠️ Post ' + postId + ' — Skipped (already filled)');
                return false;
            }
            return true;
        });

        const total = buttons.length;
        if (total === 0) {
            alert('No empty rows to generate — all appear to be filled.');
            return;
        }

        console.log('🚀 Starting batch generation');

        isGenerating = true;
        generatedCount = 0;
        failedCount = 0;
        skippedCount = 0;
        generationSummary = [];

        $('#gem-stop-generation').show();
        $('#gem-progress-wrapper').show();
        updateProgress(0, total);

        buttons.each(function (i, btn) {
            setTimeout(() => {
                if (!isGenerating) {
                    console.log('⏹ Generation stopped');
                    return;
                }

                console.log('🔄 Generating row', i + 1);
                generateTagsForRow($(btn), function () {
                    updateProgress(i + 1, total);

                    if (i + 1 === total || !isGenerating) {
                        isGenerating = false;
                        $('#gem-stop-generation').hide();
                        //$('#gem-status-download-wrap').fadeIn();

                        const html = generationSummary
                            .map(msg => '<li style="margin-bottom:3px;">' + msg + '</li>')
                            .join('');

                        $('#gem-progress-label').html(
                            '<strong>Generation complete:</strong><br>' +
                            '✅ Generated: ' + generatedCount +
                            ' &nbsp;&nbsp; ❌ Failed: ' + failedCount +
                            ' &nbsp;&nbsp; ⚠️ Skipped: ' + skippedCount +
                            ' &nbsp;&nbsp; 📭 No Content: ' + noContentCount
                        );

                        setTimeout(() => $('#gem-progress-wrapper').fadeOut(), 3000);

                        $('<div class="notice notice-info" style="margin-top:1em;"><p><strong>🧾 Gemini Summary:</strong></p><ul style="padding-left:1.2em; list-style:disc;">' + html + '</ul></div>').insertAfter('#gem-progress-wrapper');
                    }
                });
            }, i * 3000); // ⏱ 1 request every 3 seconds
        });
    });

    $('#gem-stop-generation').on('click', function () {
        isGenerating = false;
        $(this).hide();
        $('#gem-progress-label').text('Generation stopped');
    });

    $(document).on('click', '.generate-tags-btn', function () {
        generateTagsForRow($(this));
    });

    $(document).on('click', '.gem-save-row', function () {
        const $btn = $(this);
        const postId = $btn.data('post');
        const $row = $btn.closest('tr');
        const primary = $row.find('.gem-primary').val();
        const additional = $row.find('.gem-additional').val();
        const description = $row.find('.gem-description').val();

        console.log('💾 Saving Post', postId, {
            primary, additional, description
        });

        $btn.prop('disabled', true).text('💾 Saving...');

        $.post(ajaxurl, {
            action: 'gem_save_row_tags',
            post_id: postId,
            primary,
            additional_keywords: additional,
            description,
            nonce: gem_meta_tags.nonce
        }, function (res) {
            console.log('📬 Save response:', res);
            $btn.prop('disabled', false).text('💾');

            if (res.success) {
                $btn.after('<span class="gem-saved" style="margin-left:5px; color:green;">✅</span>');
                setTimeout(() => $row.find('.gem-saved').fadeOut(500, function () { $(this).remove(); }), 2000);
            } else {
                alert('❌ Save failed: ' + (res.data?.message || 'Unknown error'));
            }
        });
    });
});


/**alt text Gen AI */
// document.getElementById('generate-alt-text-ai').addEventListener('click', function () {
//     const button = this;
//     button.disabled = true;
//     button.textContent = 'Generating...';

//     fetch(ajaxurl, {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//         body: new URLSearchParams({
//             action: 'add_alt_text_to_images_ai'
//         })
//     })
//     .then(response => response.text())
//     .then(data => {
//         document.getElementById('alt-text-result').innerHTML = data;
//         button.disabled = false;
//         button.textContent = 'Generate Alt Text (Gen AI)';
//     })
//     .catch(error => {
//         document.getElementById('alt-text-result').innerHTML = '<p>Error generating alt text.</p>';
//         button.disabled = false;
//         button.textContent = 'Generate Alt Text (Gen AI)';
//         console.error('AJAX error:', error);
//     });
// });
/**end alt text Gen AI */