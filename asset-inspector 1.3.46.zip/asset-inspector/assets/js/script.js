jQuery("th#custom_instance").click(function() {
    jQuery("tr").each(function() {
        var cellValue = jQuery(this).find("td.custom_instance.column-custom_instance").text();
        var checkbox = jQuery(this).find("th.check-column input");
        // Set the default state of the checkbox to unchecked
        checkbox.prop('checked', false);
        
        // Check the checkbox if the cell value is 'None'
        if (cellValue == 'None') {
            checkbox.prop('checked', true);
        }
    });
});
