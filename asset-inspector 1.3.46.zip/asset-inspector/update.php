<?php
add_filter('pre_set_site_transient_update_plugins', function ($transient) {
    if (empty($transient->checked)) return $transient;
  
    $plugin_file = plugin_basename(__FILE__); // site-inspector/site-inspector.php
    $current_version = get_file_data(__FILE__, ['Version' => 'Version'])['Version'] ?? '0.0.0';
  
    $response = wp_remote_get('https://raw.githubusercontent.com/youruser/site-inspector/main/update.json', [
      'timeout' => 8,
      'headers' => ['Accept' => 'application/json']
    ]);
    if (is_wp_error($response)) return $transient;
  
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (!$body || empty($body['version'])) return $transient;
  
    if (version_compare($body['version'], $current_version, '>')) {
      $transient->response[$plugin_file] = (object)[
        'slug'        => 'site-inspector',
        'plugin'      => $plugin_file,
        'new_version' => $body['version'],
        'tested'      => $body['tested'] ?? '',
        'requires'    => $body['requires'] ?? '',
        'package'     => $body['download_url'],
        'url'         => 'https://github.com/youruser/site-inspector'
      ];
    }
  
    return $transient;
  });
  





  add_filter('plugins_api', function ($result, $action, $args) {
    if ($action !== 'plugin_information' || $args->slug !== 'site-inspector') return $result;
  
    $response = wp_remote_get('https://raw.githubusercontent.com/youruser/site-inspector/main/update.json', ['timeout' => 8]);
    if (is_wp_error($response)) return $result;
  
    $b = json_decode(wp_remote_retrieve_body($response), true);
    if (!$b) return $result;
  
    return (object)[
      'name'           => 'Site Inspector',
      'slug'           => 'site-inspector',
      'version'        => $b['version'] ?? '',
      'author'         => '<a href="https://sytian.ai/">Sytian</a>',
      'homepage'       => 'https://github.com/youruser/site-inspector',
      'requires'       => $b['requires'] ?? '',
      'tested'         => $b['tested'] ?? '',
      'requires_php'   => $b['requires_php'] ?? '',
      'download_link'  => $b['download_url'] ?? '',
      'last_updated'   => $b['last_updated'] ?? '',
      'sections'       => [
        'description' => $b['sections']['description'] ?? '',
        'changelog'   => '<pre>' . esc_html($b['sections']['changelog'] ?? '') . '</pre>',
      ],
      'external'       => true
    ];
  }, 10, 3);
  