<?php
function si_render_theme_injector() {
    if (isset($_POST['inject_theme_name'])) {
        si_inject_site_name_into_theme_css();
    }
    ?>
    <div class="wrap"><h1>Theme Setup</h1>
        <form method="post" enctype="multipart/form-data">
            <div style="display: flex; gap: 32px; align-items: flex-start;">
                <div style="flex: 1;">
                    <?php si_render_screenshot_upload(); ?>
                </div>
                <div style="flex: 1;">
                    <?php si_render_theme_info(); ?>
                    <?php submit_button('Update Theme', 'primary', 'inject_theme_name'); ?>
                </div>
            </div>
        </form>
    </div>
    <?php

    si_render_css();
}

function si_inject_site_name_into_theme_css() {
    $theme_folder = get_stylesheet_directory();
    $style_path = $theme_folder . '/style.css';
    $site_name = get_bloginfo('name');

    if (!file_exists($style_path) || !is_writable($style_path)) {
        echo '<div class="notice notice-error"><p>⚠️ style.css missing or not writable.</p></div>';
        return;
    }

    $original_css = file_get_contents($style_path);
    $new_name = "Theme Name: $site_name";
    $new_desc = "Description: This is a custom WordPress Theme for $site_name";
    $updated_date = "Updated: " . date('Y-m-d');

    if (preg_match('/^\\s*\\/\\*(.*?)\\*\\//s', $original_css, $matches)) {
        $header_block = $matches[1];
        $lines = preg_split('/\\r?\\n/', trim($header_block));
        $found_name = $found_desc = $found_updated = false;

        foreach ($lines as &$line) {
            if (stripos($line, 'Theme Name:') === 0) {
                $line = $new_name;
                $found_name = true;
            } elseif (stripos($line, 'Description:') === 0) {
                $line = $new_desc;
                $found_desc = true;
            } elseif (stripos($line, 'Updated:') === 0) {
                $line = $updated_date;
                $found_updated = true;
            }
        }

        if (!$found_name) array_unshift($lines, $new_name);
        if (!$found_desc) array_splice($lines, 1, 0, $new_desc);
        if (!$found_updated) $lines[] = $updated_date;

        $updated_header = implode("\n", $lines);
        $new_css = "/*\n" . $updated_header . "\n*/" . substr($original_css, strlen($matches[0]));
    } else {
        $new_header = "/*\n$new_name\n$new_desc\n$updated_date\n*/\n\n";
        $new_css = $new_header . ltrim($original_css);
    }

    file_put_contents($style_path . '.backup', $original_css);
    file_put_contents($style_path, $new_css);

    echo '<div class="notice notice-success is-dismissible"><p>✅ Theme metadata updated for "' . esc_html($site_name) . '".</p></div>';

    si_handle_screenshot_upload();
}

function si_render_screenshot_upload() {
    $screenshot_dir = get_stylesheet_directory();
    $screenshot_uri = get_stylesheet_directory_uri();
    $site_url = site_url();

      ?>
      <!-- Screenshot Trigger -->
    <div><label class="homepage_screenshot" for="homepage_screenshot"><strong>Upload Homepage Screenshot:</strong></label>
<button type="button" id="captureScreenshot" class="button">📸 Auto-Capture Homepage</button></div>
<div><input type="file" name="homepage_screenshot" id="homepage_screenshot" accept="image/png,image/jpeg,image/jpg" style="margin-top:16px;"></div>

<!-- Preview -->
<div id="screenshotPreview" style="margin-top: 16px;"></div>

    <p>Current Screenshot: </p>
    <?php
    foreach (['png', 'jpg', 'jpeg'] as $ext) {
        $path = "$screenshot_dir/screenshot.$ext";
        if (file_exists($path)) {
            echo '<img src="' . esc_url("$screenshot_uri/screenshot.$ext") . '" alt="Homepage Screenshot" style="width: 100%; border: 1px solid #ccc; max-width: 350px;">';
            break;
        }
    }
    ?>

    <!-- Include html2canvas -->
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>

    

<!-- Modal -->
<div id="captureModal" style="display:none;">
  <div class="captureModal-container">
    <div id="capture-progress"><p id="modalStatus">Capturing homepage screen…</p></div>
    <iframe id="modalCaptureFrame" src="/" style="width:1800px; height:900px; border:1px solid #ccc;"></iframe>
  </div>
</div>



<!-- Logic -->
<script>
const modal = document.getElementById("captureModal");
const iframe = document.getElementById("modalCaptureFrame");
const preview = document.getElementById("screenshotPreview");
const fileInput = document.getElementById("homepage_screenshot");
const modalStatus = document.getElementById("modalStatus");

document.getElementById("captureScreenshot").addEventListener("click", () => {
  preview.innerHTML = "";
  modal.style.display = "flex";
  modalStatus.textContent = "Capturing homepage screen…";
  iframe.src = "/" + "?capture=1&ts=" + Date.now();
});

window.addEventListener("message", async (event) => {
  if (event.data?.type === "screenshot-captured") {
    modalStatus.textContent = "✅ Screenshot captured!";
    modal.style.display = "none";

    const dataUrl = event.data.dataUrl;
    const img = new Image();
    img.src = dataUrl;
    img.style.maxWidth = "350px";
    preview.innerHTML = "<p>New Screenshot: </p>";
    preview.appendChild(img);

    // Convert dataURL to Blob and populate input[type=file]
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    const file = new File([blob], "screenshot.png", { type: "image/png" });

    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    fileInput.files = dataTransfer.files;

    console.log("📥 Screenshot file injected into input[type=file]");
  }
});
</script>

    <?php
}

function si_render_theme_info() {
    $theme = wp_get_theme();
    $site_name = get_bloginfo('name');
    $theme_name = $theme->get('Name');

    echo '<div>';
    echo '<h3>Theme Info</h3>';
    echo '<p><strong>Name:</strong> ' . esc_html($theme_name);
    if ($theme_name !== $site_name) {
        echo ' &rarr; <strong>new name:</strong> <b>' . esc_html($site_name) . '</b>';
    }
    echo '</p>';
    echo '<p><strong>Version:</strong> ' . esc_html($theme->get('Version')) . '</p>';
    echo '<p><strong>Template:</strong> ' . esc_html($theme->get_template()) . '</p>';
    echo '<p><strong>Stylesheet:</strong> ' . esc_html($theme->get_stylesheet()) . '</p>';
    echo '</div>';
}

function si_handle_screenshot_upload() {
    if (!empty($_FILES['homepage_screenshot']['tmp_name'])) {
        $file = $_FILES['homepage_screenshot'];
        error_log('📝 Uploaded file type: ' . $file['type']);
        error_log('📝 Uploaded file name: ' . $file['name']);

        $allowed_types = ['image/png', 'image/jpeg', 'image/jpg'];
        if (!in_array($file['type'], $allowed_types)) {
            error_log('❌ Upload rejected: Unsupported file type.');
            echo '<div class="notice notice-error"><p>❌ Upload failed: Only PNG and JPG formats are supported.</p></div>';
            return;
        }

        $theme_root = get_stylesheet_directory();
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $target_file = $theme_root . '/screenshot.' . $extension;

        foreach (['png', 'jpg', 'jpeg'] as $ext) {
            $old_file = $theme_root . '/screenshot.' . $ext;
            if (file_exists($old_file)) {
                unlink($old_file);
                error_log('🧹 Deleted old screenshot: ' . $old_file);
            }
        }

        if (move_uploaded_file($file['tmp_name'], $target_file)) {
            error_log('✅ Screenshot saved at: ' . $target_file);
            echo '<div class="notice notice-success is-dismissible"><p>🖼️ Screenshot uploaded successfully.</p></div>';
        } else {
            error_log('❌ Failed to move uploaded file.');
            echo '<div class="notice notice-error"><p>⚠️ Failed to save the screenshot. Please check folder permissions.</p></div>';
        }
    } else {
        error_log('ℹ️ No file uploaded.');
        echo '<div class="notice notice-warning"><p>ℹ️ No screenshot was selected for upload.</p></div>';
    }
}

add_action('wp_footer', function () {
    if (isset($_GET['capture']) && $_GET['capture'] === '1') {
        ?>
        <style>
        html { margin-top: 0 !important; }
        </style>
        <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
            console.log("📦 DOM loaded — preparing scroll animation");

            const adminBar = document.getElementById("wpadminbar");
            if (adminBar) {
                adminBar.style.display = "none";
                console.log("🧹 Admin bar hidden");
            }

            // Scroll down and back up to trigger animations
            window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
            setTimeout(() => {
                window.scrollTo({ top: 0, behavior: "smooth" });
                console.log("🔁 Scroll animation complete — waiting before capture");

                setTimeout(() => {
                console.log("⏱️ Delay complete — starting html2canvas");
                html2canvas(document.body, {
                    useCORS: true,
                    allowTaint: false,
                    logging: true,
                    windowWidth: document.documentElement.scrollWidth,
                    windowHeight: document.documentElement.scrollHeight
                }).then(canvas => {
                    console.log("🖼️ Canvas rendered:", canvas);
                    const cropWidth = canvas.width;
                    const cropHeight = Math.floor(cropWidth * 3 / 4);
                    const croppedCanvas = document.createElement("canvas");
                    croppedCanvas.width = 880;
                    croppedCanvas.height = 660;
                    const ctx = croppedCanvas.getContext("2d");
                    ctx.drawImage(canvas, 0, 0, cropWidth, cropHeight, 0, 0, 880, 660);
                    const dataUrl = croppedCanvas.toDataURL();
                    console.log("📤 Cropped screenshot sent to parent. Length:", dataUrl.length);
                    window.parent.postMessage({ type: "screenshot-captured", dataUrl: dataUrl }, "*");
                }).catch(err => {
                    console.error("❌ html2canvas failed:", err);
                });
                }, 12000); // Wait after scroll to allow animations
            }, 3000); // Scroll duration
            });
            </script>

        <?php
    }
});



function si_render_css(){
    ?>
<style>
p#modalStatus {
    font-size: 18px;
    margin-bottom: 16px;
    top: 50%;
    position: relative;
    width: 330px;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #fff;
    padding: 20px;
    border-radius: 20px;
}
div#capture-progress {
    position: absolute;
    top: 0;
    bottom: 0;
    margin: auto;
    width: 100%;
    background: #000000bf;
}
.captureModal-container{
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
    text-align: center;
    overflow: hidden;
}
div#captureModal {
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: #000000aa;
    z-index: 9999;
    justify-content: center;
    align-items: center;
    padding: 40px;
    position: fixed;
    box-sizing: border-box;
}
label.homepage_screenshot {
    display: block;
    margin-bottom: 10px;
}
</style>
    <?php
}