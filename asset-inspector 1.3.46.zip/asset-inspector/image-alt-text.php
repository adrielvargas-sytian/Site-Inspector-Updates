<?php
// AJAX handler for updating Alt Text
function update_alt_text_ajax_handler() {
    // Verify nonce for security
    check_ajax_referer('update_alt_text_nonce', 'security');

    // Get the image ID and new Alt text from the request
    $image_id = intval($_POST['image_id']);
    $alt_text = sanitize_text_field($_POST['alt_text']);

    // Update the Alt text in the database
    if (update_post_meta($image_id, '_wp_attachment_image_alt', $alt_text)) {
        wp_send_json_success(array(
            'message' => 'Alt text updated successfully.',
            'alt_text' => $alt_text,
        ));
    } else {
        wp_send_json_error(array(
            'message' => 'Failed to update Alt text. Please try again.',
        ));
    }

    wp_die(); // End the AJAX request
}
add_action('wp_ajax_update_alt_text', 'update_alt_text_ajax_handler');




// Display the settings page
function iat_settings_page(){
    // Generate nonce for AJAX requests
    $nonce = wp_create_nonce('update_alt_text_nonce');

    // Retrieve all images to list in the table
    $images = get_posts(array(
        'post_type' => 'attachment',
        'posts_per_page' => -1,
        'post_status' => 'any',
        'meta_query' => [
          [
            'key'     => '_wp_attachment_metadata',
            'compare' => 'EXISTS'
          ]
        ]
      ));
      
      // BEFORE building the table in iat_settings_page()
        $font_attachment_ids = ic_get_elementor_font_attachment_ids();

        // Start with all attachments you already queried
        // $images = get_posts([...]); // existing code

        // Count how many SVG font attachments are present in the fetched set
        $svg_font_count = 0;
        foreach ($images as $img) {
        $mime = get_post_mime_type($img->ID);
        if ($mime === 'image/svg+xml' && in_array((int) $img->ID, $font_attachment_ids, true)) {
            $svg_font_count++;
        }
        }

        $filtered_images = array_filter($images, function($img) use ($font_attachment_ids) {
        $mime = get_post_mime_type($img->ID);
        // Include only images
        if (strpos($mime, 'image/') !== 0) return false;

        // Exclude any attachment that is a known Elementor font SVG
        if ($mime === 'image/svg+xml' && in_array((int)$img->ID, $font_attachment_ids, true)) {
            return false;
        }

        return true;
        });


      

?><div class="wrap">
<h1>Image Alt Text Generator</h1>
<?php
    iat_handle_alt_functions();
    iat_render_filter_control($filtered_images,$images);
    iat_render_table($filtered_images);
    iat_render_filter_control($filtered_images,$images);
    iat_handle_scripts_css();
?>
    </div>
<?php

}

function iat_handle_scripts_css() {
    $ajax_url = json_encode(admin_url('admin-ajax.php'));
    $nonce = json_encode(wp_create_nonce('update_alt_text_nonce'));
  ?>
  <script>
  document.addEventListener('DOMContentLoaded', function () {
    const ajaxUrl = <?php echo $ajax_url; ?>;
    const securityNonce = <?php echo $nonce; ?>;
  
    // Toggle edit/save UI
    document.querySelectorAll('.edit-alt-text-button').forEach(button => {
      button.addEventListener('click', () => {
        const row = button.closest('tr');
        const input = row.querySelector('.alt-text-input');
        const display = row.querySelector('.alt-text-display');
        const save = row.querySelector('.save-alt-text-button');
  
        const isEditing = input.style.display === 'block';
        input.style.display = isEditing ? 'none' : 'block';
        display.style.display = isEditing ? 'block' : 'none';
        save.style.display = isEditing ? 'none' : 'inline-block';
      });
    });
  
    // Save alt text via AJAX
    document.querySelectorAll('.save-alt-text-button').forEach(button => {
      button.addEventListener('click', async () => {
        const row = button.closest('tr');
        const input = row.querySelector('.alt-text-input');
        const display = row.querySelector('.alt-text-display');
        const imageId = button.dataset.imageId;
        const newAltText = input.value;
  
        button.classList.add('loading');
  
        try {
          const response = await fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
              action: 'update_alt_text',
              security: securityNonce,
              image_id: imageId,
              alt_text: newAltText
            })
          });
  
          const result = await response.json();
          if (result.success) {
            display.textContent = result.data.alt_text;
            input.style.display = 'none';
            display.style.display = 'block';
            button.style.display = 'none';
          } else {
            alert(result.data.message || 'Failed to update alt text.');
          }
        } catch (err) {
          console.error('Alt text update failed:', err);
          alert('An error occurred while updating the Alt text.');
        } finally {
          button.classList.remove('loading');
        }
      });
    });
  
    // Bulk generate alt text
    const generateBtn = document.getElementById('generate-alt-text-ai');
    if (generateBtn) {
      generateBtn.addEventListener('click', async () => {
        const rows = Array.from(document.querySelectorAll('tbody tr')).filter(row => {
          const span = row.querySelector('[id^="alt-text-display-"]');
          return span && span.textContent.trim() === '';
        });
  
        const total = rows.length;
        if (total === 0) return;
  
        const progressBar = document.getElementById('alt-text-progress');
        const counter = document.getElementById('alt-text-counter');
        const failureDisplay = document.getElementById('alt-text-failures');
        const container = document.getElementById('alt-text-progress-container');
  
        container.style.display = 'block';
        progressBar.value = 0;
        counter.textContent = `0 / ${total}`;
        failureDisplay.textContent = `Failed: 0`;
  
        let failures = 0;
  
        for (let i = 0; i < total; i++) {
          const row = rows[i];
          const span = row.querySelector('[id^="alt-text-display-"]');
          const imageId = span.id.replace('alt-text-display-', '');
          span.textContent = 'Generating...';
  
          try {
            const response = await fetch(ajaxUrl, {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: new URLSearchParams({
                action: 'generate_single_alt_text_ai',
                image_id: imageId,
                security: securityNonce
              })
            });
  
            const result = await response.json();
            const altText = result?.data?.alt_text || '';
  
            if (altText) {
              span.textContent = altText;
            } else {
              span.textContent = '[No alt text returned]';
              failures++;
            }
          } catch (err) {
            console.error(`Error generating alt text for image ${imageId}`, err);
            span.textContent = '[Error generating alt text]';
            failures++;
          }
  
          const percent = Math.round(((i + 1) / total) * 100);
          progressBar.value = percent;
          counter.textContent = `${i + 1 - failures} / ${total}`;
          failureDisplay.textContent = `Failed: ${failures}`;
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
  
        progressBar.value = 100;
        counter.textContent = `${total - failures} / ${total}`;
        failureDisplay.textContent = `Failed: ${failures}`;
      });
    }
  });
  </script>
  <style>
    .button-primary { background-color: #007cba; color: #fff; border: none; }
    .button-primary:hover { background-color: #005177; }
    .button-secondary { background-color: #46b450; color: #fff; border: none; }
    .button-secondary:hover { background-color: #3e9e44; }
    .edit-alt-text-button { background: none; border: none; cursor: pointer; }
    .edit-alt-text-button .dashicons-edit { font-size: 20px; color: #007cba; }
    .edit-alt-text-button:hover .dashicons-edit { color: #005177; }
    .save-alt-text-button { background-color: #46b450; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; }
    .save-alt-text-button .dashicons-yes { font-size: 20px; color: white; }
    .save-alt-text-button:hover { background-color: #3e9e44; }
    .alt-text-display { margin-right: 8px; }
    #alt-text-progress.complete::-webkit-progress-value { background-color: #4caf50; }
    #alt-text-progress.complete::-moz-progress-bar { background-color: #4caf50; }
  </style>
  <?php
  }
  

function iat_handle_alt_functions(){
    // Handle Regenerate Alt Text button click
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['regenerate_alt_text'])) {
        // Remove all existing Alt text
        remove_all_alt_text();

        // Call the function to regenerate Alt text
        add_alt_text_to_images();
        echo '<div class="updated"><p>Alt text has been successfully regenerated for all images.</p></div>';
    }

    // Handle Generate Alt Text button click
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_alt_text'])) {
        // Call the function to generate Alt text for images without Alt text
        add_alt_text_to_images();
        echo '<div class="updated"><p>Alt text has been successfully generated for images without Alt Text.</p></div>';
    }

   


    // Handle remode Alt Text button click
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_alt_text'])) {
        // Call the function to generate Alt text for images without Alt text
        remove_all_alt_text();
        echo '<div class="updated"><p>Alt text has been removed.</p></div>';
    }
}

function iat_render_filter_control($filtered_images,$images){
    // BEFORE building the table in iat_settings_page()
    $font_attachment_ids = ic_get_elementor_font_attachment_ids();

    // Start with all attachments you already queried
    // $images = get_posts([...]); // existing code

    // Count how many SVG font attachments are present in the fetched set
    $svg_font_count = 0;
    foreach ($images as $img) {
    $mime = get_post_mime_type($img->ID);
    if ($mime === 'image/svg+xml' && in_array((int) $img->ID, $font_attachment_ids, true)) {
        $svg_font_count++;
    }
    }
    $total_images = count($filtered_images);
    $with_alt = count(array_filter($filtered_images, fn($img) => trim(get_post_meta($img->ID, '_wp_attachment_image_alt', true)) !== ''));
    $without_alt = $total_images - $with_alt;
    ?>
    <!-- Combined Form with both buttons -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin: 10px 0;">
            <form method="post" action="" style="display: flex; gap: 10px;">
                <?php /* <button type="submit" name="generate_alt_text" class="button-primary">Generate Alt Text</button>*/?>
                
                <button type="button" id="generate-alt-text-ai" class="button-primary">Generate Alt Text (Gemini)</button>

                <?php /*<button type="submit" name="regenerate_alt_text" class="button-secondary">Regenerate Alt Text</button>*/?>
                <button type="submit" name="remove_alt_text" class="button-secondary">Remove Alt Text</button>
            </form>
            <div style="margin-right:10px;">
                <strong>Total Images:</strong> <?= $total_images + $svg_font_count ?> |
                <span style="color: green;"><strong>With Alt Text:</strong> <?= $with_alt ?></span> |
                <span style="color: red;"><strong>Without Alt Text:</strong> <?= $without_alt ?></span> |
                <span style=""><strong>SVG Fonts:</strong> <?= $svg_font_count ?></span>
            </div>
        </div>
        <?php
}

function iat_render_table($filtered_images){
    ?>
<div id="alt-text-progress-container" style="display: none; margin-bottom: 1em;">
            <label for="alt-text-progress">Generating Alt Texts:</label>
            <div style="display: flex; align-items: center; gap: 12px;">
                <progress id="alt-text-progress" value="0" max="100" style="width: 100%; height: 20px;"></progress>
                <span id="alt-text-counter" style="white-space: nowrap;">0 / 0</span>
                <span id="alt-text-failures" style="color: red; white-space: nowrap;">Failed: 0</span>
            </div>
        </div>
        

        <table class="wp-list-table widefat fixed striped" style="table-layout: auto;">
            <thead>
                <tr>
                    <th style="width: 100px;">Thumbnail</th> <!-- Thumbnail column -->
                    <th style="width: 55px;">ID</th>         <!-- ID column -->
                    <th>Title</th>
                    <th>Alt Text</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($filtered_images as $image) :
                    $alt_text = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
                    $thumbnail = wp_get_attachment_image($image->ID, 'thumbnail', false, array('style' => 'width:100px;height:100px;'));
                ?>
                    <tr>
                        <td><?php echo $thumbnail; ?></td> <!-- Thumbnail -->
                        <td><?php echo $image->ID; ?></td> <!-- ID -->
                        <td><?php echo $image->post_title; ?></td> <!-- Title -->
                        <td>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <span class="alt-text-display" id="alt-text-display-<?php echo $image->ID; ?>">
                                    <?php echo esc_html($alt_text); ?>
                                </span>
                                <input type="text" class="alt-text-input" 
                                       value="<?php echo esc_attr($alt_text); ?>" 
                                       style="display: none;" 
                                       id="alt-text-input-<?php echo $image->ID; ?>">
                                <button type="button" class="save-alt-text-button" 
                                        data-image-id="<?php echo $image->ID; ?>" 
                                        style="display: none;">
                                    <span class="dashicons dashicons-yes"></span>
                                </button>
                                <button type="button" class="edit-alt-text-button" data-image-id="<?php echo $image->ID; ?>">
                                    <span class="dashicons dashicons-edit"></span>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div id="alt-text-result"></div>

<?php
}
function iat_settings_page_old() {
    // Generate nonce for AJAX requests
    $nonce = wp_create_nonce('update_alt_text_nonce');

    // Retrieve all images to list in the table
    $images = get_posts(array(
        'post_type' => 'attachment',
        'posts_per_page' => -1,
        'post_status' => 'any',
        'meta_query' => [
          [
            'key'     => '_wp_attachment_metadata',
            'compare' => 'EXISTS'
          ]
        ]
      ));
      
      // BEFORE building the table in iat_settings_page()
        $font_attachment_ids = ic_get_elementor_font_attachment_ids();

        // Start with all attachments you already queried
        // $images = get_posts([...]); // existing code

        // Count how many SVG font attachments are present in the fetched set
        $svg_font_count = 0;
        foreach ($images as $img) {
        $mime = get_post_mime_type($img->ID);
        if ($mime === 'image/svg+xml' && in_array((int) $img->ID, $font_attachment_ids, true)) {
            $svg_font_count++;
        }
        }

        $filtered_images = array_filter($images, function($img) use ($font_attachment_ids) {
        $mime = get_post_mime_type($img->ID);
        // Include only images
        if (strpos($mime, 'image/') !== 0) return false;

        // Exclude any attachment that is a known Elementor font SVG
        if ($mime === 'image/svg+xml' && in_array((int)$img->ID, $font_attachment_ids, true)) {
            return false;
        }

        return true;
        });


      $total_images = count($filtered_images);
$with_alt = count(array_filter($filtered_images, fn($img) => trim(get_post_meta($img->ID, '_wp_attachment_image_alt', true)) !== ''));
$without_alt = $total_images - $with_alt;

      

    ?>
    <div class="wrap">
        <h1>Image Alt Text Generator</h1>
        

        <?php
        // Handle Regenerate Alt Text button click
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['regenerate_alt_text'])) {
            // Remove all existing Alt text
            remove_all_alt_text();

            // Call the function to regenerate Alt text
            add_alt_text_to_images();
            echo '<div class="updated"><p>Alt text has been successfully regenerated for all images.</p></div>';
        }

        // Handle Generate Alt Text button click
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_alt_text'])) {
            // Call the function to generate Alt text for images without Alt text
            add_alt_text_to_images();
            echo '<div class="updated"><p>Alt text has been successfully generated for images without Alt Text.</p></div>';
        }

       


        // Handle remode Alt Text button click
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_alt_text'])) {
            // Call the function to generate Alt text for images without Alt text
            remove_all_alt_text();
            echo '<div class="updated"><p>Alt text has been removed.</p></div>';
        }
        ?>

        <!-- Combined Form with both buttons -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin: 10px 0;">
            <form method="post" action="" style="display: flex; gap: 10px;">
                <?php /* <button type="submit" name="generate_alt_text" class="button-primary">Generate Alt Text</button>*/?>
                
                <button type="button" id="generate-alt-text-ai" class="button-primary">Generate Alt Text (Gemini)</button>

                <?php /*<button type="submit" name="regenerate_alt_text" class="button-secondary">Regenerate Alt Text</button>*/?>
                <button type="submit" name="remove_alt_text" class="button-secondary">Remove Alt Text</button>
            </form>
            <div style="margin-right:10px;">
                <strong>Total Images:</strong> <?= $total_images + $svg_font_count ?> |
                <span style="color: green;"><strong>With Alt Text:</strong> <?= $with_alt ?></span> |
                <span style="color: red;"><strong>Without Alt Text:</strong> <?= $without_alt ?></span> |
                <span style=""><strong>SVG Fonts:</strong> <?= $svg_font_count ?></span>
            </div>
        </div>
        

        <div id="alt-text-progress-container" style="display: none; margin-bottom: 1em;">
            <label for="alt-text-progress">Generating Alt Texts:</label>
            <div style="display: flex; align-items: center; gap: 12px;">
                <progress id="alt-text-progress" value="0" max="100" style="width: 100%; height: 20px;"></progress>
                <span id="alt-text-counter" style="white-space: nowrap;">0 / 0</span>
                <span id="alt-text-failures" style="color: red; white-space: nowrap;">Failed: 0</span>
            </div>
        </div>
        

        <table class="wp-list-table widefat fixed striped" style="table-layout: auto;">
            <thead>
                <tr>
                    <th style="width: 100px;">Thumbnail</th> <!-- Thumbnail column -->
                    <th style="width: 55px;">ID</th>         <!-- ID column -->
                    <th>Title</th>
                    <th>Alt Text</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($filtered_images as $image) :
                    $alt_text = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
                    $thumbnail = wp_get_attachment_image($image->ID, 'thumbnail', false, array('style' => 'width:100px;height:100px;'));
                ?>
                    <tr>
                        <td><?php echo $thumbnail; ?></td> <!-- Thumbnail -->
                        <td><?php echo $image->ID; ?></td> <!-- ID -->
                        <td><?php echo $image->post_title; ?></td> <!-- Title -->
                        <td>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <span class="alt-text-display" id="alt-text-display-<?php echo $image->ID; ?>">
                                    <?php echo esc_html($alt_text); ?>
                                </span>
                                <input type="text" class="alt-text-input" 
                                       value="<?php echo esc_attr($alt_text); ?>" 
                                       style="display: none;" 
                                       id="alt-text-input-<?php echo $image->ID; ?>">
                                <button type="button" class="save-alt-text-button" 
                                        data-image-id="<?php echo $image->ID; ?>" 
                                        style="display: none;">
                                    <span class="dashicons dashicons-yes"></span>
                                </button>
                                <button type="button" class="edit-alt-text-button" data-image-id="<?php echo $image->ID; ?>">
                                    <span class="dashicons dashicons-edit"></span>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div id="alt-text-result"></div>

    </div>

    <script>
        jQuery(document).ready(function ($) {
            $('.edit-alt-text-button').on('click', function (e) {
                e.preventDefault();

                const button = $(this);
                const row = button.closest('tr');
                const inputField = row.find('.alt-text-input');
                const displayField = row.find('.alt-text-display');
                const saveButton = row.find('.save-alt-text-button');

                // Toggle visibility
                if (inputField.is(':visible')) {
                    inputField.hide();
                    displayField.show();
                    saveButton.hide();
                } else {
                    inputField.show();
                    displayField.hide();
                    saveButton.show();
                }
            });

            $('.save-alt-text-button').on('click', function (e) {
                e.preventDefault();

                const button = $(this);
                const row = button.closest('tr');
                const inputField = row.find('.alt-text-input');
                const displayField = row.find('.alt-text-display');
                const imageId = button.data('image-id');
                const newAltText = inputField.val();

                // Send AJAX request
                $.ajax({
                    url: "<?php echo admin_url('admin-ajax.php'); ?>",
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'update_alt_text',
                        security: "<?php echo $nonce; ?>",
                        image_id: imageId,
                        alt_text: newAltText,
                    },
                    beforeSend: function () {
                        button.addClass('loading');
                    },
                    success: function (response) {
                        button.removeClass('loading');
                        if (response.success) {
                            displayField.text(response.data.alt_text);
                            inputField.hide();
                            displayField.show();
                            button.hide();
                        } else {
                            alert(response.data.message);
                        }
                    },
                    error: function () {
                        button.removeClass('loading');
                        alert('An error occurred while updating the Alt text.');
                    },
                });
            });
        });
    </script>

<script>
    document.getElementById('alt-text-progress-container').style.display = 'none';
    
    document.getElementById('generate-alt-text-ai').addEventListener('click', async function () {
    const allRows = document.querySelectorAll('tbody tr');
    const rowsToProcess = Array.from(allRows).filter(row => {
        const displaySpan = row.querySelector('[id^="alt-text-display-"]');
        return displaySpan && displaySpan.textContent.trim() === '';
    });

    const total = rowsToProcess.length;
    if (total === 0) return;

    const progressBar = document.getElementById('alt-text-progress');
    const counter = document.getElementById('alt-text-counter');
    const failureDisplay = document.getElementById('alt-text-failures');
    const container = document.getElementById('alt-text-progress-container');

    container.style.display = 'block';
    progressBar.value = 0;
    counter.textContent = `0 / ${total}`;
    failureDisplay.textContent = `Failed: 0`;

    let failures = 0;
    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

    for (let i = 0; i < total; i++) {
        const row = rowsToProcess[i];
        const displaySpan = row.querySelector('[id^="alt-text-display-"]');
        const imageId = displaySpan.id.replace('alt-text-display-', '');

        displaySpan.textContent = 'Generating...';

        let altText = '';
        try {
            const response = await fetch(ajaxurl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'generate_single_alt_text_ai',
                    image_id: imageId
                })
            });

            const result = await response.json();
            altText = result?.data?.alt_text || '';
        } catch (error) {
            console.error('Fetch error for image ID', imageId, error);
        }

        if (altText) {
            displaySpan.textContent = altText;
        } else {
            displaySpan.textContent = '[No alt text returned]';
            failures++;
        }

        const percent = Math.round(((i + 1) / total) * 100);
        progressBar.value = percent;
        counter.textContent = `${i + 1 - failures} / ${total}`;
        failureDisplay.textContent = `Failed: ${failures}`;

        await delay(1000);
    }

    progressBar.value = 100;
    counter.textContent = `${total - failures} / ${total}`;
    failureDisplay.textContent = `Failed: ${failures}`;
});
</script>

    <style>
        /* Style for the buttons */
        form button {
            display: inline-block;
            padding: 10px 20px;
            margin: 0;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .button-primary {
            background-color: #007cba;
            color: #ffffff;
            border: none;
        }

        .button-primary:hover {
            background-color: #005177;
        }

        .button-secondary {
            background-color: #46b450;
            color: #ffffff;
            border: none;
        }

        .button-secondary:hover {
            background-color: #3e9e44;
        }

        /* Style for the edit (pencil) button */
        button.edit-alt-text-button {
            background-color: transparent;
            border: none;
            cursor: pointer;
        }

        button.edit-alt-text-button .dashicons-edit {
            font-size: 20px;
            color: #007cba;
        }

        button.edit-alt-text-button:hover .dashicons-edit {
            color: #005177;
        }

        /* Style for the save (checkmark) button */
        button.save-alt-text-button {
            background-color: #46b450;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }

        button.save-alt-text-button .dashicons-yes {
            font-size: 20px;
            color: white;
        }

        button.save-alt-text-button:hover {
            background-color: #3e9e44;
        }

        /* Align input and buttons nicely */
        .alt-text-display {
            margin-right: 8px;
        }
        #alt-text-progress.complete::-webkit-progress-value {
        background-color: #4caf50;
        }
        #alt-text-progress.complete::-moz-progress-bar {
        background-color: #4caf50;
        }
    </style>
    <?php
}

// Function to remove all Alt text
function remove_all_alt_text() {
    // Retrieve all image attachments from the media library
    $images = get_posts(array(
        'post_type' => 'attachment',
        'posts_per_page' => -1,
        'post_status' => 'any',
        'meta_query' => [
          [
            'key'     => '_wp_attachment_metadata',
            'compare' => 'EXISTS'
          ]
        ]
      ));
      
      // BEFORE building the table in iat_settings_page()
      $font_attachment_ids = ic_get_elementor_font_attachment_ids();

      // Start with all attachments you already queried
      // $images = get_posts([...]); // existing code

      // Count how many SVG font attachments are present in the fetched set
      $svg_font_count = 0;
      foreach ($images as $img) {
      $mime = get_post_mime_type($img->ID);
      if ($mime === 'image/svg+xml' && in_array((int) $img->ID, $font_attachment_ids, true)) {
          $svg_font_count++;
      }
      }

$filtered_images = array_filter($images, function($img) use ($font_attachment_ids) {
  $mime = get_post_mime_type($img->ID);
  // Include only images
  if (strpos($mime, 'image/') !== 0) return false;

  // Exclude any attachment that is a known Elementor font SVG
  if ($mime === 'image/svg+xml' && in_array((int)$img->ID, $font_attachment_ids, true)) {
    return false;
  }

  return true;
});


      $total_images = count($filtered_images);
$with_alt = count(array_filter($filtered_images, fn($img) => trim(get_post_meta($img->ID, '_wp_attachment_image_alt', true)) !== ''));
$without_alt = $total_images - $with_alt;

      

    // Loop through each image and remove Alt text
    foreach ($filtered_images as $image) {
        delete_post_meta($image->ID, '_wp_attachment_image_alt'); // Remove the Alt text
    }
}




// generate alt text function
function add_alt_text_to_images() {
    // Retrieve all image attachments from the media library
    $images = get_posts(array(
        'post_type' => 'attachment',
        'posts_per_page' => -1,
        'post_status' => 'any',
        'meta_query' => [
          [
            'key'     => '_wp_attachment_metadata',
            'compare' => 'EXISTS'
          ]
        ]
      ));
      
      // BEFORE building the table in iat_settings_page()
      $font_attachment_ids = ic_get_elementor_font_attachment_ids();

      // Start with all attachments you already queried
      // $images = get_posts([...]); // existing code

      // Count how many SVG font attachments are present in the fetched set
      $svg_font_count = 0;
      foreach ($images as $img) {
      $mime = get_post_mime_type($img->ID);
      if ($mime === 'image/svg+xml' && in_array((int) $img->ID, $font_attachment_ids, true)) {
          $svg_font_count++;
      }
      }

$filtered_images = array_filter($images, function($img) use ($font_attachment_ids) {
  $mime = get_post_mime_type($img->ID);
  // Include only images
  if (strpos($mime, 'image/') !== 0) return false;

  // Exclude any attachment that is a known Elementor font SVG
  if ($mime === 'image/svg+xml' && in_array((int)$img->ID, $font_attachment_ids, true)) {
    return false;
  }

  return true;
});


      $total_images = count($filtered_images);
$with_alt = count(array_filter($filtered_images, fn($img) => trim(get_post_meta($img->ID, '_wp_attachment_image_alt', true)) !== ''));
$without_alt = $total_images - $with_alt;

      

    // Get the site name
    $site_name = get_bloginfo('name');

    // Loop through each image
    foreach ($filtered_images as $image) {
        // Get the current alt text for the image
        $alt_text = get_post_meta($image->ID, '_wp_attachment_image_alt', true);

        // Retrieve the original filename (title of the attachment)
        $filename = $image->post_title;

        // Initialize $new_alt_text for the alt text
        $new_alt_text = '';

        
        
        // Handle hash-style social filenames (e.g., long numeric blobs with optional "(1)" suffix)
        if (preg_match('/^\d{6,}(_\d+)*(_n)?(\s*\(\d+\))?$/i', $filename)) {
            if (!empty($image->post_parent)) {
                $new_alt_text = get_the_title($image->post_parent);
            } else {
                $new_alt_text = $site_name . ' image';
            }
        }

        // Handle default camera patterns
        elseif (preg_match('/^(IMG|DSCF|DCIM|PXL|Picture)[_ ]?\d{6,}(_\d{6,})*/i', $filename)) {
            // Check if the image is uploaded to a post (parent post exists)
            if (!empty($image->post_parent)) {
                $parent_post_title = get_the_title($image->post_parent);

                // Ensure the parent post title is not the same as the filename
                if (!empty($parent_post_title) && $filename !== $parent_post_title) {
                    $new_alt_text = $parent_post_title;
                } else {
                    // Fall back to "site name + image" if conditions are not met
                    $new_alt_text = $site_name . ' image';
                }
            } else {
                // If no parent post exists, fall back to "site name + image"
                $new_alt_text = $site_name . ' image';
            }
        } else {
            // Perform filename modifications for non-camera filenames

            // Remove suffix like "_2176x1224_05_2023"
            $new_alt_text = preg_replace('/_\d{2,4}x\d{2,4}_\d{2}_\d{4}$/i', '', $filename);            

            // Remove unnecessary keywords (e.g., "LOGO", "scaled", "Photoroom")
            $new_alt_text = preg_replace('/LOGO|scaled|Photoroom/i', '', $new_alt_text);
            $new_alt_text = trim($new_alt_text, " -");

            // Remove numeric patterns in parentheses (e.g., "(01)")
            $new_alt_text = preg_replace('/\s*\(\d+\)$/', '', $new_alt_text);
            $new_alt_text = trim($new_alt_text, " -");

            // Remove image dimensions (e.g., "-300x300")
            $new_alt_text = preg_replace('/-\d+x\d+$/', '', $new_alt_text);
            $new_alt_text = trim($new_alt_text, " -");

            // Remove trailing numeric patterns (e.g., "Image 01")
            $new_alt_text = preg_replace('/\s+\d+$/', '', $new_alt_text);
            $new_alt_text = trim($new_alt_text, " -");

            // Replace dashes with spaces, but retain isolated dashes
            if (substr_count($new_alt_text, '-') > 1) {
                $new_alt_text = str_replace('-', ' ', $new_alt_text);
            }
             // Replace underscores with spaces, but retain isolated underscores
             if (substr_count($new_alt_text, '_') > 1) {
                $new_alt_text = str_replace('_', ' ', $new_alt_text);
            }
            $new_alt_text = trim($new_alt_text, " -");

            // Remove file format extensions (e.g., ".jpg", ".png")
            $new_alt_text = preg_replace('/\.[^.\s]+$/', '', $new_alt_text);
            $new_alt_text = trim($new_alt_text, " -");

            // If the filename is entirely numeric, use the parent post title instead
            if (is_numeric($new_alt_text)) {
                $parent_post_title = get_the_title($image->post_parent);
                $new_alt_text = $parent_post_title;
            }
            $new_alt_text = trim($new_alt_text, " -");

            // Decode HTML entities in the new alt text to ensure proper formatting
            $new_alt_text = html_entity_decode($new_alt_text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $new_alt_text = trim($new_alt_text, " -");
        }

        // Ensure no multiple spaces side by side
        $new_alt_text = preg_replace('/\s+/', ' ', $new_alt_text);
        $new_alt_text = trim($new_alt_text);

        // Update the alt text if it's currently empty and the new alt text is not empty
        if (!empty($new_alt_text) && empty($alt_text)) {
            update_post_meta($image->ID, '_wp_attachment_image_alt', $new_alt_text);
        }
    }
}



// // generate alt text function
// function add_alt_text_to_images_ai() {
//     // Retrieve all image attachments from the media library
//     $images = get_posts(array(
//         'post_type' => 'attachment',        // Filter for attachment post type
//         'posts_per_page' => -1,            // Retrieve all attachments without pagination
//         'post_mime_type' => 'image',       // Only fetch image attachments
//         'post_status' => 'any',            // Include all attachment statuses
//     ));

//     // Get the site name
//     $site_name = get_bloginfo('name');

//     // Loop through each image
//     foreach ($images as $image) {
//         // Get the current alt text for the image
//         $alt_text = get_post_meta($image->ID, '_wp_attachment_image_alt', true);

        

//         // Update the alt text if it's currently empty and the new alt text is not empty
//         if (empty($alt_text)) {
//             $result = generate_gemini_alt_text($image->ID) ."<br>";
//         }
//         echo '<h3>Result for '.$image->ID.':</h3><pre>' . $result . '</pre>';
//     }
// }


add_action('wp_ajax_add_alt_text_to_images_ai', 'add_alt_text_to_images_ai');

function add_alt_text_to_images_ai() {
    $images = get_posts(array(
        'post_type' => 'attachment',
        'posts_per_page' => -1,
        'post_status' => 'any',
        'meta_query' => [
          [
            'key'     => '_wp_attachment_metadata',
            'compare' => 'EXISTS'
          ]
        ]
      ));
      
      // BEFORE building the table in iat_settings_page()
      $font_attachment_ids = ic_get_elementor_font_attachment_ids();

      // Start with all attachments you already queried
      // $images = get_posts([...]); // existing code

      // Count how many SVG font attachments are present in the fetched set
      $svg_font_count = 0;
      foreach ($images as $img) {
      $mime = get_post_mime_type($img->ID);
      if ($mime === 'image/svg+xml' && in_array((int) $img->ID, $font_attachment_ids, true)) {
          $svg_font_count++;
      }
      }

$filtered_images = array_filter($images, function($img) use ($font_attachment_ids) {
  $mime = get_post_mime_type($img->ID);
  // Include only images
  if (strpos($mime, 'image/') !== 0) return false;

  // Exclude any attachment that is a known Elementor font SVG
  if ($mime === 'image/svg+xml' && in_array((int)$img->ID, $font_attachment_ids, true)) {
    return false;
  }

  return true;
});


      $total_images = count($filtered_images);
        $with_alt = count(array_filter($filtered_images, fn($img) => trim(get_post_meta($img->ID, '_wp_attachment_image_alt', true)) !== ''));
        $without_alt = $total_images - $with_alt;

      

    $site_name = get_bloginfo('name');
    $output = '';

    foreach ($filtered_images as $image) {
        $alt_text = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
        $new_alt_text = generate_gemini_alt_text($image->ID); // Ensure this returns a string

        if (!empty($new_alt_text) && empty($alt_text)) {
            update_post_meta($image->ID, '_wp_attachment_image_alt', sanitize_text_field($new_alt_text));
            $output .= '<strong>' . esc_html($image->post_title) . ':</strong> ' . esc_html($new_alt_text) . '<br>';
        }
    }

    echo '<h2>Generated Alt Texts:</h2><pre>' . $output . '</pre>';
    wp_die(); // Required to terminate AJAX properly
}

function ic_get_alt_text_data() {
    $args = [
      'post_type' => 'attachment',
      'post_status' => 'inherit',
      'posts_per_page' => -1,
      'post_mime_type' => 'image',
    ];
  
    $query = new WP_Query($args);
    $results = [];
  
    foreach ($query->posts as $post) {
      $alt = get_post_meta($post->ID, '_wp_attachment_image_alt', true);
      $results[] = [
        'id' => $post->ID,
        'title' => $post->post_title,
        'alt' => $alt,
      ];
    }
  
    return $results;
  }
  

  // Collect attachment IDs referenced by elementor_font posts (meta: elementor_font_files)
function ic_get_elementor_font_attachment_ids() {
    $cache_key = 'ic_elementor_font_attachment_ids';
    $cached = get_transient($cache_key);
    if ($cached !== false && is_array($cached)) return $cached;
  
    $ids = [];
  
    $font_posts = get_posts([
      'post_type'   => 'elementor_font',
      'post_status' => 'any',
      'numberposts' => -1,
      'fields'      => 'ids',
    ]);
  
    foreach ($font_posts as $font_id) {
      $files = get_post_meta($font_id, 'elementor_font_files', true);
      if (!is_array($files)) continue;
  
      foreach ($files as $entry) {
        foreach (['svg','woff','woff2','ttf','eot'] as $fmt) {
          if (!empty($entry[$fmt]['id'])) {
            $ids[] = (int) $entry[$fmt]['id'];
          }
        }
      }
    }
  
    $ids = array_values(array_unique(array_filter($ids)));
    set_transient($cache_key, $ids, HOUR_IN_SECONDS);
    return $ids;
  }
  

  