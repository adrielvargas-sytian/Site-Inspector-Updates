<?php

//************admin column*************/


function add_a_instance_column($columns) {
    $new_columns = [];
    foreach ($columns as $key => $value) {
        if ($key == 'shortcode') {
            $new_columns['custom_instance'] = '<span title="Click here to select all unused templates.">Status</span>';
        }
        $new_columns[$key] = $value;
    }
    return $new_columns;
}


function add_custom_column_to_post_types($post_type) {
    if (in_array($post_type, ['jet-engine', 'elementor_library','ae_global_templates','jet-popup'])) {
        add_filter("manage_{$post_type}_posts_columns", 'add_a_instance_column');
    }
}

/******************* C O L U M N S ******************/
/******elementor template**********/
function custom_column_content($column, $post_id) {
    if ($column == 'custom_instance') {
        echo scan_elementor_templates($post_id);//get_post_meta($post_id, 'custom_field', true);
    }
}
add_action('manage_posts_custom_column', 'custom_column_content', 10, 2);

add_action('current_screen', function() {
    $screen = get_current_screen();
    if ($screen) {
        add_custom_column_to_post_types($screen->post_type);
    }
});

function get_elementor_template_type($post_id) {
    // Retrieve the meta value
    $template_type = get_post_meta($post_id, '_elementor_template_type', true);
    return $template_type;
}


/******Jet Engine Listing**********/
function add_new_jet_engine_column($columns) {
    $columns['custom_instance'] = __('Status', 'textdomain');
    return $columns;
}
add_filter('manage_edit-jet-engine_columns', 'add_new_jet_engine_column');




/******JetPopup**********/
function add_new_jet_popup_column($columns) {
    $columns['custom_instance'] = __('Status', 'textdomain');
    return $columns;
}
add_filter('manage_edit-jet-popup_columns', 'add_new_jet_popup_column');



/******AE Template**********/
function add_new_ae_template_column($columns) {
    $columns['custom_instance'] = __('Status', 'textdomain');
    return $columns;
}
add_filter('manage_edit-ae_global_templates_columns', 'add_new_ae_template_column');



/***************Menu**************/
   
function my_plugin_menu() {
	// Add top-level menu
    
    add_menu_page(
        'Site Inspector', // Page title
        'Site Inspector', // Menu title
        'manage_options', // Capability
        'e-assets', // Menu slug
        'e_assets', // Callback function
        'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxOS4yLjEsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiDQoJIHZpZXdCb3g9IjAgMCA0OCA0OCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNDggNDg7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxnPg0KCTxyZWN0IHg9IjIxLjciIHk9IjYuOCIgd2lkdGg9IjEyLjEiIGhlaWdodD0iMyIvPg0KCTxyZWN0IHg9IjEwLjQiIHk9IjMxLjYiIHdpZHRoPSI2IiBoZWlnaHQ9IjMiLz4NCgk8cG9seWdvbiBwb2ludHM9IjIxLjcsMTYgMzMuNywxNiAzMy43LDE0LjUgMzMuNywxMyAyMS43LDEzIAkiLz4NCgk8cmVjdCB4PSIxMC40IiB5PSIyNS40IiB3aWR0aD0iNy41IiBoZWlnaHQ9IjMiLz4NCgk8cmVjdCB4PSIxMC40IiB5PSIxOS4yIiB3aWR0aD0iOC4xIiBoZWlnaHQ9IjMiLz4NCgk8cGF0aCBkPSJNMjYuOSwzMS42YzAtMi41LDItNC41LDQuNS00LjVjMC44LDAsMS41LTAuNywxLjUtMS41YzAtMC44LTAuNy0xLjUtMS41LTEuNWMtNC4xLDAtNy41LDMuNC03LjUsNy41DQoJCWMwLDAuOCwwLjcsMS41LDEuNSwxLjVDMjYuMywzMy4xLDI2LjksMzIuNSwyNi45LDMxLjZ6Ii8+DQoJPHBhdGggZD0iTTQ3LjQsNDUuNkw0MC44LDM5YzEuNi0yLDIuNS00LjYsMi41LTcuNGMwLTYuNi01LjQtMTItMTItMTJzLTEyLDUuNC0xMiwxMmMwLDYuNiw1LjQsMTIsMTIsMTJjMi44LDAsNS4zLTEsNy40LTIuNQ0KCQlsNi42LDYuNmMwLjMsMC4zLDAuNywwLjQsMS4xLDAuNGMwLjQsMCwwLjgtMC4xLDEuMS0wLjRDNDgsNDcuMSw0OCw0Ni4yLDQ3LjQsNDUuNnogTTMxLjMsNDAuN2MtNSwwLTktNC05LTljMC01LDQtOSw5LTkNCgkJYzUsMCw5LDQsOSw5QzQwLjMsMzYuNiwzNi4yLDQwLjcsMzEuMyw0MC43eiIvPg0KCTxwYXRoIGQ9Ik0zNy4zLDBoLTMuNGgtMUg3LjJDNS41LDAsNCwxLjQsNCwzdjEuNWMtMiwwLTQsMi00LDQuNXYzMy4xQzAsNDQuNiwxLjcsNDcsNC4yLDQ3SDI0di0xLjhWNDRINC4yQzMuNCw0NCwzLDQzLDMsNDIuMlY5LjENCgkJYzAtMC44LDAtMS41LDEtMS41djMxLjZDNCw0MC44LDUuNSw0Miw3LjIsNDJIMTl2LTNIN1YzaDI1LjloMUgzN3YxNmgzVjNDNDAsMS40LDM5LDAsMzcuMywweiIvPg0KCTxyZWN0IHg9IjkuNyIgeT0iNS44IiB3aWR0aD0iOS43IiBoZWlnaHQ9IjEwLjkiLz4NCjwvZz4NCjwvc3ZnPg0K', // Icon URL
        6 // Position
    );

    add_submenu_page(
        'e-assets', // Parent slug
        'Dashboard',                // Page title
        'Dashboard',                // Menu label
        'manage_options',
        'e-assets',
        'e_assets'
    );


    // Add Image Link Checker submenu
    add_submenu_page(
        'e-assets', // Parent slug
        'Image Checker', // Page title
        'Image Checker', // Menu title
        'manage_options', // Capability
        'image-link-checker', // Menu slug
        'ic_settings_page' // Callback function
    );

    // Add Image Link Checker submenu
    add_submenu_page(
        'e-assets', // Parent slug
        'Image Alt Text', // Page title
        'Image Alt Text', // Menu title
        'manage_options', // Capability
        'image-alt_text', // Menu slug
        'iat_settings_page' // Callback function
    );
    
    
    // Add Meta Tag submenu
    add_submenu_page(
        'e-assets', // Parent slug
        'Metadata Generator', // Page title
        'Metadata Generator', // Menu title
        'manage_options', // Capability
        'e-meta_tags', // Menu slug
        'mt_settings_page' // Callback function
    );

    // Add Taxonomy Metadata subpage
    add_submenu_page(
        'e-assets', // Same parent slug
        'Taxonomy Metadata Generator', // Page title
        ' — Taxonomies', // Menu title
        'manage_options',
        'e-meta_taxonomies', // New slug
        'mt_taxonomy_settings_page' // New callback
    );

    


    //templates overview
    add_submenu_page(
        'e-assets',
        'Template Overview',
        'Template Overview',
        'manage_options',
        'template-overview',
        'render_template_overview_page'
      );

	// Add Templates submenu
    add_submenu_page(
        'e-assets', // Parent slug
        'Elementor Templates', // Page title
        ' — Elementor', // Menu title
        'manage_options', // Capability
        'edit.php?post_type=elementor_library' // Menu slug
    );
	
	//display Jet Engine Listings & AE Templates
	check_plugins_and_components();

    // Add Elementor Form submenu
    add_submenu_page(
        'e-assets', // Parent slug
        'Elementor Forms', // Page title
        'Elementor Forms', // Menu title
        'manage_options', // Capability
        'e-elementor_forms', // Menu slug
        'mt_forms_page' // Callback function
    );


    // update theme
    add_submenu_page(
        'e-assets', // Parent slug
        'Theme Setup', // Page title
        'Theme Setup', // Menu title
        'manage_options', // Capability
        'e-theme-setup', // Menu slug
        'si_render_theme_injector' // Callback function
    );


    //gemini settings
    add_submenu_page(
        'e-assets',
        'Gemini Settings',
        'Gemini Settings',
        'manage_options',
        'gemini-settings',
        'render_gen_ai_settings_page'
    );

    
		  
}
add_action('admin_menu', 'my_plugin_menu',1);

add_action('admin_menu', function () {
    add_submenu_page(
        'upload.php',
        'Trashed Attachments',
        'Trashed Attachments',
        'manage_options',
        'trashed-attachments',
        'ic_view_trashed_attachments'
    );
});

// Callback function for the top-level menu
function e_assets() {
  // Fetch stats from scan functions
  $templates = get_all_templates(); // From template-scan
  $template_total = count($templates);
  $template_unused = count(array_filter($templates, fn($tpl) => $tpl['status'] === 'Unused'));

  $images = ic_check_image_links_data(); // From image-checker
  $image_total = count($images);
  $image_unused = count(array_filter($images, fn($img) => $img['status'] === 'Unused'));


  
// Alt text stats (based on alt text table)
  $alt_text_data = ic_get_alt_text_data(); // You can extract this from your alt text generator logic
  $alt_total = count($alt_text_data);
  $alt_missing = count(array_filter($alt_text_data, fn($img) => empty(trim($img['alt'])) || str_starts_with($img['alt'], 'http')));

  // Elementor forms stats
  $form_total = get_elementor_forms_count();
	
	  // Placeholder stats for other modules
  $meta_count = 0;


  $encrypted_key = get_option('gen_ai_api_key');
  $api_key = decrypt_gen_ai_api_key($encrypted_key);
  if (empty($api_key)) {
    $gem_dash_style = 'background:#fdd;border-color:#c00;';
  }
  

  $modules = [    
    [
      'title' => 'Image Checker',
      'slug' => 'image-link-checker',
      'description' => 'Detect unused media attachments across posts, templates, and taxonomies.',
      'icon' => '',
      'stats' => "{$image_total} images<br><span style='color:red;'>{$image_unused} unused</span>",
      'style' => ""
    ],
    [
      'title' => 'Image Alt Text',
      'slug' => 'image-alt_text',
      'description' => 'Generate and audit alt text for attachments. Improve accessibility and SEO.',
      'icon' => '',
      'stats' => "{$alt_total} images<br><span style='color:red;'>{$alt_missing} missing alt text</span>",
      'style' => ""
    ],
    [
      'title' => 'Metadata Generator',
      'slug' => 'e-meta_tags',
      'description' => 'Generate meta titles and descriptions for posts and pages.',
      'icon' => '',
      'stats' => "",
      'style' => ""
    ],
    [
        'title' => 'Template Overview',
        'slug' => 'template-overview',
        'description' => 'Scan and audit Elementor, AE, JetEngine, and JetPopup templates. Filter by usage and type.',
        'icon' => '',
        'stats' => "{$template_total} templates<br><span style='color:red;'>{$template_unused} unused</span>",
        'style' => ""
        ],
    [
      'title' => 'Elementor Forms',
      'slug' => 'e-elementor_forms',
      'description' => 'Inspect and manage Elementor form submissions and configurations.',
      'icon' => '',
      'stats' => "{$form_total} forms",
      'style' => ""
    ],
    [
        'title' => 'Theme Setup',
        'slug' => 'e-theme-setup',
        'description' => 'Update theme info and screenshot',
        'icon' => '',
        'stats' => "",
        'style' => ""
      ],
    [
      'title' => 'Gemini Settings',
      'slug' => 'gemini-settings',
      'description' => 'Configure Gemini module settings and integrations.',
      'icon' => '',
      'stats' => '',
      'style' => "{$gem_dash_style}"
    ]
  ];

  echo '<div class="wrap"><h1>Site Inspector Dashboard</h1>';
  echo '<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin-top: 20px;">';

  foreach ($modules as $mod) {
    $url = admin_url("admin.php?page=" . $mod['slug']);
    echo '<div style="background: #fff; border: 1px solid #ddd; padding: 16px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); '.$mod['style'].'">';
    echo '<div style="font-size: 24px; margin-bottom: 8px;">' . $mod['icon'] . ' <strong>' . esc_html($mod['title']) . '</strong></div>';
    echo '<p style="margin-bottom: 12px;">' . esc_html($mod['description']) . '</p>';
    if (!empty($mod['stats'])) {
      echo '<div style="font-size: 13px; margin-bottom: 12px; color: #555;">' . $mod['stats'] . '</div>';
    }
    echo '<a href="' . esc_url($url) . '" class="button button-primary">Open '.esc_html($mod['title']).'</a>';
    echo '</div>';
  }

  echo '</div></div>';
}

  





function check_plugins_and_components() {
    // Check if JetEngine plugin is active

		
		if (is_plugin_active('jet-engine/jet-engine.php')) {
			// Check if Listings/Components of JetEngine are active
			if (post_type_exists('jet-engine')) {
				
				// Add Jet Engine Listing submenu
				add_submenu_page(
					'e-assets', // Parent slug
					'JetEngine Listings', // Page title
					' — JetEngine', // Menu title
					'manage_options', // Capability
					'edit.php?post_type=jet-engine' // Menu slug
				);
				
			}
			
			if (post_type_exists('jet-popup')) {
				
				// Add Jet Engine Listing submenu
				add_submenu_page(
					'e-assets', // Parent slug
					'JetPopup', // Page title
					' — JetPopup', // Menu title
					'manage_options', // Capability
					'edit.php?post_type=jet-popup' // Menu slug
				);
				
			}
		}

		// Check if Anywhere Elementor plugin is active
		if (is_plugin_active('anywhere-elementor-pro/anywhere-elementor-pro.php')) {

			// Check if AE Templates are active
			if (post_type_exists('ae_global_templates')) {

				// Add Jet Engine Listing submenu
				add_submenu_page(
					'e-assets', // Parent slug
					'AE Templates', // Page title
					' — AE', // Menu title
					'manage_options', // Capability
					'edit.php?post_type=ae_global_templates' // Menu slug
				);

			}
		}
	
		
    

    
}

// Add JavaScript to remove and add classes conditionally
function remove_and_add_classes() {
    echo "
    <script type='text/javascript'>
        jQuery(document).ready(function($) {
    $('.toplevel_page_e-assets li').each(function() {
        if ($(this).text().trim() === 'Elementor Templates' && $(this).hasClass('current') && $(this).closest('.toplevel_page_e-assets').hasClass('wp-has-current-submenu wp-menu-open')) {
            // Remove classes from the closest parent .toplevel_page_e-assets
            $(this).closest('.toplevel_page_e-assets').removeClass('wp-has-current-submenu wp-menu-open');
            $(this).closest('.toplevel_page_e-assets').addClass('wp-not-current-submenu');

            $(this).find('a').removeClass('wp-has-current-submenu wp-menu-open');
            $(this).find('a').addClass('wp-not-current-submenu');

            // Add classes to .menu-icon-elementor_library
            $('.menu-icon-elementor_library').addClass('wp-has-current-submenu wp-menu-open');
            $('.menu-icon-elementor_library').removeClass('wp-not-current-submenu');

            console.log('Elementor Templates')
        }else if ($(this).text().trim() === 'JetEngine Listings' && $(this).hasClass('current') && $(this).closest('.toplevel_page_e-assets').hasClass('wp-has-current-submenu wp-menu-open')) {
            // Remove classes from the closest parent .toplevel_page_e-assets
            $(this).closest('.toplevel_page_e-assets').removeClass('wp-has-current-submenu wp-menu-open');
            $(this).closest('.toplevel_page_e-assets').addClass('wp-not-current-submenu');

            $(this).find('a').removeClass('wp-has-current-submenu wp-menu-open');
            $(this).find('a').addClass('wp-not-current-submenu');

            // Add classes to .menu-icon-elementor_library
            $('.toplevel_page_jet-engine').addClass('wp-has-current-submenu wp-menu-open');
            $('.toplevel_page_jet-engine').removeClass('wp-not-current-submenu');
            console.log('JetEngine Listings')
        }else if ($(this).text().trim() === 'AE Templates' && $(this).hasClass('current') && $(this).closest('.toplevel_page_e-assets').hasClass('wp-has-current-submenu wp-menu-open')) {
            // Remove classes from the closest parent .toplevel_page_e-assets
            $(this).closest('.toplevel_page_e-assets').removeClass('wp-has-current-submenu wp-menu-open');
            $(this).closest('.toplevel_page_e-assets').addClass('wp-not-current-submenu');

            $(this).find('a').removeClass('wp-has-current-submenu wp-menu-open');
            $(this).find('a').addClass('wp-not-current-submenu');

            // Add classes to .menu-icon-elementor_library
            $('.menu-icon-ae_global_templates').addClass('wp-has-current-submenu wp-menu-open');
            $('.menu-icon-ae_global_templates').removeClass('wp-not-current-submenu');
            console.log('AE Templates')
        }
    });
});








    </script>
    ";
}
add_action('admin_footer', 'remove_and_add_classes');





add_action('admin_head', 'add_custom_submenu_class');
function add_custom_submenu_class() {
    $encrypted_key = get_option('gen_ai_api_key');
    $api_key = decrypt_gen_ai_api_key($encrypted_key);
    if (empty($api_key)) {
        ?>
        <style>
            #toplevel_page_e-assets .wp-submenu a[href="admin.php?page=gemini-settings"] {
                background: red !important;
                color: #fff !important;
            }
            #toplevel_page_e-assets > a .wp-menu-name:after {
                content: '1';
                padding: 0 6px;
                margin-left: 6px;
                background: #d63638;
                border-radius: 100px;
                font-size: 12px;
                font-weight: bold;
                color: #fff;
                display: inline-block;
                text-align: center;
            }
        </style>
        <?php
    }
}

