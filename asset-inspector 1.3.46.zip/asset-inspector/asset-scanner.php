<?php

/*
Plugin Name:  Asset Inspector
Plugin URI:   https://www.sytian-productions.com/
Description:  Asset Inspector helps developers and site owners manage image assets with confidence. It scans your entire site—posts, templates, sliders, forms, and database fields—to detect media usage, flag unused files, and suggest improvements like alt text and SEO meta tags.
Version:      1.3.46
Author:       Adriel + Copilot
Author URI:   https://www.sytian-productions.com/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  asset-scan
*/


//add PA Template Mega Menu
//menu item = post type: nav_menu_item 
//loop nav_menu_item
//get meta_value from meta_key 'pa_mega_content_temp' and cross reference it with all templates if it is used.
//get the meta value 'pa_megamenu_item_meta' and search for 'mega_content_enabled'




// Include additional files
include_once plugin_dir_path(__FILE__) . 'template-scan.php';
include_once plugin_dir_path(__FILE__) . 'admin-menu.php';
include_once plugin_dir_path(__FILE__) . 'shortcodes.php';

include_once plugin_dir_path(__FILE__) . 'image-checker.php';
include_once plugin_dir_path(__FILE__) . 'image-trash-dashboard.php';
include_once plugin_dir_path(__FILE__) . 'image-alt-text.php';
include_once plugin_dir_path(__FILE__) . 'meta-tag.php';
include_once plugin_dir_path(__FILE__) . 'meta-tag-taxonomy.php';
include_once plugin_dir_path(__FILE__) . 'elementor-form.php';
include_once plugin_dir_path(__FILE__) . 'gen-ai.php';
include_once plugin_dir_path(__FILE__) . 'alt-text-ai.php';

include_once plugin_dir_path(__FILE__) . 'theme-setup.php';

include_once plugin_dir_path(__FILE__) . 'image-compression.php';
















function enqueue_custom_admin_script($hook) {
    // Check if we are on the edit.php page for the specific post type
    if ($hook != 'edit.php') {
        return;
    }
    
    // Enqueue jQuery (if not already included)
    wp_enqueue_script('jquery');
    
    // Add inline script to ensure it runs
    add_action('admin_footer', function() {
        echo '<script src="' . plugins_url('/assets/js/script.js', __FILE__) . '"></script>';
        //echo '<script>console.log("Custom script added to footer!!!");</script>';
    });
}
add_action('admin_enqueue_scripts', 'enqueue_custom_admin_script');


function enqueue_custom_admin_styles($hook) {
    // Check if we are on the edit.php page
    if ($hook != 'edit.php') {
        return;
    }
    
    // Enqueue custom CSS
    wp_enqueue_style('custom-admin-styles', plugins_url('/assets/css/custom-admin-styles.css', __FILE__));
}
add_action('admin_enqueue_scripts', 'enqueue_custom_admin_styles');
