<?php

/*function render_gemini_alt_text_ui() {
    ?>
    <div class="wrap">
        <h1>🧠 Gemini Alt Text Generator</h1>
        <form method="post">
            <label for="attachment_id">Enter Attachment ID:</label>
            <input type="number" name="attachment_id" id="attachment_id" required>
            <?php submit_button('Generate Alt Text'); ?>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['attachment_id'])) {
            $attachment_id = intval($_POST['attachment_id']);
            $result = generate_gemini_alt_text($attachment_id);
            echo '<h2>Result:</h2><pre>' . esc_html($result) . '</pre>';
        }
        ?>
    </div>
    <?php
}*/

function generate_gemini_alt_text($attachment_id) {
    $alt_text = generate_gemini_alt_text_process($attachment_id);

    // Only return raw alt text
    return $alt_text;
}
function generate_gemini_alt_text_display($attachment_id) {
    return generate_gemini_alt_text_process($attachment_id);
}
function generate_gemini_alt_text_process($attachment_id) {
    $file_path = get_attached_file($attachment_id);
    $mime_type = get_post_mime_type($attachment_id);

    if (!file_exists($file_path)) {
        error_log("❌ File not found for attachment ID $attachment_id.");
        return '';
    }

    $image_data   = file_get_contents($file_path);
    $base64_image = base64_encode($image_data);


    $encrypted_key = get_option('gen_ai_api_key');
    $api_key = decrypt_gen_ai_api_key($encrypted_key);

    $model        = trim(get_option('gen_ai_model', 'gemini-2.0-flash'));

    // 🧠 Contextual metadata
    $filename = basename($file_path);
    $title    = get_the_title($attachment_id);
    $context  = "Filename: $filename. Title: $title.";

    // 📝 Prompt with context
    $prompt = "Generate a single-line alt text for this image. Keep it concise, readable, and under 255 characters. No formatting or options. Use this context if helpful: $context";

    $url = 'https://generativelanguage.googleapis.com/v1/models/' . urlencode($model) . ':generateContent?key=' . urlencode($api_key);

    $body = [
        'contents' => [[
            'parts' => [
                ['text' => $prompt],
                ['inline_data' => [
                    'mime_type' => $mime_type,
                    'data' => $base64_image
                ]]
            ]
        ]]
    ];

    $response = wp_remote_post($url, [
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => wp_json_encode($body),
        'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
        error_log('❌ Gemini request failed: ' . $response->get_error_message());
        return '';
    }

    $data     = json_decode(wp_remote_retrieve_body($response), true);
    $alt_text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

    if (!empty($alt_text)) {
        update_post_meta($attachment_id, '_wp_attachment_image_alt', sanitize_text_field($alt_text));
        error_log("✅ Alt text saved for ID $attachment_id: $alt_text");
    } else {
        error_log("⚠️ Empty alt text for ID $attachment_id. Full response: " . print_r($data, true));
    }

    
    return $alt_text;
}
// function generate_gemini_alt_text($attachment_id) {
//     $file_path = get_attached_file($attachment_id);
//     $mime_type = get_post_mime_type($attachment_id);

//     if (!file_exists($file_path)) {
//         return "❌ File not found for attachment ID $attachment_id.";
//     }

//     $image_data = file_get_contents($file_path);
//     $base64_image = base64_encode($image_data);

//     // Use your stored API key and model
//     $api_key = get_option('gen_ai_api_key');
//     $model   = trim(get_option('gen_ai_model', 'gemini-2.0-flash'));

//     // Build endpoint
//     $url      = 'https://generativelanguage.googleapis.com/v1/models/' . urlencode($model) . ':generateContent?key=' . urlencode($api_key);
//     $endpoint = strtok($url, '?') . '?key=***'; // For logging/debug only

//     // Gemini request body
//     $body = [
//         'contents' => [[
//             'parts' => [
//                 ['text' => 'Generate a single-line alt text for this image. Keep it concise, readable, and under 255 characters. No formatting or options.'],
//                 ['inline_data' => [
//                     'mime_type' => $mime_type,
//                     'data' => $base64_image
//                 ]]
//             ]
//         ]]
//     ];

//     $response = wp_remote_post($url, [
//         'headers' => ['Content-Type' => 'application/json'],
//         'body'    => wp_json_encode($body),
//         'timeout' => 30,
//     ]);

//     if (is_wp_error($response)) {
//         return '❌ Request failed: ' . $response->get_error_message();
//     }

//     $data = json_decode(wp_remote_retrieve_body($response), true);
//     $alt_text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

//     if (empty($alt_text)) {
//         error_log('⚠️ Gemini empty response for attachment ' . $attachment_id . ': ' . print_r($data, true));
//         $alt_text = '';
//     }

//     update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt_text);

//     return "✅ Alt text updated:\n" . $alt_text . "\n\n🔍 Endpoint used: " . esc_html($endpoint);
// }




add_action('add_attachment', 'auto_generate_gemini_alt_text_on_upload');

function auto_generate_gemini_alt_text_on_upload($attachment_id) {
    $mime_type = get_post_mime_type($attachment_id);

    // Only process images
    if (strpos($mime_type, 'image/') !== 0) {
        return;
    }

    // Optional: skip if alt text already exists
    $existing_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
    if (!empty($existing_alt)) {
        return;
    }

    // Call your Gemini function
    $result = generate_gemini_alt_text($attachment_id);

    // Optional: log result for debugging
    error_log("🧠 Gemini ALT generation result for attachment $attachment_id:\n$result");
}


/////////////////////////
add_action('wp_ajax_generate_single_alt_text_ai', 'generate_single_alt_text_ai');

function generate_single_alt_text_ai() {
    if (!current_user_can('upload_files')) {
        wp_send_json_error(['message' => 'Unauthorized']);
    }

    $image_id = intval($_POST['image_id'] ?? 0);
    if (!$image_id || get_post_type($image_id) !== 'attachment') {
        wp_send_json_error(['message' => 'Invalid image ID']);
    }

    $alt_text = generate_gemini_alt_text_process($image_id);

    if (!empty($alt_text)) {
        wp_send_json_success(['alt_text' => $alt_text]);
    } else {
        wp_send_json_error(['message' => 'No alt text returned']);
    }
}