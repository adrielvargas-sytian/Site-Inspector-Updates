<?php

function render_gen_ai_settings_page() {
    $api_key       = get_option('gen_ai_api_key');
    $decrypted_key = decrypt_gen_ai_api_key($api_key);

    $api_key_e = str_repeat("*", strlen($decrypted_key));

    $model         = get_option('gen_ai_model', 'gemini-2.0-flash');
    $meta_length   = get_option('gen_ai_meta_length', 30);
    $max_keywords  = get_option('gem_max_additional_keywords', 4);
    
    
    $status        = gem_test_gemini_api_key($decrypted_key, $model);
    ?>
    <div class="wrap">
        <h2>Gemini API Settings</h2>

        <form method="post" action="options.php">
            <?php
            settings_fields('gen_ai_settings_group');
            do_settings_sections('gemini-settings');
            ?>

            <table class="form-table">
                <tr>
                    <th scope="row"><label for="gen_ai_api_key">API Key</label></th>
                    <td>
                        <input type="password" name="gen_ai_api_key" id="gen_ai_api_key" value="<?php echo esc_attr($api_key_e); ?>" class="regular-text" />
                        
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="gen_ai_model">Model</label></th>
                    <td>
                        <select name="gen_ai_model" id="gen_ai_model">
                            <?php
                            $models = [
                                'gemini-2.0-flash' => 'Gemini 2.0 Flash (fast)',
                                'gemini-1.5-pro'   => 'Gemini 1.5 Pro (balanced)',
                                'gemini-pro'       => 'Gemini Pro (legacy)',
                                'chat-bison-001'   => 'Bison (v1beta compatible)',
                            ];
                            foreach ($models as $value => $label) {
                                echo '<option value="' . esc_attr($value) . '" ' . selected($model, $value, false) . '>' . esc_html($label) . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="gen_ai_meta_length">Meta Description Length</label></th>
                    <td>
                        <input type="number" name="gen_ai_meta_length" id="gen_ai_meta_length" min="10" max="300" step="10"
                               value="<?php echo esc_attr($meta_length); ?>" />
                        <p class="description">Approximate number of words for generated meta descriptions (default: 30)</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="gem_max_additional_keywords">🔢 Max Additional Keywords</label></th>
                    <td>
                        <input type="number" min="0" id="gem_max_additional_keywords" name="gem_max_additional_keywords"
                               value="<?php echo esc_attr($max_keywords); ?>" class="small-text">
                        <p class="description">Limit the number of additional keywords saved per post (default: 4)</p>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>

            <script>
document.addEventListener('DOMContentLoaded', function () {
  const displayInput = document.getElementById('gen_ai_api_key_display');
  const hiddenInput = document.getElementById('gen_ai_api_key');

  displayInput.addEventListener('input', function () {
    hiddenInput.value = displayInput.value;
  });
});
</script>
        </form>

        <p style="margin-top: 20px;">
            <strong>📚 Need help?</strong> Read the
            <a href="https://ai.google.dev/gemini-api/docs" target="_blank" rel="noopener noreferrer">
                official Gemini API documentation
            </a>.
        </p>

        <div style="margin-top: 20px;">
            <strong>🔐 API Key Status:</strong>
            <?php if ($status['ok']) : ?>
                <span style="color: green;">✅ Valid Key (model: <code><?php echo esc_html($model); ?></code>)</span>
            <?php else : ?>
                <span style="color: red;">❌ Invalid — <?php echo esc_html($status['message']); ?></span>
            <?php endif; ?>

            <h2>📊 Gemini Usage</h2>
            <p>You can view your token and request usage for this API key via
               <a href="https://aistudio.google.com/usage" target="_blank">AI Studio’s Usage Dashboard</a>.</p>
            <ul style="margin-left:1em;">
                <li><strong>Input Token Count per Day:</strong> Shown as a chart.</li>
                <li><strong>Request Count per Day:</strong> Includes both content and function calls.</li>
                <li><strong>Free Tier:</strong> 60 requests per minute, 1200 per day (as of July 2025).</li>
            </ul>
            <p>For advanced billing or quota tracking, visit your
               <a href="https://console.cloud.google.com/billing" target="_blank">Google Cloud Billing Console</a>.
            </p>
        </div>
    </div>
    <?php
}



function gem_test_gemini_api_key($key, $model = 'gemini-2.0-flash') {
    if (empty($key)) {
        return ['ok' => false, 'message' => 'API key is missing'];
    }

    $url = 'https://generativelanguage.googleapis.com/v1/models/' . urlencode($model) . ':generateContent?key=' . urlencode($key);

    $body = json_encode([
        'contents' => [[
            'parts' => [[ 'text' => 'ping' ]]
        ]]
    ]);

    $response = wp_remote_post($url, [
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => $body,
        'timeout' => 10,
    ]);

    if (is_wp_error($response)) {
        return ['ok' => false, 'message' => 'Connection failed'];
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);

    if ($code === 200 && strpos($body, 'candidates') !== false) {
        return ['ok' => true];
    }

    $json = json_decode($body, true);
    $error = $json['error']['message'] ?? 'Unknown error';
    return ['ok' => false, 'message' => $error];
}





add_action('admin_init', function () {
    //register_setting('gen_ai_settings_group', 'gen_ai_api_key');

    register_setting('gen_ai_settings_group', 'gen_ai_api_key', [
        'sanitize_callback' => function ($new_value) {
            $old_value = get_option('gen_ai_api_key');
    
            // If unchanged, skip saving
            if ($new_value === $old_value) {
                return $old_value;
            }
    
            // If input is only asterisks, skip saving
            if (preg_match('/^\*+$/', $new_value)) {
                return $old_value;
            }
    
            // Otherwise, encrypt and save
            return encrypt_gen_ai_api_key($new_value);
        },
    ]);
    

    
    

    register_setting('gen_ai_settings_group', 'gen_ai_model');
    register_setting('gen_ai_settings_group', 'gen_ai_meta_length');
    register_setting('gen_ai_settings_group', 'gem_max_additional_keywords'); // ✅ new line

    add_settings_section('gen_ai_main_section', '', null, 'gemini-settings');

    
});




function render_gen_ai_api_key_field() {
    $api_key = get_option('gen_ai_api_key', '');    
    echo '<input type="text" name="gen_ai_api_key" value="' . esc_attr($api_key) . '" style="width:400px;">';
}

function render_gen_max_keywords_field() {
    $value = get_option('gem_max_additional_keywords', 5);
    echo '<input type="number" name="gem_max_additional_keywords" value="' . esc_attr($value) . '" min="0" class="small-text"> <span class="description">Limit how many additional keywords Gemini is allowed to save per post (default: 5)</span>';
}



// 🚀 Register AJAX handler for logged-in users
add_action( 'wp_ajax_gem_generate_meta_tags', 'gem_generate_meta_tags_callback' );

function gem_generate_meta_tags_callback() {
    
    gem_add_debug_log( '🚀 Entered gem_generate_meta_tags_callback' );

    // 🔐 Verify nonce
    if ( empty( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'gem_meta_tags_nonce' ) ) {
        gem_add_debug_log( '🛑 Nonce verification failed' );
        wp_send_json_error( [ 'message' => 'Nonce verification failed (403)' ] );
        return;
    }

    // 🔐 Permission check
    if ( ! current_user_can( 'edit_posts' ) ) {
        gem_add_debug_log( '🛑 Current user lacks edit_posts capability' );
        wp_send_json_error( [ 'message' => 'Insufficient permissions' ] );
        return;
    }

    // 📥 Get post ID
    $post_id = absint( $_POST['post_id'] ?? 0 );
    if ( ! $post_id || get_post_status( $post_id ) === false ) {
        gem_add_debug_log( '🛑 Invalid or missing post ID: ' . $post_id );
        wp_send_json_error( [ 'message' => 'Invalid or missing post ID' ] );
        return;
    }

    // 📄 Get content
    $raw_content = get_post_field( 'post_content', $post_id );
    // 🧱 Fallback to ACF fields if content is empty (common in Elementor single templates)
    if ( empty( wp_strip_all_tags($raw_content) ) ) {
        gem_add_debug_log( '⚠️ Post content is empty — attempting ACF fallback for ID: ' . $post_id );
        $acf_fields = get_fields( $post_id );
        if ( is_array( $acf_fields ) && ! empty( $acf_fields ) ) {
            // 🧪 Convert ACF values to string for processing — you might want to refine this
            $raw_content = implode( "\n", array_map( function ( $value ) {
                return is_scalar( $value ) ? $value : json_encode( $value );
            }, $acf_fields ) );
            gem_add_debug_log( '📦 ACF fallback content assembled for Gemini generation' );
        } else {
            //gem_add_debug_log( '🛑 No ACF fields found for ID: ' . $post_id );
        
            
        }

        // 🧱 Final fallback: use post title + site name
        $post_title = get_the_title( $post_id );
        $site_title = get_bloginfo( 'name' );
        if ( ! empty( $post_title ) ) {
            $raw_content = "Page title: {$post_title}\nSite name: {$site_title}";
            gem_add_debug_log( '🪄 Using post title and site name as fallback content for Gemini' );
        } else {
            //$raw_content = "Page title: {$post_title}\nSite name: {$site_title}, This page is a placeholder page needing content";
            gem_add_debug_log( '🚫 No post title available — aborting Gemini generation' );
            wp_send_json_error( [ 'message' => 'No usable content, ACF, or title found' ] );
            //return;
        }
        
    }

    

    // 🔑 Get API key from settings or secure storage
    $api_key = trim( get_option( 'gen_ai_api_key' ) );
    $api_key = decrypt_gen_ai_api_key($api_key);
    if ( empty( $api_key ) ) {
        gem_add_debug_log( '🚫 API key is missing from settings' );
        wp_send_json_error( [ 'message' => 'API key is missing' ] );
        return;
    }
    
    
    // 🧠 Call Gemini
    $result = gem_call_gemini_api( $raw_content, $api_key );

    if ( is_wp_error( $result ) ) {
        gem_add_debug_log( '❌ Gemini generation failed: ' . $result->get_error_message() );
        wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        return;
    }

    gem_add_debug_log( '✅ Returning successful tag result for post ' . $post_id );
    wp_send_json_success( $result );
}




function gem_add_debug_log($line) {
    $logs = get_transient('gem_ai_debug_logs') ?: [];
    $logs[] = '[' . current_time('mysql') . '] ' . trim($line);
    set_transient('gem_ai_debug_logs', array_slice($logs, -10), 10 * MINUTE_IN_SECONDS); // keep last 10 logs
}







function gem_call_gemini_api( $content, $api_key ) {
    $model      = trim( get_option( 'gen_ai_model', 'gemini-2.0-flash' ) );
    $word_count = intval( get_option( 'gen_ai_meta_length', 30 ) );
    $api_key    = trim( $api_key );

    // Log empty config if any
    if ( empty( $model ) ) gem_add_debug_log( '🚫 Model is empty!' );
    if ( empty( $api_key ) ) gem_add_debug_log( '🚫 API key is missing!' );

    $url = 'https://generativelanguage.googleapis.com/v1/models/' . urlencode( $model ) . ':generateContent?key=' . urlencode( $api_key );
    $url_safe = strtok( $url, '?' ) . '?key=***';

    gem_add_debug_log( '🌐 Gemini Endpoint: ' . $url_safe );
    gem_add_debug_log( '🧠 Model: ' . $model );

    // Prepare content
    $content = apply_filters( 'the_content', $content );
    $content = html_entity_decode( wp_strip_all_tags( strip_shortcodes( $content ) ) );
    $content = trim( mb_substr( $content, 0, 8000 ) );

    gem_add_debug_log( '📄 Cleaned Content: ' . substr( $content, 0, 300 ) );

    if ( empty( $content ) ) {
        gem_add_debug_log( '❌ Cleaned content is empty.' );
        return new WP_Error( 'gemini_empty_input', 'Post content is empty or stripped.' );
    }

    $max_keywords = intval( get_option( 'gem_max_additional_keywords', 3 ) );
    $site_lang = get_bloginfo('language'); // Outputs like 'en-US' or 'ja'
$prompt = "You're an expert SEO assistant working in the language: {$site_lang}.
For the following content, generate:
- A brief meta description (~{$word_count} words)
- A primary keyword (1–3 words)
- A list of up to {$max_keywords} comma-separated additional keywords

Respond using this exact JSON format only (do not use Markdown code blocks):

{
  \"description\": \"...\",
  \"primary_keyword\": \"...\",
  \"additional_keywords\": \"...\"
}

Content:
{$content}";

    $body = [
        'contents' => [[
            'role'  => 'user',
            'parts' => [[ 'text' => $prompt ]]
        ]],
        'generationConfig' => [
            'temperature' => 0.7
        ]
    ];

    $response = wp_remote_post( $url, [
        'headers' => [ 'Content-Type' => 'application/json' ],
        'body'    => json_encode( $body ),
        'timeout' => 20,
    ]);

    if ( is_wp_error( $response ) ) {
        gem_add_debug_log( '🚨 HTTP Error: ' . $response->get_error_message() );
        return new WP_Error( 'gemini_http', $response->get_error_message() );
    }

    $body_raw = wp_remote_retrieve_body( $response );
    gem_add_debug_log( '📨 RAW: ' . substr( $body_raw, 0, 300 ) );

    $json = json_decode( $body_raw, true );

    if ( isset( $json['error'] ) ) {
        gem_add_debug_log( '❗ Gemini API Error: ' . $json['error']['message'] );
        return new WP_Error( 'gemini_api_error', $json['error']['message'] );
    }

    $text = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';

    if ( empty( $text ) ) {
        gem_add_debug_log( '❌ Gemini empty content received.' );
        return new WP_Error( 'gemini_no_text', 'No response from Gemini API.' );
    }

    gem_add_debug_log( '🧪 Gemini Text: ' . substr( $text, 0, 300 ) );

    // 🧹 Clean Markdown code fences if present
    $text_clean = preg_replace( '/^```json\s*/', '', $text );
    $text_clean = preg_replace( '/\s*```$/', '', $text_clean );
    gem_add_debug_log( '🧹 Cleaned for decode: ' . substr( $text_clean, 0, 300 ) );

    // 🔍 Try JSON parse
    $parsed = json_decode( $text_clean, true );

    // 🛠 Attempt patch if broken
    if ( ! is_array( $parsed ) ) {
        gem_add_debug_log( '⚠️ Attempting to patch broken JSON...' );

        if ( preg_match( '/"additional_keywords"\s*:\s*"[^"]*$/', $text_clean ) ) {
            $text_clean = preg_replace( '/"additional_keywords"\s*:\s*"[^"]*$/', '"additional_keywords": ""', $text_clean );
        }

        $text_clean = rtrim( $text_clean, ", \n\r\t" ) . "\"}";

        $parsed = json_decode( $text_clean, true );
    }

    // ❌ Final check
    if (
        ! is_array( $parsed ) ||
        ! isset( $parsed['description'], $parsed['primary_keyword'], $parsed['additional_keywords'] )
    ) {
        gem_add_debug_log( '❌ Parse fail after clean/patch: ' . substr( $text_clean, 0, 300 ) );
        return new WP_Error( 'gemini_parse', 'Gemini response malformed. Raw: ' . substr( $text, 0, 300 ) );
    }

    gem_add_debug_log( '✅ Final parsed result: ' . json_encode( $parsed ) );

    return [
        'description'         => sanitize_text_field( $parsed['description'] ),
        'primary_keyword'     => sanitize_text_field( $parsed['primary_keyword'] ),
        'additional_keywords' => sanitize_text_field( $parsed['additional_keywords'] ),
    ];
}










function gemini_generate_response($prompt) {
    $encrypted_key = get_option('gen_ai_api_key');
    $api_key = decrypt_gen_ai_api_key($encrypted_key);

    $response = wp_remote_post("https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={$api_key}", [
        'headers' => ['Content-Type' => 'application/json'],
        'body' => json_encode([
            'contents' => [[
                'parts' => [['text' => $prompt]]
            ]]
        ])
    ]);

    if (is_wp_error($response)) {
        return '❌ WP Error: ' . $response->get_error_message();
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

	if (
		isset($body['candidates'][0]['content']['parts'][0]['text']) &&
		!empty($body['candidates'][0]['content']['parts'][0]['text'])
	) {
		return $body['candidates'][0]['content']['parts'][0]['text'];
	}

	// Log fallback for debugging
	error_log('🤷 Gemini returned: ' . print_r($body, true));

	return '🤷 No result.';


    // 🔍 Log entire response
    error_log(print_r($body, true));

    // Try returning full first candidate for testing
    return $body['candidates'][0]['content']['parts'][0]['text'] ?? '🤷 No result.';
}

function render_gen_ai_meta_table($all_posts) {
    echo '<p>
        <button id="gem-generate-all" type="button" class="button">✨ Generate Tags for All</button>

        <button id="gem-save-all" class="button button-primary">💾 Save All Changes</button>
    </p>';

    echo '<div id="gem-progress-wrapper" style="margin: 1em 0; display: none;">
        <div style="height: 8px; background: #eee; width: 100%; border-radius: 4px;">
            <div id="gem-progress-bar" style="height: 100%; width: 0%; background: #0073aa; transition: width 0.3s ease; border-radius: 4px;"></div>
        </div>
        <small id="gem-progress-label" style="display: block; margin-top: 4px; color: #555;">Starting...</small>
    </div>';

    echo '<p id="gem-status-download-wrap" style="display: none;">
        <button id="gem-status-download" class="button">📥 Download Tag Report</button>
    </p>';

    echo '<table id="contentTable" class="widefat fixed striped">';
    echo '<thead><tr>
        <th width="70">Post ID</th>
        <th>Title</th>
        <th class="csv-url">Link</th>
        <th width="120">Post Type</th>
        <th>Primary Keyword</th>
        <th>Additional Keywords</th>
        <th>Meta Description</th>
        <th width="230">AI Actions</th>
    </tr></thead>';

    foreach ($all_posts as $post) {
        $post_id = $post->ID;
        $title = get_the_title($post_id);
        $link  = get_permalink($post_id);
        $type  = get_post_type($post_id);

        $primary    = get_post_meta($post_id, '_yoast_wpseo_focuskw', true);
        $additional = get_post_meta($post_id, '_yoast_wpseo_multiple_focus_keywords', true);
        $meta_desc  = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);

        if (!is_array($additional)) {
            $additional = [];
        }

        $additional_list = array_column($additional, 'keyword');
        $keyword_string  = implode(', ', $additional_list);

        echo '<tr data-title="' . esc_attr($title) . '">';
        echo '<td>' . esc_html($post_id) . '</td>';
        echo '<td class="title-cell">' . esc_html($title) . '</td>';
        echo '<td class="csv-url"><a href="' . esc_url($link) . '" target="_blank">' . esc_html($link) . '</a></td>';
        echo '<td>' . esc_html($type) . '</td>';

        echo '<td><input type="text" class="gem-primary" data-id="' . esc_attr($post_id) . '" value="' . esc_attr($primary) . '"></td>';
        echo '<td><input type="text" class="gem-additional" data-id="' . esc_attr($post_id) . '" value="' . esc_attr($keyword_string) . '"></td>';
        echo '<td><input type="text" class="gem-description" data-id="' . esc_attr($post_id) . '" value="' . esc_attr($meta_desc) . '"></td>';

        echo '<td class="gem-status-cell">';
        echo '<button class="generate-tags-btn button" data-post="' . esc_attr($post_id) . '">Generate Tags</button> ';
        echo '<span class="gem-status-icon" style="margin-left: 8px;"></span> ';
        echo '<button class="gem-save-row button" data-post="' . esc_attr($post_id) . '">💾</button>';
        echo '</td>';

        echo '</tr>';
    }

    echo '</table>';
}


function enqueue_gen_ai_script($hook) {
  if (strpos($hook, 'e-meta_tags') === false) return;

  wp_enqueue_script(
    'gen-ai-script',
    plugins_url('/assets/js/gen-ai-script.js', __FILE__),
    ['jquery'],
    '1.0',
    true
  );

  wp_localize_script('gen-ai-script', 'gem_meta_tags', [
		'nonce' => wp_create_nonce('gem_meta_tags_nonce')
	]);
}
add_action('admin_enqueue_scripts', 'enqueue_gen_ai_script');




function gem_save_meta_tags_for_post($post_id, $primary_keyword, $meta_description, $additional_keywords_raw) {
    if (!is_numeric($post_id)) return;

    // Sanitize inputs
    $primary_keyword  = sanitize_text_field($primary_keyword);
    $meta_description = sanitize_text_field($meta_description);
    $limit            = intval(get_option('gem_max_additional_keywords', 4));
    $keywords_array   = array_filter(array_map('trim', explode(',', $additional_keywords_raw)));

    // Enforce keyword limit
    $keywords_array = array_slice($keywords_array, 0, $limit);

    // Structure additional keywords
    $serialized = [];
    $scored     = [];

    foreach ($keywords_array as $keyword) {
        $serialized[] = [
            'keyword'   => $keyword,
            'synonyms'  => [],
            'modifiers' => [],
            'links'     => []
        ];
        $scored[] = [
            'keyword' => $keyword,
            'score'   => 0
        ];
    }

    // Save to Yoast-compatible fields
    update_post_meta($post_id, '_yoast_wpseo_focuskw', $primary_keyword);
    update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_description);
    update_post_meta($post_id, '_yoast_wpseo_multiple_focus_keywords', $serialized);
    update_post_meta($post_id, '_yoast_wpseo_focuskeywords', wp_json_encode($scored));
}


add_action('wp_ajax_gem_save_row_tags', 'gem_handle_row_save');

function gem_handle_row_save() {
    check_ajax_referer('gem_meta_nonce', 'nonce');

    $post_id    = intval($_POST['post_id']);
    $primary    = sanitize_text_field($_POST['primary'] ?? '');
    $desc       = sanitize_text_field($_POST['description'] ?? '');
    $additional = sanitize_text_field($_POST['additional_keywords'] ?? '');

    gem_save_meta_tags_for_post($post_id, $primary, $desc, $additional);

    wp_send_json_success(['message' => 'Saved successfully']);
}


define('GEN_AI_ENCRYPTION_KEY', 'v9XrL2qT8eYzB5pWfJmK1uNsHdCgQxRt');

function encrypt_gen_ai_api_key($input) {
    $encryption_key = defined('GEN_AI_ENCRYPTION_KEY') ? GEN_AI_ENCRYPTION_KEY : 'v9XrL2qT8eYzB5pWfJmK1uNsHdCgQxRt';
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($input, 'AES-256-CBC', $encryption_key, 0, $iv);
    return base64_encode($iv . $encrypted);
}


function decrypt_gen_ai_api_key($stored_value) {
    $encryption_key = defined('GEN_AI_ENCRYPTION_KEY') ? GEN_AI_ENCRYPTION_KEY : 'v9XrL2qT8eYzB5pWfJmK1uNsHdCgQxRt';
    $data = base64_decode($stored_value);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', $encryption_key, 0, $iv);
}